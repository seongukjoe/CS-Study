﻿namespace XModule.Forms.FormRecipe
{
    partial class FrmPageRecipeProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPageRecipeProject));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSaveAs = new Glass.GlassButton();
            this.btnOpen = new Glass.GlassButton();
            this.grid = new System.Windows.Forms.DataGridView();
            this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDelete = new Glass.GlassButton();
            this.a1Panel11 = new Owf.Controls.A1Panel();
            this.btnRename = new Glass.GlassButton();
            this.picVCM = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageGeneral = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lbResetTime1 = new System.Windows.Forms.Label();
            this.lbResetTime2 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.gbLanguageOption = new System.Windows.Forms.GroupBox();
            this.btnLanguage = new Glass.GlassButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.lblUseMES = new System.Windows.Forms.Label();
            this.btnUseMES = new Glass.GlassButton();
            this.label28 = new System.Windows.Forms.Label();
            this.lblVisionVer = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lbActuator_3_Mode = new System.Windows.Forms.Label();
            this.btnActuator_3_Mode = new Glass.GlassButton();
            this.lbPreAct = new System.Windows.Forms.Label();
            this.btnPreAct = new Glass.GlassButton();
            this.lblUseActNotAction2 = new System.Windows.Forms.Label();
            this.btnUseActNotAction2 = new Glass.GlassButton();
            this.lblUseActNotAction1 = new System.Windows.Forms.Label();
            this.btnUseActNotAction1 = new Glass.GlassButton();
            this.lblUseActRetry = new System.Windows.Forms.Label();
            this.btnUseActRetry = new Glass.GlassButton();
            this.lblbtnUseActAndCure = new System.Windows.Forms.Label();
            this.btnUseActAndCure = new Glass.GlassButton();
            this.lbActuator_2_Mode = new System.Windows.Forms.Label();
            this.lbActuator_1_Mode = new System.Windows.Forms.Label();
            this.btnActuator_2_Mode = new Glass.GlassButton();
            this.btnActuator_1_Mode = new Glass.GlassButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnUnloaderMagazine = new Glass.GlassButton();
            this.lbLoaderMagazine = new System.Windows.Forms.Label();
            this.lbUnloaderMagazine = new System.Windows.Forms.Label();
            this.btnLoaderMagazine = new Glass.GlassButton();
            this.btnLensMagazine = new Glass.GlassButton();
            this.lbLensMagazine = new System.Windows.Forms.Label();
            this.gbMachineOption = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbAlCooling2 = new System.Windows.Forms.Label();
            this.lbAlCooling1 = new System.Windows.Forms.Label();
            this.btnUseCooling2 = new Glass.GlassButton();
            this.btnUseCooling1 = new Glass.GlassButton();
            this.lbUseDummy2 = new System.Windows.Forms.Label();
            this.lbUseDummy1 = new System.Windows.Forms.Label();
            this.btnUseDummy2 = new Glass.GlassButton();
            this.btnUseDummy1 = new Glass.GlassButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDummyPeriodCount2 = new System.Windows.Forms.Label();
            this.lblDummyPeriodCount1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lbUsePlusenum_2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnUsePlusenum_2 = new Glass.GlassButton();
            this.lbUsePlusenum_1 = new System.Windows.Forms.Label();
            this.btnUsePlusenum_1 = new Glass.GlassButton();
            this.lblDummyTime2 = new System.Windows.Forms.Label();
            this.btnJettingMode_2 = new Glass.GlassButton();
            this.btnJettingMode_1 = new Glass.GlassButton();
            this.lblUseTipClean2 = new System.Windows.Forms.Label();
            this.lblDummyTime1 = new System.Windows.Forms.Label();
            this.lbUseIdle2 = new System.Windows.Forms.Label();
            this.lblUseTipClean1 = new System.Windows.Forms.Label();
            this.lbUseIdle1 = new System.Windows.Forms.Label();
            this.btnUseTipClean2 = new Glass.GlassButton();
            this.btnUseIdle2 = new Glass.GlassButton();
            this.btnUseTipClean1 = new Glass.GlassButton();
            this.btnUseIdle1 = new Glass.GlassButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLensHeightReslut = new Glass.GlassButton();
            this.lbVisionResult = new System.Windows.Forms.Label();
            this.lbLensHeightResult = new System.Windows.Forms.Label();
            this.btnVisionResult = new Glass.GlassButton();
            this.btnJigPlateAngleResult = new Glass.GlassButton();
            this.btnSideAngleResult = new Glass.GlassButton();
            this.lbSideAngleResult = new System.Windows.Forms.Label();
            this.lbJigFlatnessResult = new System.Windows.Forms.Label();
            this.gbRunOption = new System.Windows.Forms.GroupBox();
            this.btnVisionCheck = new Glass.GlassButton();
            this.lbVisionCheck = new System.Windows.Forms.Label();
            this.btnIndexCheck = new Glass.GlassButton();
            this.lbVacuumCheck = new System.Windows.Forms.Label();
            this.lbIndexCheck = new System.Windows.Forms.Label();
            this.btnVacuumCheck = new Glass.GlassButton();
            this.btnTrayCheck = new Glass.GlassButton();
            this.lbTrayCheck = new System.Windows.Forms.Label();
            this.gbSequenceOption = new System.Windows.Forms.GroupBox();
            this.btnUseAct3 = new Glass.GlassButton();
            this.lbUseAct3 = new System.Windows.Forms.Label();
            this.btnUseLensPicker = new Glass.GlassButton();
            this.lbUseLensPicker = new System.Windows.Forms.Label();
            this.btnUseCureVisionFail = new Glass.GlassButton();
            this.lbUseCureVisionFail = new System.Windows.Forms.Label();
            this.btnUseBonder2 = new Glass.GlassButton();
            this.btnUseCuring2 = new Glass.GlassButton();
            this.lbUseCuring2 = new System.Windows.Forms.Label();
            this.lbUseBonder2 = new System.Windows.Forms.Label();
            this.btnUseBonder1 = new Glass.GlassButton();
            this.btnUseCuring1 = new Glass.GlassButton();
            this.lbUseCuring1 = new System.Windows.Forms.Label();
            this.lbUseBonder1 = new System.Windows.Forms.Label();
            this.btnUseVision = new Glass.GlassButton();
            this.lbUseVision = new System.Windows.Forms.Label();
            this.btnUsePlateAngle = new Glass.GlassButton();
            this.lbUseJigPlateAngle = new System.Windows.Forms.Label();
            this.lbUsePlateAngle = new System.Windows.Forms.Label();
            this.btnUseJigPlateAngle = new Glass.GlassButton();
            this.btnUseCleanJig = new Glass.GlassButton();
            this.btnUseLensHeight = new Glass.GlassButton();
            this.lbUseLensHeight = new System.Windows.Forms.Label();
            this.lbUseCleanJig = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.lbUseMeasureContact = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lbPlateAngleGood = new System.Windows.Forms.Label();
            this.btnUseContact = new Glass.GlassButton();
            this.label39 = new System.Windows.Forms.Label();
            this.lbPlateAngleRetry = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.lbBonder2GapPosY = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbBonder2GapPosX = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbBonder1GapPosY = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbBonder1GapPosX = new System.Windows.Forms.Label();
            this.lbUseGap = new System.Windows.Forms.Label();
            this.btnUseGap = new Glass.GlassButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.lbVisionRetry = new System.Windows.Forms.Label();
            this.lbVisionRetryCount = new System.Windows.Forms.Label();
            this.lbBonder2Retry = new System.Windows.Forms.Label();
            this.lbBonder2RetryCount = new System.Windows.Forms.Label();
            this.lbBonder1Retry = new System.Windows.Forms.Label();
            this.lbBonder1RetryCount = new System.Windows.Forms.Label();
            this.lbLensBottomRetry = new System.Windows.Forms.Label();
            this.lbLensBottomRetryCount = new System.Windows.Forms.Label();
            this.lbLensUpperRetry = new System.Windows.Forms.Label();
            this.lbLensUpperRetryCount = new System.Windows.Forms.Label();
            this.lbVCMVisionRetry = new System.Windows.Forms.Label();
            this.lbVCMVISIONRetryCount = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lbSecondaryLimitValue = new System.Windows.Forms.Label();
            this.lbUseSecondaryCorrection = new System.Windows.Forms.Label();
            this.btnSecondaryCorrection = new Glass.GlassButton();
            this.btnAssembleMode = new Glass.GlassButton();
            this.lbLensThetaTorque = new System.Windows.Forms.Label();
            this.btnLensThetaTorque = new Glass.GlassButton();
            this.label19 = new System.Windows.Forms.Label();
            this.lbLensPickUpTorque = new System.Windows.Forms.Label();
            this.btnLensPickUpTorque = new Glass.GlassButton();
            this.lbTorqueLimitZ = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbLensInsertTorque = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnLensInsertTorque = new Glass.GlassButton();
            this.lbTorqueTLimit = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.lbUseResultRowDataJudge = new System.Windows.Forms.Label();
            this.btnUseResultRowDataJudge = new Glass.GlassButton();
            this.label13 = new System.Windows.Forms.Label();
            this.lbRnRShift = new System.Windows.Forms.Label();
            this.lblResultDummyPass = new System.Windows.Forms.Label();
            this.BtnResultDummyPass = new Glass.GlassButton();
            this.label5 = new System.Windows.Forms.Label();
            this.lbRnRGain = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lblLensAllowMin = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblLensHeight = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLensAllowMax = new System.Windows.Forms.Label();
            this.lbLensHeightSoftWareJudge = new System.Windows.Forms.Label();
            this.btnLensHeightSoftWareJudge = new Glass.GlassButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx2 = new System.Windows.Forms.Label();
            this.btnSelectItemDelete1 = new Glass.GlassButton();
            this.btnSelectItemAdd1 = new Glass.GlassButton();
            this.btnItemDelete1 = new Glass.GlassButton();
            this.btnItemAdd1 = new Glass.GlassButton();
            this.gridDp2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbJetPosGridTitle1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx1 = new System.Windows.Forms.Label();
            this.btnSelectItemDelete = new Glass.GlassButton();
            this.btnSelectItemAdd = new Glass.GlassButton();
            this.btnItemDelete = new Glass.GlassButton();
            this.btnItemAdd = new Glass.GlassButton();
            this.gridDp1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DEC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbJetPosGridTitle = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.picVCM2 = new System.Windows.Forms.PictureBox();
            this.picVCM1 = new System.Windows.Forms.PictureBox();
            this.btnPatCurNum2 = new Glass.GlassButton();
            this.btnPatPre2 = new Glass.GlassButton();
            this.btnPatCurNum1 = new Glass.GlassButton();
            this.label11 = new System.Windows.Forms.Label();
            this.btnPatPre1 = new Glass.GlassButton();
            this.lblPatCreate2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnPatNext2 = new Glass.GlassButton();
            this.lblPatCreate1 = new System.Windows.Forms.Label();
            this.btnPatNext1 = new Glass.GlassButton();
            this.gridPLineDp1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx2PLine = new System.Windows.Forms.Label();
            this.btnPLine2SelectItemDelete = new Glass.GlassButton();
            this.btnPLine2SelectItemAdd = new Glass.GlassButton();
            this.btnPLine2ItemDelete = new Glass.GlassButton();
            this.btnPLine2ItemAdd = new Glass.GlassButton();
            this.gridPLineDp2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx1PLine = new System.Windows.Forms.Label();
            this.btnPLine1SelectItemDelete = new Glass.GlassButton();
            this.btnPLine1SelectItemAdd = new Glass.GlassButton();
            this.btnPLine1ItemDelete = new Glass.GlassButton();
            this.btnPLine1ItemAdd = new Glass.GlassButton();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gridPArcDp2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridPArcDp1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picVCMArc2 = new System.Windows.Forms.PictureBox();
            this.picVCMArc1 = new System.Windows.Forms.PictureBox();
            this.btnArcCurNum2 = new Glass.GlassButton();
            this.btnArcPre2 = new Glass.GlassButton();
            this.btnArcCurNum1 = new Glass.GlassButton();
            this.label21 = new System.Windows.Forms.Label();
            this.btnArcPre1 = new Glass.GlassButton();
            this.lblArcCreate2 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnArcNext2 = new Glass.GlassButton();
            this.lblArcCreate1 = new System.Windows.Forms.Label();
            this.btnArcNext1 = new Glass.GlassButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx2PArc = new System.Windows.Forms.Label();
            this.btnPArc2SelectItemDelete = new Glass.GlassButton();
            this.btnPArc2SelectItemAdd = new Glass.GlassButton();
            this.btnPArc2ItemDelete = new Glass.GlassButton();
            this.btnPArc2ItemAdd = new Glass.GlassButton();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.lblSelectRowIdx1PArc = new System.Windows.Forms.Label();
            this.btnPArc1SelectItemDelete = new Glass.GlassButton();
            this.btnPArc1SelectItemAdd = new Glass.GlassButton();
            this.btnPArc1ItemDelete = new Glass.GlassButton();
            this.btnPArc1ItemAdd = new Glass.GlassButton();
            this.label31 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.a1Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVCM)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPageGeneral.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.gbLanguageOption.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbMachineOption.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbRunOption.SuspendLayout();
            this.gbSequenceOption.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDp2)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDp1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVCM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCM1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPLineDp1)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPLineDp2)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPArcDp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPArcDp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCMArc2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCMArc1)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.BackColor = System.Drawing.Color.Silver;
            this.btnSaveAs.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(150)));
            this.btnSaveAs.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSaveAs.GlowColor = System.Drawing.Color.Transparent;
            this.btnSaveAs.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveAs.InnerBorderColor = System.Drawing.Color.White;
            this.btnSaveAs.Location = new System.Drawing.Point(94, 539);
            this.btnSaveAs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSaveAs.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSaveAs.ShineColor = System.Drawing.Color.Silver;
            this.btnSaveAs.Size = new System.Drawing.Size(81, 45);
            this.btnSaveAs.TabIndex = 982;
            this.btnSaveAs.TabStop = false;
            this.btnSaveAs.Tag = "1";
            this.btnSaveAs.Text = "SAVE AS";
            this.btnSaveAs.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // btnOpen
            // 
            this.btnOpen.BackColor = System.Drawing.Color.Silver;
            this.btnOpen.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(150)));
            this.btnOpen.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnOpen.GlowColor = System.Drawing.Color.Transparent;
            this.btnOpen.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOpen.InnerBorderColor = System.Drawing.Color.White;
            this.btnOpen.Location = new System.Drawing.Point(7, 539);
            this.btnOpen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.OuterBorderColor = System.Drawing.Color.Black;
            this.btnOpen.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnOpen.ShineColor = System.Drawing.Color.Silver;
            this.btnOpen.Size = new System.Drawing.Size(81, 45);
            this.btnOpen.TabIndex = 981;
            this.btnOpen.TabStop = false;
            this.btnOpen.Tag = "2";
            this.btnOpen.Text = "OPEN";
            this.btnOpen.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.AllowUserToResizeColumns = false;
            this.grid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.grid.BackgroundColor = System.Drawing.Color.White;
            this.grid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grid.ColumnHeadersHeight = 30;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewTextBoxColumn1,
            this.Column2,
            this.Column3});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid.DefaultCellStyle = dataGridViewCellStyle5;
            this.grid.GridColor = System.Drawing.Color.Silver;
            this.grid.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grid.Location = new System.Drawing.Point(7, 6);
            this.grid.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.grid.MultiSelect = false;
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grid.RowHeadersVisible = false;
            this.grid.RowHeadersWidth = 30;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.grid.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.grid.RowTemplate.Height = 35;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.ShowCellErrors = false;
            this.grid.ShowEditingIcon = false;
            this.grid.ShowRowErrors = false;
            this.grid.Size = new System.Drawing.Size(344, 523);
            this.grid.StandardTab = true;
            this.grid.TabIndex = 983;
            this.grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_CellClick);
            // 
            // DataGridViewTextBoxColumn1
            // 
            this.DataGridViewTextBoxColumn1.FillWeight = 50F;
            this.DataGridViewTextBoxColumn1.HeaderText = "No";
            this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
            this.DataGridViewTextBoxColumn1.ReadOnly = true;
            this.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DataGridViewTextBoxColumn1.Width = 40;
            // 
            // Column2
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column2.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column2.HeaderText = "Module Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 200;
            // 
            // Column3
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column3.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column3.FillWeight = 200F;
            this.Column3.HeaderText = "DATE";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Silver;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(150)));
            this.btnDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnDelete.GlowColor = System.Drawing.Color.Transparent;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(181, 539);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnDelete.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnDelete.Size = new System.Drawing.Size(81, 45);
            this.btnDelete.TabIndex = 984;
            this.btnDelete.TabStop = false;
            this.btnDelete.Tag = "0";
            this.btnDelete.Text = "DELETE";
            this.btnDelete.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // a1Panel11
            // 
            this.a1Panel11.BackColor = System.Drawing.Color.White;
            this.a1Panel11.BorderColor = System.Drawing.Color.Black;
            this.a1Panel11.BorderWidth = 2;
            this.a1Panel11.Controls.Add(this.btnRename);
            this.a1Panel11.Controls.Add(this.picVCM);
            this.a1Panel11.Controls.Add(this.tabControl1);
            this.a1Panel11.Controls.Add(this.btnDelete);
            this.a1Panel11.Controls.Add(this.grid);
            this.a1Panel11.Controls.Add(this.btnOpen);
            this.a1Panel11.Controls.Add(this.btnSaveAs);
            this.a1Panel11.GradientEndColor = System.Drawing.Color.White;
            this.a1Panel11.GradientStartColor = System.Drawing.Color.White;
            this.a1Panel11.Image = null;
            this.a1Panel11.ImageLocation = new System.Drawing.Point(4, 4);
            this.a1Panel11.Location = new System.Drawing.Point(0, 0);
            this.a1Panel11.Name = "a1Panel11";
            this.a1Panel11.RoundCornerRadius = 12;
            this.a1Panel11.ShadowOffSet = 1;
            this.a1Panel11.Size = new System.Drawing.Size(1787, 993);
            this.a1Panel11.TabIndex = 191;
            // 
            // btnRename
            // 
            this.btnRename.BackColor = System.Drawing.Color.Silver;
            this.btnRename.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(150)));
            this.btnRename.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnRename.GlowColor = System.Drawing.Color.Transparent;
            this.btnRename.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRename.InnerBorderColor = System.Drawing.Color.White;
            this.btnRename.Location = new System.Drawing.Point(268, 539);
            this.btnRename.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRename.Name = "btnRename";
            this.btnRename.OuterBorderColor = System.Drawing.Color.Black;
            this.btnRename.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnRename.ShineColor = System.Drawing.Color.Silver;
            this.btnRename.Size = new System.Drawing.Size(81, 45);
            this.btnRename.TabIndex = 989;
            this.btnRename.TabStop = false;
            this.btnRename.Tag = "3";
            this.btnRename.Text = "RE NAME";
            this.btnRename.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // picVCM
            // 
            this.picVCM.Image = ((System.Drawing.Image)(resources.GetObject("picVCM.Image")));
            this.picVCM.Location = new System.Drawing.Point(18, 633);
            this.picVCM.Name = "picVCM";
            this.picVCM.Size = new System.Drawing.Size(318, 318);
            this.picVCM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVCM.TabIndex = 988;
            this.picVCM.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPageGeneral);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl1.ItemSize = new System.Drawing.Size(91, 35);
            this.tabControl1.Location = new System.Drawing.Point(358, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1428, 979);
            this.tabControl1.TabIndex = 985;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPageGeneral
            // 
            this.tabPageGeneral.BackColor = System.Drawing.Color.White;
            this.tabPageGeneral.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPageGeneral.Controls.Add(this.groupBox15);
            this.tabPageGeneral.Controls.Add(this.gbLanguageOption);
            this.tabPageGeneral.Controls.Add(this.groupBox17);
            this.tabPageGeneral.Controls.Add(this.groupBox7);
            this.tabPageGeneral.Controls.Add(this.groupBox2);
            this.tabPageGeneral.Controls.Add(this.gbMachineOption);
            this.tabPageGeneral.Controls.Add(this.gbSequenceOption);
            this.tabPageGeneral.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPageGeneral.ForeColor = System.Drawing.Color.RoyalBlue;
            this.tabPageGeneral.Location = new System.Drawing.Point(4, 39);
            this.tabPageGeneral.Name = "tabPageGeneral";
            this.tabPageGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGeneral.Size = new System.Drawing.Size(1420, 936);
            this.tabPageGeneral.TabIndex = 0;
            this.tabPageGeneral.Text = "GENERAL";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label14);
            this.groupBox15.Controls.Add(this.lbResetTime1);
            this.groupBox15.Controls.Add(this.lbResetTime2);
            this.groupBox15.Controls.Add(this.label17);
            this.groupBox15.Location = new System.Drawing.Point(483, 836);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(469, 92);
            this.groupBox15.TabIndex = 1535;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Auto Reset Time";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Gainsboro;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(44, 23);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label14.Size = new System.Drawing.Size(183, 31);
            this.label14.TabIndex = 1942;
            this.label14.Text = "Reset Time 1";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbResetTime1
            // 
            this.lbResetTime1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbResetTime1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResetTime1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResetTime1.ForeColor = System.Drawing.Color.Black;
            this.lbResetTime1.Location = new System.Drawing.Point(44, 58);
            this.lbResetTime1.Name = "lbResetTime1";
            this.lbResetTime1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lbResetTime1.Size = new System.Drawing.Size(183, 31);
            this.lbResetTime1.TabIndex = 1941;
            this.lbResetTime1.Tag = "0";
            this.lbResetTime1.Text = "3";
            this.lbResetTime1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbResetTime1.Click += new System.EventHandler(this.lbResetTime_Click);
            // 
            // lbResetTime2
            // 
            this.lbResetTime2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbResetTime2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResetTime2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResetTime2.ForeColor = System.Drawing.Color.Black;
            this.lbResetTime2.Location = new System.Drawing.Point(263, 58);
            this.lbResetTime2.Name = "lbResetTime2";
            this.lbResetTime2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lbResetTime2.Size = new System.Drawing.Size(178, 31);
            this.lbResetTime2.TabIndex = 1943;
            this.lbResetTime2.Tag = "1";
            this.lbResetTime2.Text = "3";
            this.lbResetTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbResetTime2.Click += new System.EventHandler(this.lbResetTime_Click);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Gainsboro;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(262, 23);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label17.Size = new System.Drawing.Size(179, 31);
            this.label17.TabIndex = 1944;
            this.label17.Text = "Reset Time 2";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbLanguageOption
            // 
            this.gbLanguageOption.Controls.Add(this.btnLanguage);
            this.gbLanguageOption.Location = new System.Drawing.Point(12, 746);
            this.gbLanguageOption.Name = "gbLanguageOption";
            this.gbLanguageOption.Size = new System.Drawing.Size(465, 87);
            this.gbLanguageOption.TabIndex = 1534;
            this.gbLanguageOption.TabStop = false;
            this.gbLanguageOption.Text = "Language Option";
            // 
            // btnLanguage
            // 
            this.btnLanguage.BackColor = System.Drawing.Color.Silver;
            this.btnLanguage.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLanguage.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLanguage.GlowColor = System.Drawing.Color.Transparent;
            this.btnLanguage.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLanguage.InnerBorderColor = System.Drawing.Color.White;
            this.btnLanguage.Location = new System.Drawing.Point(140, 26);
            this.btnLanguage.Name = "btnLanguage";
            this.btnLanguage.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLanguage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLanguage.ShineColor = System.Drawing.Color.Silver;
            this.btnLanguage.Size = new System.Drawing.Size(188, 46);
            this.btnLanguage.TabIndex = 1477;
            this.btnLanguage.TabStop = false;
            this.btnLanguage.Tag = "0";
            this.btnLanguage.Text = "KOREA";
            this.btnLanguage.Click += new System.EventHandler(this.BtnLanguage_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.lblUseMES);
            this.groupBox17.Controls.Add(this.btnUseMES);
            this.groupBox17.Controls.Add(this.label28);
            this.groupBox17.Controls.Add(this.lblVisionVer);
            this.groupBox17.Location = new System.Drawing.Point(483, 746);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(469, 84);
            this.groupBox17.TabIndex = 1533;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "MES Option";
            // 
            // lblUseMES
            // 
            this.lblUseMES.BackColor = System.Drawing.Color.Lime;
            this.lblUseMES.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseMES.Location = new System.Drawing.Point(26, 27);
            this.lblUseMES.Name = "lblUseMES";
            this.lblUseMES.Size = new System.Drawing.Size(15, 49);
            this.lblUseMES.TabIndex = 1540;
            // 
            // btnUseMES
            // 
            this.btnUseMES.BackColor = System.Drawing.Color.Silver;
            this.btnUseMES.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseMES.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseMES.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseMES.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseMES.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseMES.Location = new System.Drawing.Point(47, 27);
            this.btnUseMES.Name = "btnUseMES";
            this.btnUseMES.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseMES.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseMES.ShineColor = System.Drawing.Color.Silver;
            this.btnUseMES.Size = new System.Drawing.Size(158, 49);
            this.btnUseMES.TabIndex = 1539;
            this.btnUseMES.TabStop = false;
            this.btnUseMES.Tag = "0";
            this.btnUseMES.Text = "USE MES";
            this.btnUseMES.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(217, 26);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 49);
            this.label28.TabIndex = 1509;
            this.label28.Text = "VisionVer";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVisionVer
            // 
            this.lblVisionVer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVisionVer.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVisionVer.ForeColor = System.Drawing.Color.Black;
            this.lblVisionVer.Location = new System.Drawing.Point(311, 26);
            this.lblVisionVer.Name = "lblVisionVer";
            this.lblVisionVer.Size = new System.Drawing.Size(130, 49);
            this.lblVisionVer.TabIndex = 1510;
            this.lblVisionVer.Text = "1.0.1.1.";
            this.lblVisionVer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblVisionVer.Click += new System.EventHandler(this.lblVisionVer_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lbActuator_3_Mode);
            this.groupBox7.Controls.Add(this.btnActuator_3_Mode);
            this.groupBox7.Controls.Add(this.lbPreAct);
            this.groupBox7.Controls.Add(this.btnPreAct);
            this.groupBox7.Controls.Add(this.lblUseActNotAction2);
            this.groupBox7.Controls.Add(this.btnUseActNotAction2);
            this.groupBox7.Controls.Add(this.lblUseActNotAction1);
            this.groupBox7.Controls.Add(this.btnUseActNotAction1);
            this.groupBox7.Controls.Add(this.lblUseActRetry);
            this.groupBox7.Controls.Add(this.btnUseActRetry);
            this.groupBox7.Controls.Add(this.lblbtnUseActAndCure);
            this.groupBox7.Controls.Add(this.btnUseActAndCure);
            this.groupBox7.Controls.Add(this.lbActuator_2_Mode);
            this.groupBox7.Controls.Add(this.lbActuator_1_Mode);
            this.groupBox7.Controls.Add(this.btnActuator_2_Mode);
            this.groupBox7.Controls.Add(this.btnActuator_1_Mode);
            this.groupBox7.Location = new System.Drawing.Point(483, 409);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(469, 331);
            this.groupBox7.TabIndex = 1505;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Actuator Option";
            // 
            // lbActuator_3_Mode
            // 
            this.lbActuator_3_Mode.BackColor = System.Drawing.Color.White;
            this.lbActuator_3_Mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbActuator_3_Mode.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbActuator_3_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbActuator_3_Mode.Location = new System.Drawing.Point(43, 276);
            this.lbActuator_3_Mode.Name = "lbActuator_3_Mode";
            this.lbActuator_3_Mode.Size = new System.Drawing.Size(157, 44);
            this.lbActuator_3_Mode.TabIndex = 1536;
            this.lbActuator_3_Mode.Text = "Actuator #3 Mode";
            this.lbActuator_3_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnActuator_3_Mode
            // 
            this.btnActuator_3_Mode.BackColor = System.Drawing.Color.Silver;
            this.btnActuator_3_Mode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnActuator_3_Mode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnActuator_3_Mode.GlowColor = System.Drawing.Color.Transparent;
            this.btnActuator_3_Mode.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnActuator_3_Mode.InnerBorderColor = System.Drawing.Color.White;
            this.btnActuator_3_Mode.Location = new System.Drawing.Point(43, 229);
            this.btnActuator_3_Mode.Name = "btnActuator_3_Mode";
            this.btnActuator_3_Mode.OuterBorderColor = System.Drawing.Color.Black;
            this.btnActuator_3_Mode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnActuator_3_Mode.ShineColor = System.Drawing.Color.Silver;
            this.btnActuator_3_Mode.Size = new System.Drawing.Size(157, 44);
            this.btnActuator_3_Mode.TabIndex = 1535;
            this.btnActuator_3_Mode.TabStop = false;
            this.btnActuator_3_Mode.Tag = "0";
            this.btnActuator_3_Mode.Text = "ACTUATOR #3 MODE";
            this.btnActuator_3_Mode.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbPreAct
            // 
            this.lbPreAct.BackColor = System.Drawing.Color.Lime;
            this.lbPreAct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPreAct.Location = new System.Drawing.Point(263, 45);
            this.lbPreAct.Name = "lbPreAct";
            this.lbPreAct.Size = new System.Drawing.Size(15, 49);
            this.lbPreAct.TabIndex = 1534;
            // 
            // btnPreAct
            // 
            this.btnPreAct.BackColor = System.Drawing.Color.Silver;
            this.btnPreAct.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnPreAct.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPreAct.GlowColor = System.Drawing.Color.Transparent;
            this.btnPreAct.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPreAct.InnerBorderColor = System.Drawing.Color.White;
            this.btnPreAct.Location = new System.Drawing.Point(283, 45);
            this.btnPreAct.Name = "btnPreAct";
            this.btnPreAct.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPreAct.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPreAct.ShineColor = System.Drawing.Color.Silver;
            this.btnPreAct.Size = new System.Drawing.Size(158, 49);
            this.btnPreAct.TabIndex = 1533;
            this.btnPreAct.TabStop = false;
            this.btnPreAct.Tag = "0";
            this.btnPreAct.Text = "USE PRE ACT";
            this.btnPreAct.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblUseActNotAction2
            // 
            this.lblUseActNotAction2.BackColor = System.Drawing.Color.Lime;
            this.lblUseActNotAction2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseActNotAction2.Location = new System.Drawing.Point(263, 265);
            this.lblUseActNotAction2.Name = "lblUseActNotAction2";
            this.lblUseActNotAction2.Size = new System.Drawing.Size(15, 49);
            this.lblUseActNotAction2.TabIndex = 1532;
            // 
            // btnUseActNotAction2
            // 
            this.btnUseActNotAction2.BackColor = System.Drawing.Color.Silver;
            this.btnUseActNotAction2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseActNotAction2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseActNotAction2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseActNotAction2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseActNotAction2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseActNotAction2.Location = new System.Drawing.Point(284, 265);
            this.btnUseActNotAction2.Name = "btnUseActNotAction2";
            this.btnUseActNotAction2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseActNotAction2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseActNotAction2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseActNotAction2.Size = new System.Drawing.Size(158, 49);
            this.btnUseActNotAction2.TabIndex = 1531;
            this.btnUseActNotAction2.TabStop = false;
            this.btnUseActNotAction2.Tag = "0";
            this.btnUseActNotAction2.Text = "USE ACTUATING 2 ACTION";
            this.btnUseActNotAction2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblUseActNotAction1
            // 
            this.lblUseActNotAction1.BackColor = System.Drawing.Color.Lime;
            this.lblUseActNotAction1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseActNotAction1.Location = new System.Drawing.Point(263, 155);
            this.lblUseActNotAction1.Name = "lblUseActNotAction1";
            this.lblUseActNotAction1.Size = new System.Drawing.Size(15, 49);
            this.lblUseActNotAction1.TabIndex = 1530;
            // 
            // btnUseActNotAction1
            // 
            this.btnUseActNotAction1.BackColor = System.Drawing.Color.Silver;
            this.btnUseActNotAction1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseActNotAction1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseActNotAction1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseActNotAction1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseActNotAction1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseActNotAction1.Location = new System.Drawing.Point(283, 155);
            this.btnUseActNotAction1.Name = "btnUseActNotAction1";
            this.btnUseActNotAction1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseActNotAction1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseActNotAction1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseActNotAction1.Size = new System.Drawing.Size(158, 49);
            this.btnUseActNotAction1.TabIndex = 1529;
            this.btnUseActNotAction1.TabStop = false;
            this.btnUseActNotAction1.Tag = "0";
            this.btnUseActNotAction1.Text = "USE ACTUATING 1 ACTION";
            this.btnUseActNotAction1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblUseActRetry
            // 
            this.lblUseActRetry.BackColor = System.Drawing.Color.Lime;
            this.lblUseActRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseActRetry.Location = new System.Drawing.Point(263, 210);
            this.lblUseActRetry.Name = "lblUseActRetry";
            this.lblUseActRetry.Size = new System.Drawing.Size(15, 49);
            this.lblUseActRetry.TabIndex = 1528;
            // 
            // btnUseActRetry
            // 
            this.btnUseActRetry.BackColor = System.Drawing.Color.Silver;
            this.btnUseActRetry.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseActRetry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseActRetry.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseActRetry.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseActRetry.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseActRetry.Location = new System.Drawing.Point(284, 210);
            this.btnUseActRetry.Name = "btnUseActRetry";
            this.btnUseActRetry.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseActRetry.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseActRetry.ShineColor = System.Drawing.Color.Silver;
            this.btnUseActRetry.Size = new System.Drawing.Size(158, 49);
            this.btnUseActRetry.TabIndex = 1527;
            this.btnUseActRetry.TabStop = false;
            this.btnUseActRetry.Tag = "0";
            this.btnUseActRetry.Text = "USE ACTUATING\r\n#1 RETRY";
            this.btnUseActRetry.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblbtnUseActAndCure
            // 
            this.lblbtnUseActAndCure.BackColor = System.Drawing.Color.Lime;
            this.lblbtnUseActAndCure.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblbtnUseActAndCure.Location = new System.Drawing.Point(263, 100);
            this.lblbtnUseActAndCure.Name = "lblbtnUseActAndCure";
            this.lblbtnUseActAndCure.Size = new System.Drawing.Size(15, 49);
            this.lblbtnUseActAndCure.TabIndex = 1526;
            // 
            // btnUseActAndCure
            // 
            this.btnUseActAndCure.BackColor = System.Drawing.Color.Silver;
            this.btnUseActAndCure.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseActAndCure.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseActAndCure.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseActAndCure.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseActAndCure.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseActAndCure.Location = new System.Drawing.Point(284, 100);
            this.btnUseActAndCure.Name = "btnUseActAndCure";
            this.btnUseActAndCure.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseActAndCure.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseActAndCure.ShineColor = System.Drawing.Color.Silver;
            this.btnUseActAndCure.Size = new System.Drawing.Size(158, 49);
            this.btnUseActAndCure.TabIndex = 1525;
            this.btnUseActAndCure.TabStop = false;
            this.btnUseActAndCure.Tag = "0";
            this.btnUseActAndCure.Text = "USE ACTUATING \r\nAnd #1 Cure";
            this.btnUseActAndCure.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbActuator_2_Mode
            // 
            this.lbActuator_2_Mode.BackColor = System.Drawing.Color.White;
            this.lbActuator_2_Mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbActuator_2_Mode.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbActuator_2_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbActuator_2_Mode.Location = new System.Drawing.Point(42, 179);
            this.lbActuator_2_Mode.Name = "lbActuator_2_Mode";
            this.lbActuator_2_Mode.Size = new System.Drawing.Size(158, 44);
            this.lbActuator_2_Mode.TabIndex = 1516;
            this.lbActuator_2_Mode.Text = "Actuator #2 Mode";
            this.lbActuator_2_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbActuator_1_Mode
            // 
            this.lbActuator_1_Mode.BackColor = System.Drawing.Color.White;
            this.lbActuator_1_Mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbActuator_1_Mode.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbActuator_1_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbActuator_1_Mode.Location = new System.Drawing.Point(43, 77);
            this.lbActuator_1_Mode.Name = "lbActuator_1_Mode";
            this.lbActuator_1_Mode.Size = new System.Drawing.Size(157, 44);
            this.lbActuator_1_Mode.TabIndex = 1515;
            this.lbActuator_1_Mode.Text = "Actuator #1 Mode";
            this.lbActuator_1_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnActuator_2_Mode
            // 
            this.btnActuator_2_Mode.BackColor = System.Drawing.Color.Silver;
            this.btnActuator_2_Mode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnActuator_2_Mode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnActuator_2_Mode.GlowColor = System.Drawing.Color.Transparent;
            this.btnActuator_2_Mode.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnActuator_2_Mode.InnerBorderColor = System.Drawing.Color.White;
            this.btnActuator_2_Mode.Location = new System.Drawing.Point(43, 129);
            this.btnActuator_2_Mode.Name = "btnActuator_2_Mode";
            this.btnActuator_2_Mode.OuterBorderColor = System.Drawing.Color.Black;
            this.btnActuator_2_Mode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnActuator_2_Mode.ShineColor = System.Drawing.Color.Silver;
            this.btnActuator_2_Mode.Size = new System.Drawing.Size(157, 44);
            this.btnActuator_2_Mode.TabIndex = 1513;
            this.btnActuator_2_Mode.TabStop = false;
            this.btnActuator_2_Mode.Tag = "0";
            this.btnActuator_2_Mode.Text = "ACTUATOR #2 MODE";
            this.btnActuator_2_Mode.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnActuator_1_Mode
            // 
            this.btnActuator_1_Mode.BackColor = System.Drawing.Color.Silver;
            this.btnActuator_1_Mode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnActuator_1_Mode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnActuator_1_Mode.GlowColor = System.Drawing.Color.Transparent;
            this.btnActuator_1_Mode.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnActuator_1_Mode.InnerBorderColor = System.Drawing.Color.White;
            this.btnActuator_1_Mode.Location = new System.Drawing.Point(44, 30);
            this.btnActuator_1_Mode.Name = "btnActuator_1_Mode";
            this.btnActuator_1_Mode.OuterBorderColor = System.Drawing.Color.Black;
            this.btnActuator_1_Mode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnActuator_1_Mode.ShineColor = System.Drawing.Color.Silver;
            this.btnActuator_1_Mode.Size = new System.Drawing.Size(157, 44);
            this.btnActuator_1_Mode.TabIndex = 1509;
            this.btnActuator_1_Mode.TabStop = false;
            this.btnActuator_1_Mode.Tag = "0";
            this.btnActuator_1_Mode.Text = "ACTUATOR #1 MODE";
            this.btnActuator_1_Mode.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnUnloaderMagazine);
            this.groupBox2.Controls.Add(this.lbLoaderMagazine);
            this.groupBox2.Controls.Add(this.lbUnloaderMagazine);
            this.groupBox2.Controls.Add(this.btnLoaderMagazine);
            this.groupBox2.Controls.Add(this.btnLensMagazine);
            this.groupBox2.Controls.Add(this.lbLensMagazine);
            this.groupBox2.Location = new System.Drawing.Point(970, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(431, 220);
            this.groupBox2.TabIndex = 1503;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Magazine Work Direction";
            // 
            // btnUnloaderMagazine
            // 
            this.btnUnloaderMagazine.BackColor = System.Drawing.Color.Silver;
            this.btnUnloaderMagazine.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUnloaderMagazine.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUnloaderMagazine.GlowColor = System.Drawing.Color.Transparent;
            this.btnUnloaderMagazine.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUnloaderMagazine.InnerBorderColor = System.Drawing.Color.White;
            this.btnUnloaderMagazine.Location = new System.Drawing.Point(45, 154);
            this.btnUnloaderMagazine.Name = "btnUnloaderMagazine";
            this.btnUnloaderMagazine.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUnloaderMagazine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUnloaderMagazine.ShineColor = System.Drawing.Color.Silver;
            this.btnUnloaderMagazine.Size = new System.Drawing.Size(158, 50);
            this.btnUnloaderMagazine.TabIndex = 1513;
            this.btnUnloaderMagazine.TabStop = false;
            this.btnUnloaderMagazine.Tag = "0";
            this.btnUnloaderMagazine.Text = "UNLOADER";
            this.btnUnloaderMagazine.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // lbLoaderMagazine
            // 
            this.lbLoaderMagazine.BackColor = System.Drawing.Color.White;
            this.lbLoaderMagazine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLoaderMagazine.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbLoaderMagazine.ForeColor = System.Drawing.Color.Black;
            this.lbLoaderMagazine.Location = new System.Drawing.Point(238, 33);
            this.lbLoaderMagazine.Name = "lbLoaderMagazine";
            this.lbLoaderMagazine.Size = new System.Drawing.Size(156, 51);
            this.lbLoaderMagazine.TabIndex = 1510;
            this.lbLoaderMagazine.Text = "From Top/Bottom";
            this.lbLoaderMagazine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbUnloaderMagazine
            // 
            this.lbUnloaderMagazine.BackColor = System.Drawing.Color.White;
            this.lbUnloaderMagazine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUnloaderMagazine.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbUnloaderMagazine.ForeColor = System.Drawing.Color.Black;
            this.lbUnloaderMagazine.Location = new System.Drawing.Point(238, 155);
            this.lbUnloaderMagazine.Name = "lbUnloaderMagazine";
            this.lbUnloaderMagazine.Size = new System.Drawing.Size(156, 50);
            this.lbUnloaderMagazine.TabIndex = 1514;
            this.lbUnloaderMagazine.Text = "From Top/Bottom";
            this.lbUnloaderMagazine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLoaderMagazine
            // 
            this.btnLoaderMagazine.BackColor = System.Drawing.Color.Silver;
            this.btnLoaderMagazine.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLoaderMagazine.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLoaderMagazine.GlowColor = System.Drawing.Color.Transparent;
            this.btnLoaderMagazine.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoaderMagazine.InnerBorderColor = System.Drawing.Color.White;
            this.btnLoaderMagazine.Location = new System.Drawing.Point(45, 33);
            this.btnLoaderMagazine.Name = "btnLoaderMagazine";
            this.btnLoaderMagazine.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLoaderMagazine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLoaderMagazine.ShineColor = System.Drawing.Color.Silver;
            this.btnLoaderMagazine.Size = new System.Drawing.Size(158, 50);
            this.btnLoaderMagazine.TabIndex = 1509;
            this.btnLoaderMagazine.TabStop = false;
            this.btnLoaderMagazine.Tag = "0";
            this.btnLoaderMagazine.Text = "VCM LOADER";
            this.btnLoaderMagazine.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // btnLensMagazine
            // 
            this.btnLensMagazine.BackColor = System.Drawing.Color.Silver;
            this.btnLensMagazine.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensMagazine.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensMagazine.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensMagazine.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensMagazine.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensMagazine.Location = new System.Drawing.Point(45, 93);
            this.btnLensMagazine.Name = "btnLensMagazine";
            this.btnLensMagazine.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensMagazine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensMagazine.ShineColor = System.Drawing.Color.Silver;
            this.btnLensMagazine.Size = new System.Drawing.Size(158, 50);
            this.btnLensMagazine.TabIndex = 1511;
            this.btnLensMagazine.TabStop = false;
            this.btnLensMagazine.Tag = "0";
            this.btnLensMagazine.Text = "LENS INSERT";
            this.btnLensMagazine.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // lbLensMagazine
            // 
            this.lbLensMagazine.BackColor = System.Drawing.Color.White;
            this.lbLensMagazine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensMagazine.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lbLensMagazine.ForeColor = System.Drawing.Color.Black;
            this.lbLensMagazine.Location = new System.Drawing.Point(238, 94);
            this.lbLensMagazine.Name = "lbLensMagazine";
            this.lbLensMagazine.Size = new System.Drawing.Size(156, 50);
            this.lbLensMagazine.TabIndex = 1512;
            this.lbLensMagazine.Text = "From Top/Bottom";
            this.lbLensMagazine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbMachineOption
            // 
            this.gbMachineOption.Controls.Add(this.groupBox5);
            this.gbMachineOption.Controls.Add(this.groupBox1);
            this.gbMachineOption.Controls.Add(this.gbRunOption);
            this.gbMachineOption.Location = new System.Drawing.Point(12, 18);
            this.gbMachineOption.Name = "gbMachineOption";
            this.gbMachineOption.Size = new System.Drawing.Size(465, 722);
            this.gbMachineOption.TabIndex = 1502;
            this.gbMachineOption.TabStop = false;
            this.gbMachineOption.Text = "Machine Option";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbAlCooling2);
            this.groupBox5.Controls.Add(this.lbAlCooling1);
            this.groupBox5.Controls.Add(this.btnUseCooling2);
            this.groupBox5.Controls.Add(this.btnUseCooling1);
            this.groupBox5.Controls.Add(this.lbUseDummy2);
            this.groupBox5.Controls.Add(this.lbUseDummy1);
            this.groupBox5.Controls.Add(this.btnUseDummy2);
            this.groupBox5.Controls.Add(this.btnUseDummy1);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.lblDummyPeriodCount2);
            this.groupBox5.Controls.Add(this.lblDummyPeriodCount1);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.lbUsePlusenum_2);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.btnUsePlusenum_2);
            this.groupBox5.Controls.Add(this.lbUsePlusenum_1);
            this.groupBox5.Controls.Add(this.btnUsePlusenum_1);
            this.groupBox5.Controls.Add(this.lblDummyTime2);
            this.groupBox5.Controls.Add(this.btnJettingMode_2);
            this.groupBox5.Controls.Add(this.btnJettingMode_1);
            this.groupBox5.Controls.Add(this.lblUseTipClean2);
            this.groupBox5.Controls.Add(this.lblDummyTime1);
            this.groupBox5.Controls.Add(this.lbUseIdle2);
            this.groupBox5.Controls.Add(this.lblUseTipClean1);
            this.groupBox5.Controls.Add(this.lbUseIdle1);
            this.groupBox5.Controls.Add(this.btnUseTipClean2);
            this.groupBox5.Controls.Add(this.btnUseIdle2);
            this.groupBox5.Controls.Add(this.btnUseTipClean1);
            this.groupBox5.Controls.Add(this.btnUseIdle1);
            this.groupBox5.Location = new System.Drawing.Point(6, 199);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(450, 523);
            this.groupBox5.TabIndex = 1506;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Dispenser Option";
            // 
            // lbAlCooling2
            // 
            this.lbAlCooling2.BackColor = System.Drawing.Color.Lime;
            this.lbAlCooling2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlCooling2.Location = new System.Drawing.Point(247, 310);
            this.lbAlCooling2.Name = "lbAlCooling2";
            this.lbAlCooling2.Size = new System.Drawing.Size(15, 49);
            this.lbAlCooling2.TabIndex = 1541;
            // 
            // lbAlCooling1
            // 
            this.lbAlCooling1.BackColor = System.Drawing.Color.Lime;
            this.lbAlCooling1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlCooling1.Location = new System.Drawing.Point(18, 309);
            this.lbAlCooling1.Name = "lbAlCooling1";
            this.lbAlCooling1.Size = new System.Drawing.Size(15, 49);
            this.lbAlCooling1.TabIndex = 1542;
            // 
            // btnUseCooling2
            // 
            this.btnUseCooling2.BackColor = System.Drawing.Color.Silver;
            this.btnUseCooling2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCooling2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCooling2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCooling2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCooling2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCooling2.Location = new System.Drawing.Point(268, 310);
            this.btnUseCooling2.Name = "btnUseCooling2";
            this.btnUseCooling2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCooling2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCooling2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCooling2.Size = new System.Drawing.Size(158, 49);
            this.btnUseCooling2.TabIndex = 1539;
            this.btnUseCooling2.TabStop = false;
            this.btnUseCooling2.Tag = "0";
            this.btnUseCooling2.Text = "Always Cooling #2";
            this.btnUseCooling2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseCooling1
            // 
            this.btnUseCooling1.BackColor = System.Drawing.Color.Silver;
            this.btnUseCooling1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCooling1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCooling1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCooling1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCooling1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCooling1.Location = new System.Drawing.Point(39, 309);
            this.btnUseCooling1.Name = "btnUseCooling1";
            this.btnUseCooling1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCooling1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCooling1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCooling1.Size = new System.Drawing.Size(158, 49);
            this.btnUseCooling1.TabIndex = 1540;
            this.btnUseCooling1.TabStop = false;
            this.btnUseCooling1.Tag = "0";
            this.btnUseCooling1.Text = "Always Cooling #1";
            this.btnUseCooling1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseDummy2
            // 
            this.lbUseDummy2.BackColor = System.Drawing.Color.Lime;
            this.lbUseDummy2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseDummy2.Location = new System.Drawing.Point(248, 253);
            this.lbUseDummy2.Name = "lbUseDummy2";
            this.lbUseDummy2.Size = new System.Drawing.Size(15, 49);
            this.lbUseDummy2.TabIndex = 1537;
            // 
            // lbUseDummy1
            // 
            this.lbUseDummy1.BackColor = System.Drawing.Color.Lime;
            this.lbUseDummy1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseDummy1.Location = new System.Drawing.Point(19, 252);
            this.lbUseDummy1.Name = "lbUseDummy1";
            this.lbUseDummy1.Size = new System.Drawing.Size(15, 49);
            this.lbUseDummy1.TabIndex = 1538;
            // 
            // btnUseDummy2
            // 
            this.btnUseDummy2.BackColor = System.Drawing.Color.Silver;
            this.btnUseDummy2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseDummy2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseDummy2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseDummy2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseDummy2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseDummy2.Location = new System.Drawing.Point(269, 253);
            this.btnUseDummy2.Name = "btnUseDummy2";
            this.btnUseDummy2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseDummy2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseDummy2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseDummy2.Size = new System.Drawing.Size(158, 49);
            this.btnUseDummy2.TabIndex = 1535;
            this.btnUseDummy2.TabStop = false;
            this.btnUseDummy2.Tag = "0";
            this.btnUseDummy2.Text = "USE Dummy #2";
            this.btnUseDummy2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseDummy1
            // 
            this.btnUseDummy1.BackColor = System.Drawing.Color.Silver;
            this.btnUseDummy1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseDummy1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseDummy1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseDummy1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseDummy1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseDummy1.Location = new System.Drawing.Point(40, 252);
            this.btnUseDummy1.Name = "btnUseDummy1";
            this.btnUseDummy1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseDummy1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseDummy1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseDummy1.Size = new System.Drawing.Size(158, 49);
            this.btnUseDummy1.TabIndex = 1536;
            this.btnUseDummy1.TabStop = false;
            this.btnUseDummy1.Tag = "0";
            this.btnUseDummy1.Text = "USE Dummy #1";
            this.btnUseDummy1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(247, 364);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 35);
            this.label1.TabIndex = 1531;
            this.label1.Text = "#2 Dummy Period Count";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(18, 364);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 35);
            this.label2.TabIndex = 1532;
            this.label2.Text = "#1 Dummy Period Count";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDummyPeriodCount2
            // 
            this.lblDummyPeriodCount2.BackColor = System.Drawing.Color.White;
            this.lblDummyPeriodCount2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDummyPeriodCount2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDummyPeriodCount2.ForeColor = System.Drawing.Color.Black;
            this.lblDummyPeriodCount2.Location = new System.Drawing.Point(247, 403);
            this.lblDummyPeriodCount2.Name = "lblDummyPeriodCount2";
            this.lblDummyPeriodCount2.Size = new System.Drawing.Size(180, 35);
            this.lblDummyPeriodCount2.TabIndex = 1533;
            this.lblDummyPeriodCount2.Text = "3";
            this.lblDummyPeriodCount2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDummyPeriodCount2.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lblDummyPeriodCount1
            // 
            this.lblDummyPeriodCount1.BackColor = System.Drawing.Color.White;
            this.lblDummyPeriodCount1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDummyPeriodCount1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDummyPeriodCount1.ForeColor = System.Drawing.Color.Black;
            this.lblDummyPeriodCount1.Location = new System.Drawing.Point(18, 403);
            this.lblDummyPeriodCount1.Name = "lblDummyPeriodCount1";
            this.lblDummyPeriodCount1.Size = new System.Drawing.Size(179, 35);
            this.lblDummyPeriodCount1.TabIndex = 1534;
            this.lblDummyPeriodCount1.Text = "1";
            this.lblDummyPeriodCount1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDummyPeriodCount1.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(247, 442);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(180, 35);
            this.label15.TabIndex = 1529;
            this.label15.Text = "#2 Dummy Time";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbUsePlusenum_2
            // 
            this.lbUsePlusenum_2.BackColor = System.Drawing.Color.Lime;
            this.lbUsePlusenum_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUsePlusenum_2.Location = new System.Drawing.Point(248, 140);
            this.lbUsePlusenum_2.Name = "lbUsePlusenum_2";
            this.lbUsePlusenum_2.Size = new System.Drawing.Size(15, 49);
            this.lbUsePlusenum_2.TabIndex = 1526;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(18, 442);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 35);
            this.label10.TabIndex = 1529;
            this.label10.Text = "#1 Dummy Time";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnUsePlusenum_2
            // 
            this.btnUsePlusenum_2.BackColor = System.Drawing.Color.Silver;
            this.btnUsePlusenum_2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUsePlusenum_2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUsePlusenum_2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUsePlusenum_2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUsePlusenum_2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUsePlusenum_2.Location = new System.Drawing.Point(269, 140);
            this.btnUsePlusenum_2.Name = "btnUsePlusenum_2";
            this.btnUsePlusenum_2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUsePlusenum_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUsePlusenum_2.ShineColor = System.Drawing.Color.Silver;
            this.btnUsePlusenum_2.Size = new System.Drawing.Size(158, 49);
            this.btnUsePlusenum_2.TabIndex = 1525;
            this.btnUsePlusenum_2.TabStop = false;
            this.btnUsePlusenum_2.Tag = "0";
            this.btnUsePlusenum_2.Text = "USE PLUSENUM #2";
            this.btnUsePlusenum_2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUsePlusenum_1
            // 
            this.lbUsePlusenum_1.BackColor = System.Drawing.Color.Lime;
            this.lbUsePlusenum_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUsePlusenum_1.Location = new System.Drawing.Point(19, 138);
            this.lbUsePlusenum_1.Name = "lbUsePlusenum_1";
            this.lbUsePlusenum_1.Size = new System.Drawing.Size(15, 49);
            this.lbUsePlusenum_1.TabIndex = 1524;
            // 
            // btnUsePlusenum_1
            // 
            this.btnUsePlusenum_1.BackColor = System.Drawing.Color.Silver;
            this.btnUsePlusenum_1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUsePlusenum_1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUsePlusenum_1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUsePlusenum_1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUsePlusenum_1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUsePlusenum_1.Location = new System.Drawing.Point(40, 139);
            this.btnUsePlusenum_1.Name = "btnUsePlusenum_1";
            this.btnUsePlusenum_1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUsePlusenum_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUsePlusenum_1.ShineColor = System.Drawing.Color.Silver;
            this.btnUsePlusenum_1.Size = new System.Drawing.Size(158, 49);
            this.btnUsePlusenum_1.TabIndex = 1523;
            this.btnUsePlusenum_1.TabStop = false;
            this.btnUsePlusenum_1.Tag = "0";
            this.btnUsePlusenum_1.Text = "USE PLUSENUM #1";
            this.btnUsePlusenum_1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblDummyTime2
            // 
            this.lblDummyTime2.BackColor = System.Drawing.Color.White;
            this.lblDummyTime2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDummyTime2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDummyTime2.ForeColor = System.Drawing.Color.Black;
            this.lblDummyTime2.Location = new System.Drawing.Point(247, 481);
            this.lblDummyTime2.Name = "lblDummyTime2";
            this.lblDummyTime2.Size = new System.Drawing.Size(180, 35);
            this.lblDummyTime2.TabIndex = 1530;
            this.lblDummyTime2.Text = "4";
            this.lblDummyTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDummyTime2.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // btnJettingMode_2
            // 
            this.btnJettingMode_2.BackColor = System.Drawing.Color.Silver;
            this.btnJettingMode_2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnJettingMode_2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnJettingMode_2.GlowColor = System.Drawing.Color.Transparent;
            this.btnJettingMode_2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnJettingMode_2.InnerBorderColor = System.Drawing.Color.White;
            this.btnJettingMode_2.Location = new System.Drawing.Point(269, 23);
            this.btnJettingMode_2.Name = "btnJettingMode_2";
            this.btnJettingMode_2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnJettingMode_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnJettingMode_2.ShineColor = System.Drawing.Color.Silver;
            this.btnJettingMode_2.Size = new System.Drawing.Size(158, 49);
            this.btnJettingMode_2.TabIndex = 1522;
            this.btnJettingMode_2.TabStop = false;
            this.btnJettingMode_2.Tag = "0";
            this.btnJettingMode_2.Text = "POINT #2";
            this.btnJettingMode_2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnJettingMode_1
            // 
            this.btnJettingMode_1.BackColor = System.Drawing.Color.Silver;
            this.btnJettingMode_1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnJettingMode_1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnJettingMode_1.GlowColor = System.Drawing.Color.Transparent;
            this.btnJettingMode_1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnJettingMode_1.InnerBorderColor = System.Drawing.Color.White;
            this.btnJettingMode_1.Location = new System.Drawing.Point(40, 23);
            this.btnJettingMode_1.Name = "btnJettingMode_1";
            this.btnJettingMode_1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnJettingMode_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnJettingMode_1.ShineColor = System.Drawing.Color.Silver;
            this.btnJettingMode_1.Size = new System.Drawing.Size(158, 49);
            this.btnJettingMode_1.TabIndex = 1522;
            this.btnJettingMode_1.TabStop = false;
            this.btnJettingMode_1.Tag = "0";
            this.btnJettingMode_1.Text = "POINT #1";
            this.btnJettingMode_1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lblUseTipClean2
            // 
            this.lblUseTipClean2.BackColor = System.Drawing.Color.Lime;
            this.lblUseTipClean2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseTipClean2.Location = new System.Drawing.Point(248, 196);
            this.lblUseTipClean2.Name = "lblUseTipClean2";
            this.lblUseTipClean2.Size = new System.Drawing.Size(15, 49);
            this.lblUseTipClean2.TabIndex = 1521;
            // 
            // lblDummyTime1
            // 
            this.lblDummyTime1.BackColor = System.Drawing.Color.White;
            this.lblDummyTime1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDummyTime1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDummyTime1.ForeColor = System.Drawing.Color.Black;
            this.lblDummyTime1.Location = new System.Drawing.Point(19, 481);
            this.lblDummyTime1.Name = "lblDummyTime1";
            this.lblDummyTime1.Size = new System.Drawing.Size(178, 35);
            this.lblDummyTime1.TabIndex = 1530;
            this.lblDummyTime1.Text = "2";
            this.lblDummyTime1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDummyTime1.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbUseIdle2
            // 
            this.lbUseIdle2.BackColor = System.Drawing.Color.Lime;
            this.lbUseIdle2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseIdle2.Location = new System.Drawing.Point(248, 80);
            this.lbUseIdle2.Name = "lbUseIdle2";
            this.lbUseIdle2.Size = new System.Drawing.Size(15, 49);
            this.lbUseIdle2.TabIndex = 1521;
            // 
            // lblUseTipClean1
            // 
            this.lblUseTipClean1.BackColor = System.Drawing.Color.Lime;
            this.lblUseTipClean1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUseTipClean1.Location = new System.Drawing.Point(19, 195);
            this.lblUseTipClean1.Name = "lblUseTipClean1";
            this.lblUseTipClean1.Size = new System.Drawing.Size(15, 49);
            this.lblUseTipClean1.TabIndex = 1521;
            // 
            // lbUseIdle1
            // 
            this.lbUseIdle1.BackColor = System.Drawing.Color.Lime;
            this.lbUseIdle1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseIdle1.Location = new System.Drawing.Point(19, 80);
            this.lbUseIdle1.Name = "lbUseIdle1";
            this.lbUseIdle1.Size = new System.Drawing.Size(15, 49);
            this.lbUseIdle1.TabIndex = 1521;
            // 
            // btnUseTipClean2
            // 
            this.btnUseTipClean2.BackColor = System.Drawing.Color.Silver;
            this.btnUseTipClean2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseTipClean2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseTipClean2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseTipClean2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseTipClean2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseTipClean2.Location = new System.Drawing.Point(269, 196);
            this.btnUseTipClean2.Name = "btnUseTipClean2";
            this.btnUseTipClean2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseTipClean2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseTipClean2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseTipClean2.Size = new System.Drawing.Size(158, 49);
            this.btnUseTipClean2.TabIndex = 1509;
            this.btnUseTipClean2.TabStop = false;
            this.btnUseTipClean2.Tag = "0";
            this.btnUseTipClean2.Text = "USE TIP CLEAN #2";
            this.btnUseTipClean2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseIdle2
            // 
            this.btnUseIdle2.BackColor = System.Drawing.Color.Silver;
            this.btnUseIdle2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseIdle2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseIdle2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseIdle2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseIdle2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseIdle2.Location = new System.Drawing.Point(269, 80);
            this.btnUseIdle2.Name = "btnUseIdle2";
            this.btnUseIdle2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseIdle2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseIdle2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseIdle2.Size = new System.Drawing.Size(158, 49);
            this.btnUseIdle2.TabIndex = 1509;
            this.btnUseIdle2.TabStop = false;
            this.btnUseIdle2.Tag = "0";
            this.btnUseIdle2.Text = "USE IDLE #2";
            this.btnUseIdle2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseTipClean1
            // 
            this.btnUseTipClean1.BackColor = System.Drawing.Color.Silver;
            this.btnUseTipClean1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseTipClean1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseTipClean1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseTipClean1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseTipClean1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseTipClean1.Location = new System.Drawing.Point(40, 196);
            this.btnUseTipClean1.Name = "btnUseTipClean1";
            this.btnUseTipClean1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseTipClean1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseTipClean1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseTipClean1.Size = new System.Drawing.Size(158, 49);
            this.btnUseTipClean1.TabIndex = 1509;
            this.btnUseTipClean1.TabStop = false;
            this.btnUseTipClean1.Tag = "0";
            this.btnUseTipClean1.Text = "USE TIP CLEAN #1";
            this.btnUseTipClean1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseIdle1
            // 
            this.btnUseIdle1.BackColor = System.Drawing.Color.Silver;
            this.btnUseIdle1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseIdle1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseIdle1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseIdle1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseIdle1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseIdle1.Location = new System.Drawing.Point(40, 80);
            this.btnUseIdle1.Name = "btnUseIdle1";
            this.btnUseIdle1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseIdle1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseIdle1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseIdle1.Size = new System.Drawing.Size(158, 49);
            this.btnUseIdle1.TabIndex = 1509;
            this.btnUseIdle1.TabStop = false;
            this.btnUseIdle1.Tag = "0";
            this.btnUseIdle1.Text = "USE IDLE #1";
            this.btnUseIdle1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLensHeightReslut);
            this.groupBox1.Controls.Add(this.lbVisionResult);
            this.groupBox1.Controls.Add(this.lbLensHeightResult);
            this.groupBox1.Controls.Add(this.btnVisionResult);
            this.groupBox1.Controls.Add(this.btnJigPlateAngleResult);
            this.groupBox1.Controls.Add(this.btnSideAngleResult);
            this.groupBox1.Controls.Add(this.lbSideAngleResult);
            this.groupBox1.Controls.Add(this.lbJigFlatnessResult);
            this.groupBox1.Location = new System.Drawing.Point(9, 904);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 136);
            this.groupBox1.TabIndex = 1499;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Result Option";
            this.groupBox1.Visible = false;
            // 
            // btnLensHeightReslut
            // 
            this.btnLensHeightReslut.BackColor = System.Drawing.Color.Silver;
            this.btnLensHeightReslut.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensHeightReslut.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensHeightReslut.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensHeightReslut.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensHeightReslut.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensHeightReslut.Location = new System.Drawing.Point(259, 28);
            this.btnLensHeightReslut.Name = "btnLensHeightReslut";
            this.btnLensHeightReslut.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensHeightReslut.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensHeightReslut.ShineColor = System.Drawing.Color.Silver;
            this.btnLensHeightReslut.Size = new System.Drawing.Size(158, 45);
            this.btnLensHeightReslut.TabIndex = 1513;
            this.btnLensHeightReslut.TabStop = false;
            this.btnLensHeightReslut.Tag = "0";
            this.btnLensHeightReslut.Text = "LENS HEIGHT RESULT";
            this.btnLensHeightReslut.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbVisionResult
            // 
            this.lbVisionResult.BackColor = System.Drawing.Color.Lime;
            this.lbVisionResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVisionResult.Location = new System.Drawing.Point(29, 28);
            this.lbVisionResult.Name = "lbVisionResult";
            this.lbVisionResult.Size = new System.Drawing.Size(15, 45);
            this.lbVisionResult.TabIndex = 1510;
            // 
            // lbLensHeightResult
            // 
            this.lbLensHeightResult.BackColor = System.Drawing.Color.Lime;
            this.lbLensHeightResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensHeightResult.Location = new System.Drawing.Point(238, 28);
            this.lbLensHeightResult.Name = "lbLensHeightResult";
            this.lbLensHeightResult.Size = new System.Drawing.Size(15, 45);
            this.lbLensHeightResult.TabIndex = 1514;
            // 
            // btnVisionResult
            // 
            this.btnVisionResult.BackColor = System.Drawing.Color.Silver;
            this.btnVisionResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnVisionResult.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnVisionResult.GlowColor = System.Drawing.Color.Transparent;
            this.btnVisionResult.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVisionResult.InnerBorderColor = System.Drawing.Color.White;
            this.btnVisionResult.Location = new System.Drawing.Point(50, 28);
            this.btnVisionResult.Name = "btnVisionResult";
            this.btnVisionResult.OuterBorderColor = System.Drawing.Color.Black;
            this.btnVisionResult.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnVisionResult.ShineColor = System.Drawing.Color.Silver;
            this.btnVisionResult.Size = new System.Drawing.Size(158, 45);
            this.btnVisionResult.TabIndex = 1509;
            this.btnVisionResult.TabStop = false;
            this.btnVisionResult.Tag = "0";
            this.btnVisionResult.Text = "VISION RESULT";
            this.btnVisionResult.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnJigPlateAngleResult
            // 
            this.btnJigPlateAngleResult.BackColor = System.Drawing.Color.Silver;
            this.btnJigPlateAngleResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnJigPlateAngleResult.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnJigPlateAngleResult.GlowColor = System.Drawing.Color.Transparent;
            this.btnJigPlateAngleResult.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnJigPlateAngleResult.InnerBorderColor = System.Drawing.Color.White;
            this.btnJigPlateAngleResult.Location = new System.Drawing.Point(50, 79);
            this.btnJigPlateAngleResult.Name = "btnJigPlateAngleResult";
            this.btnJigPlateAngleResult.OuterBorderColor = System.Drawing.Color.Black;
            this.btnJigPlateAngleResult.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnJigPlateAngleResult.ShineColor = System.Drawing.Color.Silver;
            this.btnJigPlateAngleResult.Size = new System.Drawing.Size(158, 45);
            this.btnJigPlateAngleResult.TabIndex = 1511;
            this.btnJigPlateAngleResult.TabStop = false;
            this.btnJigPlateAngleResult.Tag = "0";
            this.btnJigPlateAngleResult.Text = "JIG FLATNESS RESULT";
            this.btnJigPlateAngleResult.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnSideAngleResult
            // 
            this.btnSideAngleResult.BackColor = System.Drawing.Color.Silver;
            this.btnSideAngleResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSideAngleResult.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSideAngleResult.GlowColor = System.Drawing.Color.Transparent;
            this.btnSideAngleResult.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSideAngleResult.InnerBorderColor = System.Drawing.Color.White;
            this.btnSideAngleResult.Location = new System.Drawing.Point(259, 79);
            this.btnSideAngleResult.Name = "btnSideAngleResult";
            this.btnSideAngleResult.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSideAngleResult.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSideAngleResult.ShineColor = System.Drawing.Color.Silver;
            this.btnSideAngleResult.Size = new System.Drawing.Size(158, 45);
            this.btnSideAngleResult.TabIndex = 1515;
            this.btnSideAngleResult.TabStop = false;
            this.btnSideAngleResult.Tag = "0";
            this.btnSideAngleResult.Text = "SIDE ANGLE RESULT";
            this.btnSideAngleResult.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbSideAngleResult
            // 
            this.lbSideAngleResult.BackColor = System.Drawing.Color.Lime;
            this.lbSideAngleResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbSideAngleResult.Location = new System.Drawing.Point(238, 79);
            this.lbSideAngleResult.Name = "lbSideAngleResult";
            this.lbSideAngleResult.Size = new System.Drawing.Size(15, 45);
            this.lbSideAngleResult.TabIndex = 1516;
            // 
            // lbJigFlatnessResult
            // 
            this.lbJigFlatnessResult.BackColor = System.Drawing.Color.Lime;
            this.lbJigFlatnessResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbJigFlatnessResult.Location = new System.Drawing.Point(29, 79);
            this.lbJigFlatnessResult.Name = "lbJigFlatnessResult";
            this.lbJigFlatnessResult.Size = new System.Drawing.Size(15, 45);
            this.lbJigFlatnessResult.TabIndex = 1512;
            // 
            // gbRunOption
            // 
            this.gbRunOption.Controls.Add(this.btnVisionCheck);
            this.gbRunOption.Controls.Add(this.lbVisionCheck);
            this.gbRunOption.Controls.Add(this.btnIndexCheck);
            this.gbRunOption.Controls.Add(this.lbVacuumCheck);
            this.gbRunOption.Controls.Add(this.lbIndexCheck);
            this.gbRunOption.Controls.Add(this.btnVacuumCheck);
            this.gbRunOption.Controls.Add(this.btnTrayCheck);
            this.gbRunOption.Controls.Add(this.lbTrayCheck);
            this.gbRunOption.Location = new System.Drawing.Point(6, 26);
            this.gbRunOption.Name = "gbRunOption";
            this.gbRunOption.Size = new System.Drawing.Size(450, 167);
            this.gbRunOption.TabIndex = 1498;
            this.gbRunOption.TabStop = false;
            this.gbRunOption.Text = "Dry Run Option";
            // 
            // btnVisionCheck
            // 
            this.btnVisionCheck.BackColor = System.Drawing.Color.Silver;
            this.btnVisionCheck.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnVisionCheck.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnVisionCheck.GlowColor = System.Drawing.Color.Transparent;
            this.btnVisionCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVisionCheck.InnerBorderColor = System.Drawing.Color.White;
            this.btnVisionCheck.Location = new System.Drawing.Point(270, 100);
            this.btnVisionCheck.Name = "btnVisionCheck";
            this.btnVisionCheck.OuterBorderColor = System.Drawing.Color.Black;
            this.btnVisionCheck.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnVisionCheck.ShineColor = System.Drawing.Color.Silver;
            this.btnVisionCheck.Size = new System.Drawing.Size(158, 54);
            this.btnVisionCheck.TabIndex = 1515;
            this.btnVisionCheck.TabStop = false;
            this.btnVisionCheck.Tag = "0";
            this.btnVisionCheck.Text = "VISION CHECK";
            this.btnVisionCheck.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbVisionCheck
            // 
            this.lbVisionCheck.BackColor = System.Drawing.Color.Lime;
            this.lbVisionCheck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVisionCheck.Location = new System.Drawing.Point(249, 100);
            this.lbVisionCheck.Name = "lbVisionCheck";
            this.lbVisionCheck.Size = new System.Drawing.Size(15, 54);
            this.lbVisionCheck.TabIndex = 1516;
            // 
            // btnIndexCheck
            // 
            this.btnIndexCheck.BackColor = System.Drawing.Color.Silver;
            this.btnIndexCheck.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnIndexCheck.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnIndexCheck.GlowColor = System.Drawing.Color.Transparent;
            this.btnIndexCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIndexCheck.InnerBorderColor = System.Drawing.Color.White;
            this.btnIndexCheck.Location = new System.Drawing.Point(270, 36);
            this.btnIndexCheck.Name = "btnIndexCheck";
            this.btnIndexCheck.OuterBorderColor = System.Drawing.Color.Black;
            this.btnIndexCheck.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnIndexCheck.ShineColor = System.Drawing.Color.Silver;
            this.btnIndexCheck.Size = new System.Drawing.Size(158, 54);
            this.btnIndexCheck.TabIndex = 1513;
            this.btnIndexCheck.TabStop = false;
            this.btnIndexCheck.Tag = "0";
            this.btnIndexCheck.Text = "INDEX CHECK";
            this.btnIndexCheck.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbVacuumCheck
            // 
            this.lbVacuumCheck.BackColor = System.Drawing.Color.Lime;
            this.lbVacuumCheck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVacuumCheck.Location = new System.Drawing.Point(19, 36);
            this.lbVacuumCheck.Name = "lbVacuumCheck";
            this.lbVacuumCheck.Size = new System.Drawing.Size(15, 54);
            this.lbVacuumCheck.TabIndex = 1510;
            // 
            // lbIndexCheck
            // 
            this.lbIndexCheck.BackColor = System.Drawing.Color.Lime;
            this.lbIndexCheck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbIndexCheck.Location = new System.Drawing.Point(249, 36);
            this.lbIndexCheck.Name = "lbIndexCheck";
            this.lbIndexCheck.Size = new System.Drawing.Size(15, 54);
            this.lbIndexCheck.TabIndex = 1514;
            // 
            // btnVacuumCheck
            // 
            this.btnVacuumCheck.BackColor = System.Drawing.Color.Silver;
            this.btnVacuumCheck.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnVacuumCheck.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnVacuumCheck.GlowColor = System.Drawing.Color.Transparent;
            this.btnVacuumCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVacuumCheck.InnerBorderColor = System.Drawing.Color.White;
            this.btnVacuumCheck.Location = new System.Drawing.Point(40, 36);
            this.btnVacuumCheck.Name = "btnVacuumCheck";
            this.btnVacuumCheck.OuterBorderColor = System.Drawing.Color.Black;
            this.btnVacuumCheck.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnVacuumCheck.ShineColor = System.Drawing.Color.Silver;
            this.btnVacuumCheck.Size = new System.Drawing.Size(158, 54);
            this.btnVacuumCheck.TabIndex = 1509;
            this.btnVacuumCheck.TabStop = false;
            this.btnVacuumCheck.Tag = "0";
            this.btnVacuumCheck.Text = "VACUUM CHECK";
            this.btnVacuumCheck.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnTrayCheck
            // 
            this.btnTrayCheck.BackColor = System.Drawing.Color.Silver;
            this.btnTrayCheck.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnTrayCheck.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnTrayCheck.GlowColor = System.Drawing.Color.Transparent;
            this.btnTrayCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTrayCheck.InnerBorderColor = System.Drawing.Color.White;
            this.btnTrayCheck.Location = new System.Drawing.Point(40, 100);
            this.btnTrayCheck.Name = "btnTrayCheck";
            this.btnTrayCheck.OuterBorderColor = System.Drawing.Color.Black;
            this.btnTrayCheck.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnTrayCheck.ShineColor = System.Drawing.Color.Silver;
            this.btnTrayCheck.Size = new System.Drawing.Size(158, 54);
            this.btnTrayCheck.TabIndex = 1511;
            this.btnTrayCheck.TabStop = false;
            this.btnTrayCheck.Tag = "0";
            this.btnTrayCheck.Text = "TRAY CHECK";
            this.btnTrayCheck.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbTrayCheck
            // 
            this.lbTrayCheck.BackColor = System.Drawing.Color.Lime;
            this.lbTrayCheck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTrayCheck.Location = new System.Drawing.Point(19, 100);
            this.lbTrayCheck.Name = "lbTrayCheck";
            this.lbTrayCheck.Size = new System.Drawing.Size(15, 54);
            this.lbTrayCheck.TabIndex = 1512;
            // 
            // gbSequenceOption
            // 
            this.gbSequenceOption.Controls.Add(this.btnUseAct3);
            this.gbSequenceOption.Controls.Add(this.lbUseAct3);
            this.gbSequenceOption.Controls.Add(this.btnUseLensPicker);
            this.gbSequenceOption.Controls.Add(this.lbUseLensPicker);
            this.gbSequenceOption.Controls.Add(this.btnUseCureVisionFail);
            this.gbSequenceOption.Controls.Add(this.lbUseCureVisionFail);
            this.gbSequenceOption.Controls.Add(this.btnUseBonder2);
            this.gbSequenceOption.Controls.Add(this.btnUseCuring2);
            this.gbSequenceOption.Controls.Add(this.lbUseCuring2);
            this.gbSequenceOption.Controls.Add(this.lbUseBonder2);
            this.gbSequenceOption.Controls.Add(this.btnUseBonder1);
            this.gbSequenceOption.Controls.Add(this.btnUseCuring1);
            this.gbSequenceOption.Controls.Add(this.lbUseCuring1);
            this.gbSequenceOption.Controls.Add(this.lbUseBonder1);
            this.gbSequenceOption.Controls.Add(this.btnUseVision);
            this.gbSequenceOption.Controls.Add(this.lbUseVision);
            this.gbSequenceOption.Controls.Add(this.btnUsePlateAngle);
            this.gbSequenceOption.Controls.Add(this.lbUseJigPlateAngle);
            this.gbSequenceOption.Controls.Add(this.lbUsePlateAngle);
            this.gbSequenceOption.Controls.Add(this.btnUseJigPlateAngle);
            this.gbSequenceOption.Controls.Add(this.btnUseCleanJig);
            this.gbSequenceOption.Controls.Add(this.btnUseLensHeight);
            this.gbSequenceOption.Controls.Add(this.lbUseLensHeight);
            this.gbSequenceOption.Controls.Add(this.lbUseCleanJig);
            this.gbSequenceOption.Location = new System.Drawing.Point(483, 18);
            this.gbSequenceOption.Name = "gbSequenceOption";
            this.gbSequenceOption.Size = new System.Drawing.Size(469, 385);
            this.gbSequenceOption.TabIndex = 1501;
            this.gbSequenceOption.TabStop = false;
            this.gbSequenceOption.Text = "Sequence Option";
            this.gbSequenceOption.Enter += new System.EventHandler(this.gbSequenceOption_Enter);
            // 
            // btnUseAct3
            // 
            this.btnUseAct3.BackColor = System.Drawing.Color.Silver;
            this.btnUseAct3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseAct3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseAct3.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseAct3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseAct3.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseAct3.Location = new System.Drawing.Point(283, 317);
            this.btnUseAct3.Name = "btnUseAct3";
            this.btnUseAct3.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseAct3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseAct3.ShineColor = System.Drawing.Color.Silver;
            this.btnUseAct3.Size = new System.Drawing.Size(158, 50);
            this.btnUseAct3.TabIndex = 1525;
            this.btnUseAct3.TabStop = false;
            this.btnUseAct3.Tag = "0";
            this.btnUseAct3.Text = "USE ACT #3";
            this.btnUseAct3.Visible = false;
            this.btnUseAct3.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseAct3
            // 
            this.lbUseAct3.BackColor = System.Drawing.Color.Lime;
            this.lbUseAct3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseAct3.Location = new System.Drawing.Point(262, 317);
            this.lbUseAct3.Name = "lbUseAct3";
            this.lbUseAct3.Size = new System.Drawing.Size(15, 50);
            this.lbUseAct3.TabIndex = 1526;
            this.lbUseAct3.Visible = false;
            // 
            // btnUseLensPicker
            // 
            this.btnUseLensPicker.BackColor = System.Drawing.Color.Silver;
            this.btnUseLensPicker.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseLensPicker.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseLensPicker.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseLensPicker.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseLensPicker.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseLensPicker.Location = new System.Drawing.Point(43, 318);
            this.btnUseLensPicker.Name = "btnUseLensPicker";
            this.btnUseLensPicker.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseLensPicker.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseLensPicker.ShineColor = System.Drawing.Color.Silver;
            this.btnUseLensPicker.Size = new System.Drawing.Size(158, 50);
            this.btnUseLensPicker.TabIndex = 1523;
            this.btnUseLensPicker.TabStop = false;
            this.btnUseLensPicker.Tag = "0";
            this.btnUseLensPicker.Text = "USE LENS PICKER";
            this.btnUseLensPicker.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseLensPicker
            // 
            this.lbUseLensPicker.BackColor = System.Drawing.Color.Lime;
            this.lbUseLensPicker.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseLensPicker.Location = new System.Drawing.Point(22, 318);
            this.lbUseLensPicker.Name = "lbUseLensPicker";
            this.lbUseLensPicker.Size = new System.Drawing.Size(15, 50);
            this.lbUseLensPicker.TabIndex = 1524;
            // 
            // btnUseCureVisionFail
            // 
            this.btnUseCureVisionFail.BackColor = System.Drawing.Color.Silver;
            this.btnUseCureVisionFail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCureVisionFail.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCureVisionFail.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCureVisionFail.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCureVisionFail.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCureVisionFail.Location = new System.Drawing.Point(283, 260);
            this.btnUseCureVisionFail.Name = "btnUseCureVisionFail";
            this.btnUseCureVisionFail.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCureVisionFail.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCureVisionFail.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCureVisionFail.Size = new System.Drawing.Size(158, 50);
            this.btnUseCureVisionFail.TabIndex = 1521;
            this.btnUseCureVisionFail.TabStop = false;
            this.btnUseCureVisionFail.Tag = "0";
            this.btnUseCureVisionFail.Text = "USE CURE VISION FAIL";
            this.btnUseCureVisionFail.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseCureVisionFail
            // 
            this.lbUseCureVisionFail.BackColor = System.Drawing.Color.Lime;
            this.lbUseCureVisionFail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseCureVisionFail.Location = new System.Drawing.Point(262, 260);
            this.lbUseCureVisionFail.Name = "lbUseCureVisionFail";
            this.lbUseCureVisionFail.Size = new System.Drawing.Size(15, 50);
            this.lbUseCureVisionFail.TabIndex = 1522;
            // 
            // btnUseBonder2
            // 
            this.btnUseBonder2.BackColor = System.Drawing.Color.Silver;
            this.btnUseBonder2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseBonder2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseBonder2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseBonder2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseBonder2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseBonder2.Location = new System.Drawing.Point(43, 204);
            this.btnUseBonder2.Name = "btnUseBonder2";
            this.btnUseBonder2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseBonder2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseBonder2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseBonder2.Size = new System.Drawing.Size(158, 50);
            this.btnUseBonder2.TabIndex = 1517;
            this.btnUseBonder2.TabStop = false;
            this.btnUseBonder2.Tag = "0";
            this.btnUseBonder2.Text = "USE BONDER #2";
            this.btnUseBonder2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseCuring2
            // 
            this.btnUseCuring2.BackColor = System.Drawing.Color.Silver;
            this.btnUseCuring2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCuring2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCuring2.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCuring2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCuring2.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCuring2.Location = new System.Drawing.Point(283, 203);
            this.btnUseCuring2.Name = "btnUseCuring2";
            this.btnUseCuring2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCuring2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCuring2.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCuring2.Size = new System.Drawing.Size(158, 50);
            this.btnUseCuring2.TabIndex = 1519;
            this.btnUseCuring2.TabStop = false;
            this.btnUseCuring2.Tag = "0";
            this.btnUseCuring2.Text = "USE CURING #2";
            this.btnUseCuring2.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseCuring2
            // 
            this.lbUseCuring2.BackColor = System.Drawing.Color.Lime;
            this.lbUseCuring2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseCuring2.Location = new System.Drawing.Point(262, 203);
            this.lbUseCuring2.Name = "lbUseCuring2";
            this.lbUseCuring2.Size = new System.Drawing.Size(15, 50);
            this.lbUseCuring2.TabIndex = 1520;
            // 
            // lbUseBonder2
            // 
            this.lbUseBonder2.BackColor = System.Drawing.Color.Lime;
            this.lbUseBonder2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseBonder2.Location = new System.Drawing.Point(22, 204);
            this.lbUseBonder2.Name = "lbUseBonder2";
            this.lbUseBonder2.Size = new System.Drawing.Size(15, 50);
            this.lbUseBonder2.TabIndex = 1518;
            // 
            // btnUseBonder1
            // 
            this.btnUseBonder1.BackColor = System.Drawing.Color.Silver;
            this.btnUseBonder1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseBonder1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseBonder1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseBonder1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseBonder1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseBonder1.Location = new System.Drawing.Point(43, 147);
            this.btnUseBonder1.Name = "btnUseBonder1";
            this.btnUseBonder1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseBonder1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseBonder1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseBonder1.Size = new System.Drawing.Size(158, 50);
            this.btnUseBonder1.TabIndex = 1509;
            this.btnUseBonder1.TabStop = false;
            this.btnUseBonder1.Tag = "0";
            this.btnUseBonder1.Text = "USE BONDER #1";
            this.btnUseBonder1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseCuring1
            // 
            this.btnUseCuring1.BackColor = System.Drawing.Color.Silver;
            this.btnUseCuring1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCuring1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCuring1.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCuring1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCuring1.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCuring1.Location = new System.Drawing.Point(283, 146);
            this.btnUseCuring1.Name = "btnUseCuring1";
            this.btnUseCuring1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCuring1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCuring1.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCuring1.Size = new System.Drawing.Size(158, 50);
            this.btnUseCuring1.TabIndex = 1511;
            this.btnUseCuring1.TabStop = false;
            this.btnUseCuring1.Tag = "0";
            this.btnUseCuring1.Text = "USE CURING #1";
            this.btnUseCuring1.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseCuring1
            // 
            this.lbUseCuring1.BackColor = System.Drawing.Color.Lime;
            this.lbUseCuring1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseCuring1.Location = new System.Drawing.Point(262, 146);
            this.lbUseCuring1.Name = "lbUseCuring1";
            this.lbUseCuring1.Size = new System.Drawing.Size(15, 50);
            this.lbUseCuring1.TabIndex = 1512;
            // 
            // lbUseBonder1
            // 
            this.lbUseBonder1.BackColor = System.Drawing.Color.Lime;
            this.lbUseBonder1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseBonder1.Location = new System.Drawing.Point(22, 147);
            this.lbUseBonder1.Name = "lbUseBonder1";
            this.lbUseBonder1.Size = new System.Drawing.Size(15, 50);
            this.lbUseBonder1.TabIndex = 1510;
            // 
            // btnUseVision
            // 
            this.btnUseVision.BackColor = System.Drawing.Color.Silver;
            this.btnUseVision.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseVision.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseVision.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseVision.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseVision.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseVision.Location = new System.Drawing.Point(43, 261);
            this.btnUseVision.Name = "btnUseVision";
            this.btnUseVision.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseVision.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseVision.ShineColor = System.Drawing.Color.Silver;
            this.btnUseVision.Size = new System.Drawing.Size(158, 50);
            this.btnUseVision.TabIndex = 1515;
            this.btnUseVision.TabStop = false;
            this.btnUseVision.Tag = "0";
            this.btnUseVision.Text = "USE VISION";
            this.btnUseVision.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseVision
            // 
            this.lbUseVision.BackColor = System.Drawing.Color.Lime;
            this.lbUseVision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseVision.Location = new System.Drawing.Point(22, 261);
            this.lbUseVision.Name = "lbUseVision";
            this.lbUseVision.Size = new System.Drawing.Size(15, 50);
            this.lbUseVision.TabIndex = 1516;
            // 
            // btnUsePlateAngle
            // 
            this.btnUsePlateAngle.BackColor = System.Drawing.Color.Silver;
            this.btnUsePlateAngle.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUsePlateAngle.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUsePlateAngle.GlowColor = System.Drawing.Color.Transparent;
            this.btnUsePlateAngle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUsePlateAngle.InnerBorderColor = System.Drawing.Color.White;
            this.btnUsePlateAngle.Location = new System.Drawing.Point(283, 32);
            this.btnUsePlateAngle.Name = "btnUsePlateAngle";
            this.btnUsePlateAngle.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUsePlateAngle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUsePlateAngle.ShineColor = System.Drawing.Color.Silver;
            this.btnUsePlateAngle.Size = new System.Drawing.Size(158, 50);
            this.btnUsePlateAngle.TabIndex = 1505;
            this.btnUsePlateAngle.TabStop = false;
            this.btnUsePlateAngle.Tag = "0";
            this.btnUsePlateAngle.Text = "USE SIDE ANGLE";
            this.btnUsePlateAngle.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseJigPlateAngle
            // 
            this.lbUseJigPlateAngle.BackColor = System.Drawing.Color.Lime;
            this.lbUseJigPlateAngle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseJigPlateAngle.Location = new System.Drawing.Point(22, 33);
            this.lbUseJigPlateAngle.Name = "lbUseJigPlateAngle";
            this.lbUseJigPlateAngle.Size = new System.Drawing.Size(15, 50);
            this.lbUseJigPlateAngle.TabIndex = 1500;
            // 
            // lbUsePlateAngle
            // 
            this.lbUsePlateAngle.BackColor = System.Drawing.Color.Lime;
            this.lbUsePlateAngle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUsePlateAngle.Location = new System.Drawing.Point(262, 32);
            this.lbUsePlateAngle.Name = "lbUsePlateAngle";
            this.lbUsePlateAngle.Size = new System.Drawing.Size(15, 50);
            this.lbUsePlateAngle.TabIndex = 1506;
            // 
            // btnUseJigPlateAngle
            // 
            this.btnUseJigPlateAngle.BackColor = System.Drawing.Color.Silver;
            this.btnUseJigPlateAngle.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseJigPlateAngle.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseJigPlateAngle.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseJigPlateAngle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseJigPlateAngle.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseJigPlateAngle.Location = new System.Drawing.Point(43, 33);
            this.btnUseJigPlateAngle.Name = "btnUseJigPlateAngle";
            this.btnUseJigPlateAngle.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseJigPlateAngle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseJigPlateAngle.ShineColor = System.Drawing.Color.Silver;
            this.btnUseJigPlateAngle.Size = new System.Drawing.Size(158, 50);
            this.btnUseJigPlateAngle.TabIndex = 1499;
            this.btnUseJigPlateAngle.TabStop = false;
            this.btnUseJigPlateAngle.Tag = "0";
            this.btnUseJigPlateAngle.Text = "USE JIG FLATNESS";
            this.btnUseJigPlateAngle.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseCleanJig
            // 
            this.btnUseCleanJig.BackColor = System.Drawing.Color.Silver;
            this.btnUseCleanJig.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseCleanJig.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseCleanJig.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseCleanJig.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseCleanJig.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseCleanJig.Location = new System.Drawing.Point(43, 90);
            this.btnUseCleanJig.Name = "btnUseCleanJig";
            this.btnUseCleanJig.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseCleanJig.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseCleanJig.ShineColor = System.Drawing.Color.Silver;
            this.btnUseCleanJig.Size = new System.Drawing.Size(158, 50);
            this.btnUseCleanJig.TabIndex = 1501;
            this.btnUseCleanJig.TabStop = false;
            this.btnUseCleanJig.Tag = "0";
            this.btnUseCleanJig.Text = "USE CLEAN JIG";
            this.btnUseCleanJig.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnUseLensHeight
            // 
            this.btnUseLensHeight.BackColor = System.Drawing.Color.Silver;
            this.btnUseLensHeight.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseLensHeight.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseLensHeight.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseLensHeight.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseLensHeight.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseLensHeight.Location = new System.Drawing.Point(283, 89);
            this.btnUseLensHeight.Name = "btnUseLensHeight";
            this.btnUseLensHeight.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseLensHeight.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseLensHeight.ShineColor = System.Drawing.Color.Silver;
            this.btnUseLensHeight.Size = new System.Drawing.Size(158, 50);
            this.btnUseLensHeight.TabIndex = 1507;
            this.btnUseLensHeight.TabStop = false;
            this.btnUseLensHeight.Tag = "0";
            this.btnUseLensHeight.Text = "USE LENS HEIGHT";
            this.btnUseLensHeight.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbUseLensHeight
            // 
            this.lbUseLensHeight.BackColor = System.Drawing.Color.Lime;
            this.lbUseLensHeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseLensHeight.Location = new System.Drawing.Point(262, 89);
            this.lbUseLensHeight.Name = "lbUseLensHeight";
            this.lbUseLensHeight.Size = new System.Drawing.Size(15, 50);
            this.lbUseLensHeight.TabIndex = 1508;
            // 
            // lbUseCleanJig
            // 
            this.lbUseCleanJig.BackColor = System.Drawing.Color.Lime;
            this.lbUseCleanJig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseCleanJig.Location = new System.Drawing.Point(22, 90);
            this.lbUseCleanJig.Name = "lbUseCleanJig";
            this.lbUseCleanJig.Size = new System.Drawing.Size(15, 50);
            this.lbUseCleanJig.TabIndex = 1502;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.groupBox18);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Controls.Add(this.groupBox13);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Controls.Add(this.groupBox14);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 39);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1420, 936);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "  DATA  ";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.lbUseMeasureContact);
            this.groupBox18.Controls.Add(this.label37);
            this.groupBox18.Controls.Add(this.lbPlateAngleGood);
            this.groupBox18.Controls.Add(this.btnUseContact);
            this.groupBox18.Controls.Add(this.label39);
            this.groupBox18.Controls.Add(this.lbPlateAngleRetry);
            this.groupBox18.Location = new System.Drawing.Point(785, 516);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(419, 417);
            this.groupBox18.TabIndex = 1539;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "PlateAngle Retry Option";
            // 
            // lbUseMeasureContact
            // 
            this.lbUseMeasureContact.BackColor = System.Drawing.Color.Lime;
            this.lbUseMeasureContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseMeasureContact.Location = new System.Drawing.Point(39, 40);
            this.lbUseMeasureContact.Name = "lbUseMeasureContact";
            this.lbUseMeasureContact.Size = new System.Drawing.Size(15, 54);
            this.lbUseMeasureContact.TabIndex = 1530;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(39, 225);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(178, 54);
            this.label37.TabIndex = 1501;
            this.label37.Text = "Good Count";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPlateAngleGood
            // 
            this.lbPlateAngleGood.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPlateAngleGood.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlateAngleGood.ForeColor = System.Drawing.Color.Black;
            this.lbPlateAngleGood.Location = new System.Drawing.Point(223, 226);
            this.lbPlateAngleGood.Name = "lbPlateAngleGood";
            this.lbPlateAngleGood.Size = new System.Drawing.Size(139, 54);
            this.lbPlateAngleGood.TabIndex = 1502;
            this.lbPlateAngleGood.Text = "1";
            this.lbPlateAngleGood.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPlateAngleGood.Click += new System.EventHandler(this.PlateAngleOptionSet_Click);
            // 
            // btnUseContact
            // 
            this.btnUseContact.BackColor = System.Drawing.Color.Silver;
            this.btnUseContact.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseContact.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseContact.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseContact.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseContact.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseContact.Location = new System.Drawing.Point(60, 40);
            this.btnUseContact.Name = "btnUseContact";
            this.btnUseContact.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseContact.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseContact.ShineColor = System.Drawing.Color.Silver;
            this.btnUseContact.Size = new System.Drawing.Size(158, 54);
            this.btnUseContact.TabIndex = 1529;
            this.btnUseContact.TabStop = false;
            this.btnUseContact.Tag = "0";
            this.btnUseContact.Text = "Contact Act 2";
            this.btnUseContact.Click += new System.EventHandler(this.btnUseContact_Click);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(39, 165);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(178, 54);
            this.label39.TabIndex = 1498;
            this.label39.Text = "Retry Count";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPlateAngleRetry
            // 
            this.lbPlateAngleRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPlateAngleRetry.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlateAngleRetry.ForeColor = System.Drawing.Color.Black;
            this.lbPlateAngleRetry.Location = new System.Drawing.Point(223, 166);
            this.lbPlateAngleRetry.Name = "lbPlateAngleRetry";
            this.lbPlateAngleRetry.Size = new System.Drawing.Size(139, 54);
            this.lbPlateAngleRetry.TabIndex = 1500;
            this.lbPlateAngleRetry.Text = "1";
            this.lbPlateAngleRetry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPlateAngleRetry.Click += new System.EventHandler(this.PlateAngleOptionSet_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.lbBonder2GapPosY);
            this.groupBox9.Controls.Add(this.label23);
            this.groupBox9.Controls.Add(this.lbBonder2GapPosX);
            this.groupBox9.Controls.Add(this.label20);
            this.groupBox9.Controls.Add(this.lbBonder1GapPosY);
            this.groupBox9.Controls.Add(this.label22);
            this.groupBox9.Controls.Add(this.lbBonder1GapPosX);
            this.groupBox9.Controls.Add(this.lbUseGap);
            this.groupBox9.Controls.Add(this.btnUseGap);
            this.groupBox9.Location = new System.Drawing.Point(785, 13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(397, 497);
            this.groupBox9.TabIndex = 1536;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Dispenser Air Type Gap Sensor";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(39, 293);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(179, 54);
            this.label18.TabIndex = 1807;
            this.label18.Text = "#2 Gap Pos Y";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder2GapPosY
            // 
            this.lbBonder2GapPosY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder2GapPosY.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder2GapPosY.Location = new System.Drawing.Point(226, 293);
            this.lbBonder2GapPosY.Name = "lbBonder2GapPosY";
            this.lbBonder2GapPosY.Size = new System.Drawing.Size(139, 54);
            this.lbBonder2GapPosY.TabIndex = 1808;
            this.lbBonder2GapPosY.Text = "1";
            this.lbBonder2GapPosY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder2GapPosY.Click += new System.EventHandler(this.lbGapPosX_Click);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(39, 233);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(179, 54);
            this.label23.TabIndex = 1805;
            this.label23.Text = "#2 Gap Pos X";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder2GapPosX
            // 
            this.lbBonder2GapPosX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder2GapPosX.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder2GapPosX.Location = new System.Drawing.Point(226, 233);
            this.lbBonder2GapPosX.Name = "lbBonder2GapPosX";
            this.lbBonder2GapPosX.Size = new System.Drawing.Size(139, 54);
            this.lbBonder2GapPosX.TabIndex = 1806;
            this.lbBonder2GapPosX.Text = "1";
            this.lbBonder2GapPosX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder2GapPosX.Click += new System.EventHandler(this.lbGapPosX_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(39, 167);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(179, 54);
            this.label20.TabIndex = 1803;
            this.label20.Text = "#1 Gap Pos Y";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder1GapPosY
            // 
            this.lbBonder1GapPosY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder1GapPosY.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder1GapPosY.Location = new System.Drawing.Point(226, 167);
            this.lbBonder1GapPosY.Name = "lbBonder1GapPosY";
            this.lbBonder1GapPosY.Size = new System.Drawing.Size(139, 54);
            this.lbBonder1GapPosY.TabIndex = 1804;
            this.lbBonder1GapPosY.Text = "1";
            this.lbBonder1GapPosY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder1GapPosY.Click += new System.EventHandler(this.lbGapPosX_Click);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(39, 107);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(179, 54);
            this.label22.TabIndex = 1801;
            this.label22.Text = "#1 Gap Pos X";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder1GapPosX
            // 
            this.lbBonder1GapPosX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder1GapPosX.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder1GapPosX.Location = new System.Drawing.Point(226, 107);
            this.lbBonder1GapPosX.Name = "lbBonder1GapPosX";
            this.lbBonder1GapPosX.Size = new System.Drawing.Size(139, 54);
            this.lbBonder1GapPosX.TabIndex = 1802;
            this.lbBonder1GapPosX.Text = "1";
            this.lbBonder1GapPosX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder1GapPosX.Click += new System.EventHandler(this.lbGapPosX_Click);
            // 
            // lbUseGap
            // 
            this.lbUseGap.BackColor = System.Drawing.Color.Lime;
            this.lbUseGap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseGap.Location = new System.Drawing.Point(39, 42);
            this.lbUseGap.Name = "lbUseGap";
            this.lbUseGap.Size = new System.Drawing.Size(15, 54);
            this.lbUseGap.TabIndex = 1523;
            // 
            // btnUseGap
            // 
            this.btnUseGap.BackColor = System.Drawing.Color.Silver;
            this.btnUseGap.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseGap.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseGap.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseGap.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseGap.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseGap.Location = new System.Drawing.Point(58, 42);
            this.btnUseGap.Name = "btnUseGap";
            this.btnUseGap.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseGap.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseGap.ShineColor = System.Drawing.Color.Silver;
            this.btnUseGap.Size = new System.Drawing.Size(158, 54);
            this.btnUseGap.TabIndex = 1522;
            this.btnUseGap.TabStop = false;
            this.btnUseGap.Tag = "0";
            this.btnUseGap.Text = "USE GAP";
            this.btnUseGap.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.lbVisionRetry);
            this.groupBox13.Controls.Add(this.lbVisionRetryCount);
            this.groupBox13.Controls.Add(this.lbBonder2Retry);
            this.groupBox13.Controls.Add(this.lbBonder2RetryCount);
            this.groupBox13.Controls.Add(this.lbBonder1Retry);
            this.groupBox13.Controls.Add(this.lbBonder1RetryCount);
            this.groupBox13.Controls.Add(this.lbLensBottomRetry);
            this.groupBox13.Controls.Add(this.lbLensBottomRetryCount);
            this.groupBox13.Controls.Add(this.lbLensUpperRetry);
            this.groupBox13.Controls.Add(this.lbLensUpperRetryCount);
            this.groupBox13.Controls.Add(this.lbVCMVisionRetry);
            this.groupBox13.Controls.Add(this.lbVCMVISIONRetryCount);
            this.groupBox13.Location = new System.Drawing.Point(14, 516);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(368, 417);
            this.groupBox13.TabIndex = 1535;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Vision Retry Count";
            // 
            // lbVisionRetry
            // 
            this.lbVisionRetry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbVisionRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVisionRetry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVisionRetry.ForeColor = System.Drawing.Color.Black;
            this.lbVisionRetry.Location = new System.Drawing.Point(26, 344);
            this.lbVisionRetry.Name = "lbVisionRetry";
            this.lbVisionRetry.Size = new System.Drawing.Size(178, 54);
            this.lbVisionRetry.TabIndex = 1509;
            this.lbVisionRetry.Text = "VISION INSPECT";
            this.lbVisionRetry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbVisionRetryCount
            // 
            this.lbVisionRetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVisionRetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVisionRetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbVisionRetryCount.Location = new System.Drawing.Point(211, 345);
            this.lbVisionRetryCount.Name = "lbVisionRetryCount";
            this.lbVisionRetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbVisionRetryCount.TabIndex = 1510;
            this.lbVisionRetryCount.Text = "1";
            this.lbVisionRetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbVisionRetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbBonder2Retry
            // 
            this.lbBonder2Retry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbBonder2Retry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder2Retry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder2Retry.ForeColor = System.Drawing.Color.Black;
            this.lbBonder2Retry.Location = new System.Drawing.Point(26, 283);
            this.lbBonder2Retry.Name = "lbBonder2Retry";
            this.lbBonder2Retry.Size = new System.Drawing.Size(178, 54);
            this.lbBonder2Retry.TabIndex = 1507;
            this.lbBonder2Retry.Text = "BONDER 2";
            this.lbBonder2Retry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder2RetryCount
            // 
            this.lbBonder2RetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder2RetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder2RetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbBonder2RetryCount.Location = new System.Drawing.Point(211, 284);
            this.lbBonder2RetryCount.Name = "lbBonder2RetryCount";
            this.lbBonder2RetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbBonder2RetryCount.TabIndex = 1508;
            this.lbBonder2RetryCount.Text = "1";
            this.lbBonder2RetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder2RetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbBonder1Retry
            // 
            this.lbBonder1Retry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbBonder1Retry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder1Retry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder1Retry.ForeColor = System.Drawing.Color.Black;
            this.lbBonder1Retry.Location = new System.Drawing.Point(26, 222);
            this.lbBonder1Retry.Name = "lbBonder1Retry";
            this.lbBonder1Retry.Size = new System.Drawing.Size(178, 54);
            this.lbBonder1Retry.TabIndex = 1505;
            this.lbBonder1Retry.Text = "BONDER 1";
            this.lbBonder1Retry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBonder1RetryCount
            // 
            this.lbBonder1RetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbBonder1RetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBonder1RetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbBonder1RetryCount.Location = new System.Drawing.Point(211, 223);
            this.lbBonder1RetryCount.Name = "lbBonder1RetryCount";
            this.lbBonder1RetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbBonder1RetryCount.TabIndex = 1506;
            this.lbBonder1RetryCount.Text = "1";
            this.lbBonder1RetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbBonder1RetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbLensBottomRetry
            // 
            this.lbLensBottomRetry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbLensBottomRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensBottomRetry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLensBottomRetry.ForeColor = System.Drawing.Color.Black;
            this.lbLensBottomRetry.Location = new System.Drawing.Point(26, 161);
            this.lbLensBottomRetry.Name = "lbLensBottomRetry";
            this.lbLensBottomRetry.Size = new System.Drawing.Size(178, 54);
            this.lbLensBottomRetry.TabIndex = 1503;
            this.lbLensBottomRetry.Text = "LENS BOTTOM";
            this.lbLensBottomRetry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLensBottomRetryCount
            // 
            this.lbLensBottomRetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensBottomRetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLensBottomRetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbLensBottomRetryCount.Location = new System.Drawing.Point(211, 162);
            this.lbLensBottomRetryCount.Name = "lbLensBottomRetryCount";
            this.lbLensBottomRetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbLensBottomRetryCount.TabIndex = 1504;
            this.lbLensBottomRetryCount.Text = "1";
            this.lbLensBottomRetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbLensBottomRetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbLensUpperRetry
            // 
            this.lbLensUpperRetry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbLensUpperRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensUpperRetry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLensUpperRetry.ForeColor = System.Drawing.Color.Black;
            this.lbLensUpperRetry.Location = new System.Drawing.Point(26, 100);
            this.lbLensUpperRetry.Name = "lbLensUpperRetry";
            this.lbLensUpperRetry.Size = new System.Drawing.Size(178, 54);
            this.lbLensUpperRetry.TabIndex = 1501;
            this.lbLensUpperRetry.Text = "LENS UPPER";
            this.lbLensUpperRetry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLensUpperRetryCount
            // 
            this.lbLensUpperRetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensUpperRetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLensUpperRetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbLensUpperRetryCount.Location = new System.Drawing.Point(211, 101);
            this.lbLensUpperRetryCount.Name = "lbLensUpperRetryCount";
            this.lbLensUpperRetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbLensUpperRetryCount.TabIndex = 1502;
            this.lbLensUpperRetryCount.Text = "1";
            this.lbLensUpperRetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbLensUpperRetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // lbVCMVisionRetry
            // 
            this.lbVCMVisionRetry.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbVCMVisionRetry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVCMVisionRetry.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVCMVisionRetry.ForeColor = System.Drawing.Color.Black;
            this.lbVCMVisionRetry.Location = new System.Drawing.Point(26, 39);
            this.lbVCMVisionRetry.Name = "lbVCMVisionRetry";
            this.lbVCMVisionRetry.Size = new System.Drawing.Size(178, 54);
            this.lbVCMVisionRetry.TabIndex = 1498;
            this.lbVCMVisionRetry.Text = "VCM VISION";
            this.lbVCMVisionRetry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbVCMVISIONRetryCount
            // 
            this.lbVCMVISIONRetryCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbVCMVISIONRetryCount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVCMVISIONRetryCount.ForeColor = System.Drawing.Color.Black;
            this.lbVCMVISIONRetryCount.Location = new System.Drawing.Point(211, 40);
            this.lbVCMVISIONRetryCount.Name = "lbVCMVISIONRetryCount";
            this.lbVCMVISIONRetryCount.Size = new System.Drawing.Size(139, 54);
            this.lbVCMVISIONRetryCount.TabIndex = 1500;
            this.lbVCMVISIONRetryCount.Text = "1";
            this.lbVCMVISIONRetryCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbVCMVISIONRetryCount.Click += new System.EventHandler(this.VISIONRetryCount_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.lbSecondaryLimitValue);
            this.groupBox3.Controls.Add(this.lbUseSecondaryCorrection);
            this.groupBox3.Controls.Add(this.btnSecondaryCorrection);
            this.groupBox3.Controls.Add(this.btnAssembleMode);
            this.groupBox3.Controls.Add(this.lbLensThetaTorque);
            this.groupBox3.Controls.Add(this.btnLensThetaTorque);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.lbLensPickUpTorque);
            this.groupBox3.Controls.Add(this.btnLensPickUpTorque);
            this.groupBox3.Controls.Add(this.lbTorqueLimitZ);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.lbLensInsertTorque);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.btnLensInsertTorque);
            this.groupBox3.Controls.Add(this.lbTorqueTLimit);
            this.groupBox3.Location = new System.Drawing.Point(14, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(368, 497);
            this.groupBox3.TabIndex = 1534;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Assemble Option";
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(211, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(139, 26);
            this.label24.TabIndex = 1833;
            this.label24.Text = "Limit Value";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSecondaryLimitValue
            // 
            this.lbSecondaryLimitValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbSecondaryLimitValue.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSecondaryLimitValue.Location = new System.Drawing.Point(211, 55);
            this.lbSecondaryLimitValue.Name = "lbSecondaryLimitValue";
            this.lbSecondaryLimitValue.Size = new System.Drawing.Size(139, 25);
            this.lbSecondaryLimitValue.TabIndex = 1834;
            this.lbSecondaryLimitValue.Text = "3";
            this.lbSecondaryLimitValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbSecondaryLimitValue.Click += new System.EventHandler(this.lbSecondaryLimitValue_Click);
            // 
            // lbUseSecondaryCorrection
            // 
            this.lbUseSecondaryCorrection.BackColor = System.Drawing.Color.Lime;
            this.lbUseSecondaryCorrection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseSecondaryCorrection.Location = new System.Drawing.Point(27, 26);
            this.lbUseSecondaryCorrection.Name = "lbUseSecondaryCorrection";
            this.lbUseSecondaryCorrection.Size = new System.Drawing.Size(15, 54);
            this.lbUseSecondaryCorrection.TabIndex = 1832;
            // 
            // btnSecondaryCorrection
            // 
            this.btnSecondaryCorrection.BackColor = System.Drawing.Color.Silver;
            this.btnSecondaryCorrection.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSecondaryCorrection.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSecondaryCorrection.GlowColor = System.Drawing.Color.Transparent;
            this.btnSecondaryCorrection.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSecondaryCorrection.InnerBorderColor = System.Drawing.Color.White;
            this.btnSecondaryCorrection.Location = new System.Drawing.Point(46, 26);
            this.btnSecondaryCorrection.Name = "btnSecondaryCorrection";
            this.btnSecondaryCorrection.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSecondaryCorrection.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSecondaryCorrection.ShineColor = System.Drawing.Color.Silver;
            this.btnSecondaryCorrection.Size = new System.Drawing.Size(158, 54);
            this.btnSecondaryCorrection.TabIndex = 1831;
            this.btnSecondaryCorrection.TabStop = false;
            this.btnSecondaryCorrection.Tag = "0";
            this.btnSecondaryCorrection.Text = "Second Correction (Bottom Check)";
            this.btnSecondaryCorrection.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // btnAssembleMode
            // 
            this.btnAssembleMode.BackColor = System.Drawing.Color.Silver;
            this.btnAssembleMode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnAssembleMode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnAssembleMode.GlowColor = System.Drawing.Color.Transparent;
            this.btnAssembleMode.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAssembleMode.InnerBorderColor = System.Drawing.Color.White;
            this.btnAssembleMode.Location = new System.Drawing.Point(46, 93);
            this.btnAssembleMode.Name = "btnAssembleMode";
            this.btnAssembleMode.OuterBorderColor = System.Drawing.Color.Black;
            this.btnAssembleMode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAssembleMode.ShineColor = System.Drawing.Color.Silver;
            this.btnAssembleMode.Size = new System.Drawing.Size(158, 54);
            this.btnAssembleMode.TabIndex = 1803;
            this.btnAssembleMode.TabStop = false;
            this.btnAssembleMode.Tag = "0";
            this.btnAssembleMode.Text = "NORMAL";
            this.btnAssembleMode.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // lbLensThetaTorque
            // 
            this.lbLensThetaTorque.BackColor = System.Drawing.Color.Lime;
            this.lbLensThetaTorque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensThetaTorque.Location = new System.Drawing.Point(26, 282);
            this.lbLensThetaTorque.Name = "lbLensThetaTorque";
            this.lbLensThetaTorque.Size = new System.Drawing.Size(15, 54);
            this.lbLensThetaTorque.TabIndex = 1802;
            // 
            // btnLensThetaTorque
            // 
            this.btnLensThetaTorque.BackColor = System.Drawing.Color.Silver;
            this.btnLensThetaTorque.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensThetaTorque.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensThetaTorque.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensThetaTorque.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensThetaTorque.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensThetaTorque.Location = new System.Drawing.Point(46, 282);
            this.btnLensThetaTorque.Name = "btnLensThetaTorque";
            this.btnLensThetaTorque.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensThetaTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensThetaTorque.ShineColor = System.Drawing.Color.Silver;
            this.btnLensThetaTorque.Size = new System.Drawing.Size(158, 54);
            this.btnLensThetaTorque.TabIndex = 1801;
            this.btnLensThetaTorque.TabStop = false;
            this.btnLensThetaTorque.Tag = "0";
            this.btnLensThetaTorque.Text = "THETA TORQUE";
            this.btnLensThetaTorque.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(211, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(139, 54);
            this.label19.TabIndex = 1830;
            this.label19.Text = "ASSEMBLE MODE";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLensPickUpTorque
            // 
            this.lbLensPickUpTorque.BackColor = System.Drawing.Color.Lime;
            this.lbLensPickUpTorque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensPickUpTorque.Location = new System.Drawing.Point(26, 222);
            this.lbLensPickUpTorque.Name = "lbLensPickUpTorque";
            this.lbLensPickUpTorque.Size = new System.Drawing.Size(15, 54);
            this.lbLensPickUpTorque.TabIndex = 1798;
            // 
            // btnLensPickUpTorque
            // 
            this.btnLensPickUpTorque.BackColor = System.Drawing.Color.Silver;
            this.btnLensPickUpTorque.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensPickUpTorque.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensPickUpTorque.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensPickUpTorque.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensPickUpTorque.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensPickUpTorque.Location = new System.Drawing.Point(46, 222);
            this.btnLensPickUpTorque.Name = "btnLensPickUpTorque";
            this.btnLensPickUpTorque.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensPickUpTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensPickUpTorque.ShineColor = System.Drawing.Color.Silver;
            this.btnLensPickUpTorque.Size = new System.Drawing.Size(158, 54);
            this.btnLensPickUpTorque.TabIndex = 1797;
            this.btnLensPickUpTorque.TabStop = false;
            this.btnLensPickUpTorque.Tag = "0";
            this.btnLensPickUpTorque.Text = "PICK UP TORQUE";
            this.btnLensPickUpTorque.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // lbTorqueLimitZ
            // 
            this.lbTorqueLimitZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueLimitZ.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTorqueLimitZ.Location = new System.Drawing.Point(211, 359);
            this.lbTorqueLimitZ.Name = "lbTorqueLimitZ";
            this.lbTorqueLimitZ.Size = new System.Drawing.Size(139, 54);
            this.lbTorqueLimitZ.TabIndex = 1794;
            this.lbTorqueLimitZ.Text = "1";
            this.lbTorqueLimitZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbTorqueLimitZ.Click += new System.EventHandler(this.lbTorqueLimitZ_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(26, 420);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(178, 54);
            this.label16.TabIndex = 1799;
            this.label16.Text = "TORQUE LIMIT THETA";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLensInsertTorque
            // 
            this.lbLensInsertTorque.BackColor = System.Drawing.Color.Lime;
            this.lbLensInsertTorque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensInsertTorque.Location = new System.Drawing.Point(26, 162);
            this.lbLensInsertTorque.Name = "lbLensInsertTorque";
            this.lbLensInsertTorque.Size = new System.Drawing.Size(15, 54);
            this.lbLensInsertTorque.TabIndex = 1521;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(26, 359);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(178, 54);
            this.label9.TabIndex = 1793;
            this.label9.Text = "TORQUE INDEX LIMIT Z";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLensInsertTorque
            // 
            this.btnLensInsertTorque.BackColor = System.Drawing.Color.Silver;
            this.btnLensInsertTorque.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensInsertTorque.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensInsertTorque.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensInsertTorque.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensInsertTorque.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensInsertTorque.Location = new System.Drawing.Point(46, 162);
            this.btnLensInsertTorque.Name = "btnLensInsertTorque";
            this.btnLensInsertTorque.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensInsertTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensInsertTorque.ShineColor = System.Drawing.Color.Silver;
            this.btnLensInsertTorque.Size = new System.Drawing.Size(158, 54);
            this.btnLensInsertTorque.TabIndex = 1509;
            this.btnLensInsertTorque.TabStop = false;
            this.btnLensInsertTorque.Tag = "0";
            this.btnLensInsertTorque.Text = "PLACE TORQUE";
            this.btnLensInsertTorque.Click += new System.EventHandler(this.btnLoaderMagazine_Click);
            // 
            // lbTorqueTLimit
            // 
            this.lbTorqueTLimit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueTLimit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTorqueTLimit.Location = new System.Drawing.Point(211, 420);
            this.lbTorqueTLimit.Name = "lbTorqueTLimit";
            this.lbTorqueTLimit.Size = new System.Drawing.Size(139, 54);
            this.lbTorqueTLimit.TabIndex = 1800;
            this.lbTorqueTLimit.Text = "1";
            this.lbTorqueTLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbTorqueTLimit.Click += new System.EventHandler(this.lbTorqueTLimit_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.lbUseResultRowDataJudge);
            this.groupBox14.Controls.Add(this.btnUseResultRowDataJudge);
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.lbRnRShift);
            this.groupBox14.Controls.Add(this.lblResultDummyPass);
            this.groupBox14.Controls.Add(this.BtnResultDummyPass);
            this.groupBox14.Controls.Add(this.label5);
            this.groupBox14.Controls.Add(this.lbRnRGain);
            this.groupBox14.Location = new System.Drawing.Point(388, 516);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(385, 417);
            this.groupBox14.TabIndex = 1532;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Side Angle";
            // 
            // lbUseResultRowDataJudge
            // 
            this.lbUseResultRowDataJudge.BackColor = System.Drawing.Color.Lime;
            this.lbUseResultRowDataJudge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUseResultRowDataJudge.Location = new System.Drawing.Point(38, 100);
            this.lbUseResultRowDataJudge.Name = "lbUseResultRowDataJudge";
            this.lbUseResultRowDataJudge.Size = new System.Drawing.Size(15, 54);
            this.lbUseResultRowDataJudge.TabIndex = 1532;
            // 
            // btnUseResultRowDataJudge
            // 
            this.btnUseResultRowDataJudge.BackColor = System.Drawing.Color.Silver;
            this.btnUseResultRowDataJudge.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnUseResultRowDataJudge.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnUseResultRowDataJudge.GlowColor = System.Drawing.Color.Transparent;
            this.btnUseResultRowDataJudge.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUseResultRowDataJudge.InnerBorderColor = System.Drawing.Color.White;
            this.btnUseResultRowDataJudge.Location = new System.Drawing.Point(59, 100);
            this.btnUseResultRowDataJudge.Name = "btnUseResultRowDataJudge";
            this.btnUseResultRowDataJudge.OuterBorderColor = System.Drawing.Color.Black;
            this.btnUseResultRowDataJudge.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUseResultRowDataJudge.ShineColor = System.Drawing.Color.Silver;
            this.btnUseResultRowDataJudge.Size = new System.Drawing.Size(158, 54);
            this.btnUseResultRowDataJudge.TabIndex = 1531;
            this.btnUseResultRowDataJudge.TabStop = false;
            this.btnUseResultRowDataJudge.Tag = "0";
            this.btnUseResultRowDataJudge.Text = "USE RESULT ROW DATA JUDGE";
            this.btnUseResultRowDataJudge.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(39, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(178, 54);
            this.label13.TabIndex = 1529;
            this.label13.Text = "R&&R Shift";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRnRShift
            // 
            this.lbRnRShift.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbRnRShift.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRnRShift.ForeColor = System.Drawing.Color.Black;
            this.lbRnRShift.Location = new System.Drawing.Point(223, 225);
            this.lbRnRShift.Name = "lbRnRShift";
            this.lbRnRShift.Size = new System.Drawing.Size(139, 54);
            this.lbRnRShift.TabIndex = 1530;
            this.lbRnRShift.Text = "1";
            this.lbRnRShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbRnRShift.Click += new System.EventHandler(this.lbRnRPercnet_Click);
            // 
            // lblResultDummyPass
            // 
            this.lblResultDummyPass.BackColor = System.Drawing.Color.Lime;
            this.lblResultDummyPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResultDummyPass.Location = new System.Drawing.Point(38, 40);
            this.lblResultDummyPass.Name = "lblResultDummyPass";
            this.lblResultDummyPass.Size = new System.Drawing.Size(15, 54);
            this.lblResultDummyPass.TabIndex = 1528;
            // 
            // BtnResultDummyPass
            // 
            this.BtnResultDummyPass.BackColor = System.Drawing.Color.Silver;
            this.BtnResultDummyPass.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BtnResultDummyPass.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnResultDummyPass.GlowColor = System.Drawing.Color.Transparent;
            this.BtnResultDummyPass.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnResultDummyPass.InnerBorderColor = System.Drawing.Color.White;
            this.BtnResultDummyPass.Location = new System.Drawing.Point(59, 40);
            this.BtnResultDummyPass.Name = "BtnResultDummyPass";
            this.BtnResultDummyPass.OuterBorderColor = System.Drawing.Color.Black;
            this.BtnResultDummyPass.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BtnResultDummyPass.ShineColor = System.Drawing.Color.Silver;
            this.BtnResultDummyPass.Size = new System.Drawing.Size(158, 54);
            this.BtnResultDummyPass.TabIndex = 1527;
            this.BtnResultDummyPass.TabStop = false;
            this.BtnResultDummyPass.Tag = "0";
            this.BtnResultDummyPass.Text = "USE RESULT DUMMY PASS";
            this.BtnResultDummyPass.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(39, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(178, 54);
            this.label5.TabIndex = 1501;
            this.label5.Text = "R&&R Gain";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRnRGain
            // 
            this.lbRnRGain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbRnRGain.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRnRGain.ForeColor = System.Drawing.Color.Black;
            this.lbRnRGain.Location = new System.Drawing.Point(223, 165);
            this.lbRnRGain.Name = "lbRnRGain";
            this.lbRnRGain.Size = new System.Drawing.Size(139, 54);
            this.lbRnRGain.TabIndex = 1502;
            this.lbRnRGain.Text = "1";
            this.lbRnRGain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbRnRGain.Click += new System.EventHandler(this.lbRnRPercnet_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.lblLensAllowMin);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.lblLensHeight);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.lblLensAllowMax);
            this.groupBox4.Controls.Add(this.lbLensHeightSoftWareJudge);
            this.groupBox4.Controls.Add(this.btnLensHeightSoftWareJudge);
            this.groupBox4.Location = new System.Drawing.Point(393, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(380, 497);
            this.groupBox4.TabIndex = 1506;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "LensHeight Option";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(33, 160);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(179, 54);
            this.label12.TabIndex = 1831;
            this.label12.Text = "Allow Min";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLensAllowMin
            // 
            this.lblLensAllowMin.BackColor = System.Drawing.Color.White;
            this.lblLensAllowMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLensAllowMin.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblLensAllowMin.ForeColor = System.Drawing.Color.Black;
            this.lblLensAllowMin.Location = new System.Drawing.Point(218, 160);
            this.lblLensAllowMin.Name = "lblLensAllowMin";
            this.lblLensAllowMin.Size = new System.Drawing.Size(139, 54);
            this.lblLensAllowMin.TabIndex = 1832;
            this.lblLensAllowMin.Text = "0";
            this.lblLensAllowMin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLensAllowMin.Click += new System.EventHandler(this.lblLensHeight_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(33, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 54);
            this.label7.TabIndex = 1829;
            this.label7.Text = "Lens Height";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLensHeight
            // 
            this.lblLensHeight.BackColor = System.Drawing.Color.White;
            this.lblLensHeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLensHeight.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblLensHeight.ForeColor = System.Drawing.Color.Black;
            this.lblLensHeight.Location = new System.Drawing.Point(218, 98);
            this.lblLensHeight.Name = "lblLensHeight";
            this.lblLensHeight.Size = new System.Drawing.Size(139, 54);
            this.lblLensHeight.TabIndex = 1830;
            this.lblLensHeight.Text = "0";
            this.lblLensHeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLensHeight.Click += new System.EventHandler(this.lblLensHeight_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(33, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 54);
            this.label3.TabIndex = 1827;
            this.label3.Text = "Allow Max";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLensAllowMax
            // 
            this.lblLensAllowMax.BackColor = System.Drawing.Color.White;
            this.lblLensAllowMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLensAllowMax.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblLensAllowMax.ForeColor = System.Drawing.Color.Black;
            this.lblLensAllowMax.Location = new System.Drawing.Point(218, 220);
            this.lblLensAllowMax.Name = "lblLensAllowMax";
            this.lblLensAllowMax.Size = new System.Drawing.Size(139, 54);
            this.lblLensAllowMax.TabIndex = 1828;
            this.lblLensAllowMax.Text = "0";
            this.lblLensAllowMax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLensAllowMax.Click += new System.EventHandler(this.lblLensHeight_Click);
            // 
            // lbLensHeightSoftWareJudge
            // 
            this.lbLensHeightSoftWareJudge.BackColor = System.Drawing.Color.Lime;
            this.lbLensHeightSoftWareJudge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbLensHeightSoftWareJudge.Location = new System.Drawing.Point(33, 36);
            this.lbLensHeightSoftWareJudge.Name = "lbLensHeightSoftWareJudge";
            this.lbLensHeightSoftWareJudge.Size = new System.Drawing.Size(15, 54);
            this.lbLensHeightSoftWareJudge.TabIndex = 1521;
            // 
            // btnLensHeightSoftWareJudge
            // 
            this.btnLensHeightSoftWareJudge.BackColor = System.Drawing.Color.Silver;
            this.btnLensHeightSoftWareJudge.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLensHeightSoftWareJudge.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnLensHeightSoftWareJudge.GlowColor = System.Drawing.Color.Transparent;
            this.btnLensHeightSoftWareJudge.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLensHeightSoftWareJudge.InnerBorderColor = System.Drawing.Color.White;
            this.btnLensHeightSoftWareJudge.Location = new System.Drawing.Point(54, 36);
            this.btnLensHeightSoftWareJudge.Name = "btnLensHeightSoftWareJudge";
            this.btnLensHeightSoftWareJudge.OuterBorderColor = System.Drawing.Color.Black;
            this.btnLensHeightSoftWareJudge.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLensHeightSoftWareJudge.ShineColor = System.Drawing.Color.Silver;
            this.btnLensHeightSoftWareJudge.Size = new System.Drawing.Size(158, 54);
            this.btnLensHeightSoftWareJudge.TabIndex = 1509;
            this.btnLensHeightSoftWareJudge.TabStop = false;
            this.btnLensHeightSoftWareJudge.Tag = "0";
            this.btnLensHeightSoftWareJudge.Text = "SOFTWARE JUDGE";
            this.btnLensHeightSoftWareJudge.Click += new System.EventHandler(this.glassButton_OptionDryRun_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 39);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1420, 936);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "DISPENSER (POINT)";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.gridDp2);
            this.panel1.Controls.Add(this.lbJetPosGridTitle1);
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.gridDp1);
            this.panel1.Controls.Add(this.lbJetPosGridTitle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1420, 936);
            this.panel1.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lblSelectRowIdx2);
            this.groupBox8.Controls.Add(this.btnSelectItemDelete1);
            this.groupBox8.Controls.Add(this.btnSelectItemAdd1);
            this.groupBox8.Controls.Add(this.btnItemDelete1);
            this.groupBox8.Controls.Add(this.btnItemAdd1);
            this.groupBox8.Location = new System.Drawing.Point(717, 833);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(700, 100);
            this.groupBox8.TabIndex = 1802;
            this.groupBox8.TabStop = false;
            // 
            // lblSelectRowIdx2
            // 
            this.lblSelectRowIdx2.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx2.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx2.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx2.Location = new System.Drawing.Point(326, 28);
            this.lblSelectRowIdx2.Name = "lblSelectRowIdx2";
            this.lblSelectRowIdx2.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx2.TabIndex = 1823;
            this.lblSelectRowIdx2.Text = "0";
            this.lblSelectRowIdx2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSelectItemDelete1
            // 
            this.btnSelectItemDelete1.BackColor = System.Drawing.Color.Silver;
            this.btnSelectItemDelete1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSelectItemDelete1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSelectItemDelete1.InnerBorderColor = System.Drawing.Color.White;
            this.btnSelectItemDelete1.Location = new System.Drawing.Point(553, 29);
            this.btnSelectItemDelete1.Name = "btnSelectItemDelete1";
            this.btnSelectItemDelete1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSelectItemDelete1.ShineColor = System.Drawing.Color.Silver;
            this.btnSelectItemDelete1.Size = new System.Drawing.Size(131, 53);
            this.btnSelectItemDelete1.TabIndex = 1821;
            this.btnSelectItemDelete1.Text = "ITEM DELETE";
            this.btnSelectItemDelete1.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnSelectItemAdd1
            // 
            this.btnSelectItemAdd1.BackColor = System.Drawing.Color.Silver;
            this.btnSelectItemAdd1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSelectItemAdd1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSelectItemAdd1.InnerBorderColor = System.Drawing.Color.White;
            this.btnSelectItemAdd1.Location = new System.Drawing.Point(416, 29);
            this.btnSelectItemAdd1.Name = "btnSelectItemAdd1";
            this.btnSelectItemAdd1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSelectItemAdd1.ShineColor = System.Drawing.Color.Silver;
            this.btnSelectItemAdd1.Size = new System.Drawing.Size(131, 53);
            this.btnSelectItemAdd1.TabIndex = 1820;
            this.btnSelectItemAdd1.Text = "ITEM ADD";
            this.btnSelectItemAdd1.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnItemDelete1
            // 
            this.btnItemDelete1.BackColor = System.Drawing.Color.Silver;
            this.btnItemDelete1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnItemDelete1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnItemDelete1.InnerBorderColor = System.Drawing.Color.White;
            this.btnItemDelete1.Location = new System.Drawing.Point(156, 29);
            this.btnItemDelete1.Name = "btnItemDelete1";
            this.btnItemDelete1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnItemDelete1.ShineColor = System.Drawing.Color.Silver;
            this.btnItemDelete1.Size = new System.Drawing.Size(131, 53);
            this.btnItemDelete1.TabIndex = 1821;
            this.btnItemDelete1.Text = "ITEM DELETE";
            this.btnItemDelete1.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnItemAdd1
            // 
            this.btnItemAdd1.BackColor = System.Drawing.Color.Silver;
            this.btnItemAdd1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnItemAdd1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnItemAdd1.InnerBorderColor = System.Drawing.Color.White;
            this.btnItemAdd1.Location = new System.Drawing.Point(19, 29);
            this.btnItemAdd1.Name = "btnItemAdd1";
            this.btnItemAdd1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnItemAdd1.ShineColor = System.Drawing.Color.Silver;
            this.btnItemAdd1.Size = new System.Drawing.Size(131, 53);
            this.btnItemAdd1.TabIndex = 1820;
            this.btnItemAdd1.Text = "ITEM ADD";
            this.btnItemAdd1.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // gridDp2
            // 
            this.gridDp2.AllowUserToAddRows = false;
            this.gridDp2.AllowUserToDeleteRows = false;
            this.gridDp2.AllowUserToResizeColumns = false;
            this.gridDp2.AllowUserToResizeRows = false;
            this.gridDp2.BackgroundColor = System.Drawing.Color.White;
            this.gridDp2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDp2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gridDp2.ColumnHeadersHeight = 30;
            this.gridDp2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridDp2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.Column7});
            this.gridDp2.GridColor = System.Drawing.Color.Gainsboro;
            this.gridDp2.Location = new System.Drawing.Point(717, 28);
            this.gridDp2.MultiSelect = false;
            this.gridDp2.Name = "gridDp2";
            this.gridDp2.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDp2.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gridDp2.RowHeadersVisible = false;
            this.gridDp2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridDp2.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.gridDp2.RowTemplate.Height = 30;
            this.gridDp2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridDp2.Size = new System.Drawing.Size(700, 799);
            this.gridDp2.TabIndex = 1801;
            this.gridDp2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDp2_CellClick);
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn5.HeaderText = "No";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 40;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn6.HeaderText = "RADIUS";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn7.HeaderText = "ANGLE";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 110;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "ENABLE";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 90;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "DELAY TIME";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 110;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Z OFFSET";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Z Up";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 60;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Pluse";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 90;
            // 
            // lbJetPosGridTitle1
            // 
            this.lbJetPosGridTitle1.BackColor = System.Drawing.Color.Silver;
            this.lbJetPosGridTitle1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbJetPosGridTitle1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbJetPosGridTitle1.Location = new System.Drawing.Point(717, 0);
            this.lbJetPosGridTitle1.Name = "lbJetPosGridTitle1";
            this.lbJetPosGridTitle1.Size = new System.Drawing.Size(703, 25);
            this.lbJetPosGridTitle1.TabIndex = 1800;
            this.lbJetPosGridTitle1.Tag = "3";
            this.lbJetPosGridTitle1.Text = "BONDER 2 JETTING POSITION SETTING";
            this.lbJetPosGridTitle1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbJetPosGridTitle1.Click += new System.EventHandler(this.lbBond1LineTitle_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblSelectRowIdx1);
            this.groupBox6.Controls.Add(this.btnSelectItemDelete);
            this.groupBox6.Controls.Add(this.btnSelectItemAdd);
            this.groupBox6.Controls.Add(this.btnItemDelete);
            this.groupBox6.Controls.Add(this.btnItemAdd);
            this.groupBox6.Location = new System.Drawing.Point(14, 833);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(689, 100);
            this.groupBox6.TabIndex = 1799;
            this.groupBox6.TabStop = false;
            // 
            // lblSelectRowIdx1
            // 
            this.lblSelectRowIdx1.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx1.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx1.Location = new System.Drawing.Point(313, 28);
            this.lblSelectRowIdx1.Name = "lblSelectRowIdx1";
            this.lblSelectRowIdx1.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx1.TabIndex = 1822;
            this.lblSelectRowIdx1.Text = "0";
            this.lblSelectRowIdx1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSelectItemDelete
            // 
            this.btnSelectItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnSelectItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSelectItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSelectItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnSelectItemDelete.Location = new System.Drawing.Point(538, 29);
            this.btnSelectItemDelete.Name = "btnSelectItemDelete";
            this.btnSelectItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSelectItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnSelectItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnSelectItemDelete.TabIndex = 1821;
            this.btnSelectItemDelete.Text = "SELECT\r\nITEM DELETE";
            this.btnSelectItemDelete.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnSelectItemAdd
            // 
            this.btnSelectItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnSelectItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSelectItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnSelectItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnSelectItemAdd.Location = new System.Drawing.Point(403, 29);
            this.btnSelectItemAdd.Name = "btnSelectItemAdd";
            this.btnSelectItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnSelectItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnSelectItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnSelectItemAdd.TabIndex = 1820;
            this.btnSelectItemAdd.Text = "SELECT\r\nITEM ADD";
            this.btnSelectItemAdd.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnItemDelete
            // 
            this.btnItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnItemDelete.Location = new System.Drawing.Point(152, 29);
            this.btnItemDelete.Name = "btnItemDelete";
            this.btnItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnItemDelete.TabIndex = 1821;
            this.btnItemDelete.Text = "ITEM DELETE";
            this.btnItemDelete.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // btnItemAdd
            // 
            this.btnItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnItemAdd.Location = new System.Drawing.Point(15, 29);
            this.btnItemAdd.Name = "btnItemAdd";
            this.btnItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnItemAdd.TabIndex = 1820;
            this.btnItemAdd.Text = "ITEM ADD";
            this.btnItemAdd.Click += new System.EventHandler(this.btnItemAdd_Click);
            // 
            // gridDp1
            // 
            this.gridDp1.AllowUserToAddRows = false;
            this.gridDp1.AllowUserToDeleteRows = false;
            this.gridDp1.AllowUserToResizeColumns = false;
            this.gridDp1.AllowUserToResizeRows = false;
            this.gridDp1.BackgroundColor = System.Drawing.Color.White;
            this.gridDp1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDp1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.gridDp1.ColumnHeadersHeight = 30;
            this.gridDp1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridDp1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.Column4,
            this.Column5,
            this.DEC,
            this.Column1,
            this.Column6});
            this.gridDp1.GridColor = System.Drawing.Color.Gainsboro;
            this.gridDp1.Location = new System.Drawing.Point(3, 28);
            this.gridDp1.MultiSelect = false;
            this.gridDp1.Name = "gridDp1";
            this.gridDp1.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDp1.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.gridDp1.RowHeadersVisible = false;
            this.gridDp1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridDp1.RowsDefaultCellStyle = dataGridViewCellStyle19;
            this.gridDp1.RowTemplate.Height = 30;
            this.gridDp1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridDp1.Size = new System.Drawing.Size(700, 799);
            this.gridDp1.TabIndex = 1798;
            this.gridDp1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDp1_CellClick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn2.HeaderText = "No";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 40;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn3.HeaderText = "RADIUS";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewTextBoxColumn4.HeaderText = "ANGLE";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 110;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "ENABLE";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 90;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "DELAY TIME";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 110;
            // 
            // DEC
            // 
            this.DEC.HeaderText = "Z OFFSET";
            this.DEC.Name = "DEC";
            this.DEC.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Z Up";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 60;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Pluse";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 80;
            // 
            // lbJetPosGridTitle
            // 
            this.lbJetPosGridTitle.BackColor = System.Drawing.Color.Silver;
            this.lbJetPosGridTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbJetPosGridTitle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbJetPosGridTitle.Location = new System.Drawing.Point(3, 0);
            this.lbJetPosGridTitle.Name = "lbJetPosGridTitle";
            this.lbJetPosGridTitle.Size = new System.Drawing.Size(700, 25);
            this.lbJetPosGridTitle.TabIndex = 1797;
            this.lbJetPosGridTitle.Tag = "2";
            this.lbJetPosGridTitle.Text = "BONDER 1 JETTING POSITION SETTING";
            this.lbJetPosGridTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbJetPosGridTitle.Click += new System.EventHandler(this.lbBond1LineTitle_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 39);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1420, 936);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "DISPENSER (PATTERN_LINE)";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.picVCM2);
            this.panel3.Controls.Add(this.picVCM1);
            this.panel3.Controls.Add(this.btnPatCurNum2);
            this.panel3.Controls.Add(this.btnPatPre2);
            this.panel3.Controls.Add(this.btnPatCurNum1);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.btnPatPre1);
            this.panel3.Controls.Add(this.lblPatCreate2);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.btnPatNext2);
            this.panel3.Controls.Add(this.lblPatCreate1);
            this.panel3.Controls.Add(this.btnPatNext1);
            this.panel3.Controls.Add(this.gridPLineDp1);
            this.panel3.Controls.Add(this.groupBox11);
            this.panel3.Controls.Add(this.gridPLineDp2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.groupBox12);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1420, 936);
            this.panel3.TabIndex = 2;
            // 
            // picVCM2
            // 
            this.picVCM2.Image = ((System.Drawing.Image)(resources.GetObject("picVCM2.Image")));
            this.picVCM2.Location = new System.Drawing.Point(918, 521);
            this.picVCM2.Name = "picVCM2";
            this.picVCM2.Size = new System.Drawing.Size(318, 318);
            this.picVCM2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVCM2.TabIndex = 1830;
            this.picVCM2.TabStop = false;
            // 
            // picVCM1
            // 
            this.picVCM1.Image = ((System.Drawing.Image)(resources.GetObject("picVCM1.Image")));
            this.picVCM1.Location = new System.Drawing.Point(217, 511);
            this.picVCM1.Name = "picVCM1";
            this.picVCM1.Size = new System.Drawing.Size(318, 318);
            this.picVCM1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVCM1.TabIndex = 1829;
            this.picVCM1.TabStop = false;
            // 
            // btnPatCurNum2
            // 
            this.btnPatCurNum2.BackColor = System.Drawing.Color.Silver;
            this.btnPatCurNum2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatCurNum2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatCurNum2.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatCurNum2.Location = new System.Drawing.Point(1240, 34);
            this.btnPatCurNum2.Name = "btnPatCurNum2";
            this.btnPatCurNum2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatCurNum2.ShineColor = System.Drawing.Color.Silver;
            this.btnPatCurNum2.Size = new System.Drawing.Size(70, 39);
            this.btnPatCurNum2.TabIndex = 1828;
            this.btnPatCurNum2.Text = "0";
            this.btnPatCurNum2.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // btnPatPre2
            // 
            this.btnPatPre2.BackColor = System.Drawing.Color.Silver;
            this.btnPatPre2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatPre2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatPre2.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatPre2.Location = new System.Drawing.Point(1166, 34);
            this.btnPatPre2.Name = "btnPatPre2";
            this.btnPatPre2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatPre2.ShineColor = System.Drawing.Color.Silver;
            this.btnPatPre2.Size = new System.Drawing.Size(70, 39);
            this.btnPatPre2.TabIndex = 1827;
            this.btnPatPre2.Text = "◀";
            this.btnPatPre2.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // btnPatCurNum1
            // 
            this.btnPatCurNum1.BackColor = System.Drawing.Color.Silver;
            this.btnPatCurNum1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatCurNum1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatCurNum1.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatCurNum1.Location = new System.Drawing.Point(523, 34);
            this.btnPatCurNum1.Name = "btnPatCurNum1";
            this.btnPatCurNum1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatCurNum1.ShineColor = System.Drawing.Color.Silver;
            this.btnPatCurNum1.Size = new System.Drawing.Size(70, 39);
            this.btnPatCurNum1.TabIndex = 1828;
            this.btnPatCurNum1.Text = "0";
            this.btnPatCurNum1.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(742, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 40);
            this.label11.TabIndex = 1826;
            this.label11.Text = "Pattern Create";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPatPre1
            // 
            this.btnPatPre1.BackColor = System.Drawing.Color.Silver;
            this.btnPatPre1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatPre1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatPre1.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatPre1.Location = new System.Drawing.Point(449, 34);
            this.btnPatPre1.Name = "btnPatPre1";
            this.btnPatPre1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatPre1.ShineColor = System.Drawing.Color.Silver;
            this.btnPatPre1.Size = new System.Drawing.Size(70, 39);
            this.btnPatPre1.TabIndex = 1827;
            this.btnPatPre1.Text = "◀";
            this.btnPatPre1.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // lblPatCreate2
            // 
            this.lblPatCreate2.BackColor = System.Drawing.Color.White;
            this.lblPatCreate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPatCreate2.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblPatCreate2.ForeColor = System.Drawing.Color.Black;
            this.lblPatCreate2.Location = new System.Drawing.Point(868, 33);
            this.lblPatCreate2.Name = "lblPatCreate2";
            this.lblPatCreate2.Size = new System.Drawing.Size(84, 40);
            this.lblPatCreate2.TabIndex = 1826;
            this.lblPatCreate2.Text = "0";
            this.lblPatCreate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPatCreate2.Click += new System.EventHandler(this.lblPatCreate1_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(25, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 40);
            this.label8.TabIndex = 1826;
            this.label8.Text = "Pattern Create";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPatNext2
            // 
            this.btnPatNext2.BackColor = System.Drawing.Color.Silver;
            this.btnPatNext2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatNext2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatNext2.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatNext2.Location = new System.Drawing.Point(1314, 34);
            this.btnPatNext2.Name = "btnPatNext2";
            this.btnPatNext2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatNext2.ShineColor = System.Drawing.Color.Silver;
            this.btnPatNext2.Size = new System.Drawing.Size(70, 39);
            this.btnPatNext2.TabIndex = 1825;
            this.btnPatNext2.Text = "▶";
            this.btnPatNext2.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // lblPatCreate1
            // 
            this.lblPatCreate1.BackColor = System.Drawing.Color.White;
            this.lblPatCreate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPatCreate1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblPatCreate1.ForeColor = System.Drawing.Color.Black;
            this.lblPatCreate1.Location = new System.Drawing.Point(151, 33);
            this.lblPatCreate1.Name = "lblPatCreate1";
            this.lblPatCreate1.Size = new System.Drawing.Size(84, 40);
            this.lblPatCreate1.TabIndex = 1826;
            this.lblPatCreate1.Text = "0";
            this.lblPatCreate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPatCreate1.Click += new System.EventHandler(this.lblPatCreate1_Click);
            // 
            // btnPatNext1
            // 
            this.btnPatNext1.BackColor = System.Drawing.Color.Silver;
            this.btnPatNext1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatNext1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPatNext1.InnerBorderColor = System.Drawing.Color.White;
            this.btnPatNext1.Location = new System.Drawing.Point(597, 34);
            this.btnPatNext1.Name = "btnPatNext1";
            this.btnPatNext1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPatNext1.ShineColor = System.Drawing.Color.Silver;
            this.btnPatNext1.Size = new System.Drawing.Size(70, 39);
            this.btnPatNext1.TabIndex = 1825;
            this.btnPatNext1.Text = "▶";
            this.btnPatNext1.Click += new System.EventHandler(this.btnPat_Click);
            // 
            // gridPLineDp1
            // 
            this.gridPLineDp1.AllowUserToAddRows = false;
            this.gridPLineDp1.AllowUserToDeleteRows = false;
            this.gridPLineDp1.AllowUserToResizeColumns = false;
            this.gridPLineDp1.AllowUserToResizeRows = false;
            this.gridPLineDp1.BackgroundColor = System.Drawing.Color.White;
            this.gridPLineDp1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPLineDp1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.gridPLineDp1.ColumnHeadersHeight = 30;
            this.gridPLineDp1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridPLineDp1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32});
            this.gridPLineDp1.GridColor = System.Drawing.Color.Gainsboro;
            this.gridPLineDp1.Location = new System.Drawing.Point(3, 80);
            this.gridPLineDp1.MultiSelect = false;
            this.gridPLineDp1.Name = "gridPLineDp1";
            this.gridPLineDp1.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPLineDp1.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.gridPLineDp1.RowHeadersVisible = false;
            this.gridPLineDp1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridPLineDp1.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.gridPLineDp1.RowTemplate.Height = 30;
            this.gridPLineDp1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridPLineDp1.Size = new System.Drawing.Size(700, 404);
            this.gridPLineDp1.TabIndex = 1798;
            this.gridPLineDp1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPLineDp1_CellClick);
            // 
            // dataGridViewTextBoxColumn26
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn26.DefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridViewTextBoxColumn26.HeaderText = "No";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn26.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn26.Width = 40;
            // 
            // dataGridViewTextBoxColumn27
            // 
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn27.DefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridViewTextBoxColumn27.HeaderText = "X Pos";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn27.Width = 110;
            // 
            // dataGridViewTextBoxColumn28
            // 
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn28.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn28.HeaderText = "Y Pos";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn28.Width = 110;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "Z Pos";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 90;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "Line Speed";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 110;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "Z Speed";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 110;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "Shot";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 110;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lblSelectRowIdx2PLine);
            this.groupBox11.Controls.Add(this.btnPLine2SelectItemDelete);
            this.groupBox11.Controls.Add(this.btnPLine2SelectItemAdd);
            this.groupBox11.Controls.Add(this.btnPLine2ItemDelete);
            this.groupBox11.Controls.Add(this.btnPLine2ItemAdd);
            this.groupBox11.Location = new System.Drawing.Point(717, 835);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(700, 93);
            this.groupBox11.TabIndex = 1802;
            this.groupBox11.TabStop = false;
            // 
            // lblSelectRowIdx2PLine
            // 
            this.lblSelectRowIdx2PLine.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx2PLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx2PLine.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx2PLine.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx2PLine.Location = new System.Drawing.Point(333, 28);
            this.lblSelectRowIdx2PLine.Name = "lblSelectRowIdx2PLine";
            this.lblSelectRowIdx2PLine.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx2PLine.TabIndex = 1823;
            this.lblSelectRowIdx2PLine.Text = "0";
            this.lblSelectRowIdx2PLine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPLine2SelectItemDelete
            // 
            this.btnPLine2SelectItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPLine2SelectItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine2SelectItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine2SelectItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine2SelectItemDelete.Location = new System.Drawing.Point(559, 29);
            this.btnPLine2SelectItemDelete.Name = "btnPLine2SelectItemDelete";
            this.btnPLine2SelectItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine2SelectItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine2SelectItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPLine2SelectItemDelete.TabIndex = 1821;
            this.btnPLine2SelectItemDelete.Text = "SELECT\r\nITEM DELETE";
            this.btnPLine2SelectItemDelete.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine2SelectItemAdd
            // 
            this.btnPLine2SelectItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPLine2SelectItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine2SelectItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine2SelectItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine2SelectItemAdd.Location = new System.Drawing.Point(423, 29);
            this.btnPLine2SelectItemAdd.Name = "btnPLine2SelectItemAdd";
            this.btnPLine2SelectItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine2SelectItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine2SelectItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPLine2SelectItemAdd.TabIndex = 1820;
            this.btnPLine2SelectItemAdd.Text = "SELECT\r\nITEM ADD";
            this.btnPLine2SelectItemAdd.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine2ItemDelete
            // 
            this.btnPLine2ItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPLine2ItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine2ItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine2ItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine2ItemDelete.Location = new System.Drawing.Point(152, 29);
            this.btnPLine2ItemDelete.Name = "btnPLine2ItemDelete";
            this.btnPLine2ItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine2ItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine2ItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPLine2ItemDelete.TabIndex = 1821;
            this.btnPLine2ItemDelete.Text = "ITEM DELETE";
            this.btnPLine2ItemDelete.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine2ItemAdd
            // 
            this.btnPLine2ItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPLine2ItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine2ItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine2ItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine2ItemAdd.Location = new System.Drawing.Point(15, 29);
            this.btnPLine2ItemAdd.Name = "btnPLine2ItemAdd";
            this.btnPLine2ItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine2ItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine2ItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPLine2ItemAdd.TabIndex = 1820;
            this.btnPLine2ItemAdd.Text = "ITEM ADD";
            this.btnPLine2ItemAdd.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // gridPLineDp2
            // 
            this.gridPLineDp2.AllowUserToAddRows = false;
            this.gridPLineDp2.AllowUserToDeleteRows = false;
            this.gridPLineDp2.AllowUserToResizeColumns = false;
            this.gridPLineDp2.AllowUserToResizeRows = false;
            this.gridPLineDp2.BackgroundColor = System.Drawing.Color.White;
            this.gridPLineDp2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPLineDp2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.gridPLineDp2.ColumnHeadersHeight = 30;
            this.gridPLineDp2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridPLineDp2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39});
            this.gridPLineDp2.GridColor = System.Drawing.Color.Gainsboro;
            this.gridPLineDp2.Location = new System.Drawing.Point(717, 80);
            this.gridPLineDp2.MultiSelect = false;
            this.gridPLineDp2.Name = "gridPLineDp2";
            this.gridPLineDp2.ReadOnly = true;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPLineDp2.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.gridPLineDp2.RowHeadersVisible = false;
            this.gridPLineDp2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridPLineDp2.RowsDefaultCellStyle = dataGridViewCellStyle31;
            this.gridPLineDp2.RowTemplate.Height = 30;
            this.gridPLineDp2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridPLineDp2.Size = new System.Drawing.Size(700, 404);
            this.gridPLineDp2.TabIndex = 1801;
            this.gridPLineDp2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPLineDp2_CellClick);
            // 
            // dataGridViewTextBoxColumn33
            // 
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn33.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn33.HeaderText = "No";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Width = 40;
            // 
            // dataGridViewTextBoxColumn34
            // 
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn34.DefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridViewTextBoxColumn34.HeaderText = "X Pos";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn34.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn34.Width = 110;
            // 
            // dataGridViewTextBoxColumn35
            // 
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn35.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn35.HeaderText = "Y Pos";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn35.Width = 110;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "Z Pos";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 90;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.HeaderText = "Line Speed";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 110;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.HeaderText = "Z Speed";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Width = 110;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.HeaderText = "Shot";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Width = 110;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(717, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(703, 25);
            this.label4.TabIndex = 1800;
            this.label4.Text = "BONDER 2 JETTING POSITION SETTING";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.lblSelectRowIdx1PLine);
            this.groupBox12.Controls.Add(this.btnPLine1SelectItemDelete);
            this.groupBox12.Controls.Add(this.btnPLine1SelectItemAdd);
            this.groupBox12.Controls.Add(this.btnPLine1ItemDelete);
            this.groupBox12.Controls.Add(this.btnPLine1ItemAdd);
            this.groupBox12.Location = new System.Drawing.Point(14, 835);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(689, 93);
            this.groupBox12.TabIndex = 1799;
            this.groupBox12.TabStop = false;
            // 
            // lblSelectRowIdx1PLine
            // 
            this.lblSelectRowIdx1PLine.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx1PLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx1PLine.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx1PLine.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx1PLine.Location = new System.Drawing.Point(316, 28);
            this.lblSelectRowIdx1PLine.Name = "lblSelectRowIdx1PLine";
            this.lblSelectRowIdx1PLine.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx1PLine.TabIndex = 1823;
            this.lblSelectRowIdx1PLine.Text = "0";
            this.lblSelectRowIdx1PLine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPLine1SelectItemDelete
            // 
            this.btnPLine1SelectItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPLine1SelectItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine1SelectItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine1SelectItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine1SelectItemDelete.Location = new System.Drawing.Point(543, 29);
            this.btnPLine1SelectItemDelete.Name = "btnPLine1SelectItemDelete";
            this.btnPLine1SelectItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine1SelectItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine1SelectItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPLine1SelectItemDelete.TabIndex = 1821;
            this.btnPLine1SelectItemDelete.Text = "SELECT\r\nITEM DELETE";
            this.btnPLine1SelectItemDelete.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine1SelectItemAdd
            // 
            this.btnPLine1SelectItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPLine1SelectItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine1SelectItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine1SelectItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine1SelectItemAdd.Location = new System.Drawing.Point(406, 29);
            this.btnPLine1SelectItemAdd.Name = "btnPLine1SelectItemAdd";
            this.btnPLine1SelectItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine1SelectItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine1SelectItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPLine1SelectItemAdd.TabIndex = 1820;
            this.btnPLine1SelectItemAdd.Text = "SELECT\r\nITEM ADD";
            this.btnPLine1SelectItemAdd.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine1ItemDelete
            // 
            this.btnPLine1ItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPLine1ItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine1ItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine1ItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine1ItemDelete.Location = new System.Drawing.Point(143, 29);
            this.btnPLine1ItemDelete.Name = "btnPLine1ItemDelete";
            this.btnPLine1ItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine1ItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine1ItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPLine1ItemDelete.TabIndex = 1821;
            this.btnPLine1ItemDelete.Text = "ITEM DELETE";
            this.btnPLine1ItemDelete.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // btnPLine1ItemAdd
            // 
            this.btnPLine1ItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPLine1ItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPLine1ItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPLine1ItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPLine1ItemAdd.Location = new System.Drawing.Point(6, 29);
            this.btnPLine1ItemAdd.Name = "btnPLine1ItemAdd";
            this.btnPLine1ItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPLine1ItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPLine1ItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPLine1ItemAdd.TabIndex = 1820;
            this.btnPLine1ItemAdd.Text = "ITEM ADD";
            this.btnPLine1ItemAdd.Click += new System.EventHandler(this.btnPLineItemAdd_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Silver;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(700, 25);
            this.label6.TabIndex = 1797;
            this.label6.Text = "BONDER 1 JETTING POSITION SETTING";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 39);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1420, 936);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "DISPENSER (PATTERN_ARC)";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.gridPArcDp2);
            this.panel2.Controls.Add(this.gridPArcDp1);
            this.panel2.Controls.Add(this.picVCMArc2);
            this.panel2.Controls.Add(this.picVCMArc1);
            this.panel2.Controls.Add(this.btnArcCurNum2);
            this.panel2.Controls.Add(this.btnArcPre2);
            this.panel2.Controls.Add(this.btnArcCurNum1);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.btnArcPre1);
            this.panel2.Controls.Add(this.lblArcCreate2);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.btnArcNext2);
            this.panel2.Controls.Add(this.lblArcCreate1);
            this.panel2.Controls.Add(this.btnArcNext1);
            this.panel2.Controls.Add(this.groupBox10);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.groupBox16);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1414, 930);
            this.panel2.TabIndex = 3;
            // 
            // gridPArcDp2
            // 
            this.gridPArcDp2.AllowUserToAddRows = false;
            this.gridPArcDp2.AllowUserToDeleteRows = false;
            this.gridPArcDp2.AllowUserToResizeColumns = false;
            this.gridPArcDp2.AllowUserToResizeRows = false;
            this.gridPArcDp2.BackgroundColor = System.Drawing.Color.White;
            this.gridPArcDp2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPArcDp2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.gridPArcDp2.ColumnHeadersHeight = 30;
            this.gridPArcDp2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridPArcDp2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.Column11,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn40,
            this.Column8});
            this.gridPArcDp2.GridColor = System.Drawing.Color.Gainsboro;
            this.gridPArcDp2.Location = new System.Drawing.Point(711, 92);
            this.gridPArcDp2.MultiSelect = false;
            this.gridPArcDp2.Name = "gridPArcDp2";
            this.gridPArcDp2.ReadOnly = true;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPArcDp2.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.gridPArcDp2.RowHeadersVisible = false;
            this.gridPArcDp2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridPArcDp2.RowsDefaultCellStyle = dataGridViewCellStyle37;
            this.gridPArcDp2.RowTemplate.Height = 30;
            this.gridPArcDp2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridPArcDp2.Size = new System.Drawing.Size(701, 404);
            this.gridPArcDp2.TabIndex = 1832;
            this.gridPArcDp2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPArcDp2_CellClick);
            // 
            // dataGridViewTextBoxColumn19
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn19.HeaderText = "No";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn19.Width = 40;
            // 
            // dataGridViewTextBoxColumn20
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn20.HeaderText = "Pos X";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Width = 90;
            // 
            // dataGridViewTextBoxColumn21
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn21.HeaderText = "Pos Y";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn21.Width = 90;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.HeaderText = "Pos Z";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 90;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Angle";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 90;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "Speed";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "Shot";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.Width = 80;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "TYPE";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 90;
            // 
            // gridPArcDp1
            // 
            this.gridPArcDp1.AllowUserToAddRows = false;
            this.gridPArcDp1.AllowUserToDeleteRows = false;
            this.gridPArcDp1.AllowUserToResizeColumns = false;
            this.gridPArcDp1.AllowUserToResizeRows = false;
            this.gridPArcDp1.BackgroundColor = System.Drawing.Color.White;
            this.gridPArcDp1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPArcDp1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle38;
            this.gridPArcDp1.ColumnHeadersHeight = 30;
            this.gridPArcDp1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridPArcDp1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.Column9,
            this.Column10,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn15});
            this.gridPArcDp1.GridColor = System.Drawing.Color.Gainsboro;
            this.gridPArcDp1.Location = new System.Drawing.Point(5, 92);
            this.gridPArcDp1.MultiSelect = false;
            this.gridPArcDp1.Name = "gridPArcDp1";
            this.gridPArcDp1.ReadOnly = true;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridPArcDp1.RowHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.gridPArcDp1.RowHeadersVisible = false;
            this.gridPArcDp1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gridPArcDp1.RowsDefaultCellStyle = dataGridViewCellStyle43;
            this.gridPArcDp1.RowTemplate.Height = 30;
            this.gridPArcDp1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridPArcDp1.Size = new System.Drawing.Size(701, 404);
            this.gridPArcDp1.TabIndex = 1831;
            this.gridPArcDp1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPArcDp1_CellClick);
            // 
            // dataGridViewTextBoxColumn12
            // 
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewTextBoxColumn12.HeaderText = "No";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 40;
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridViewTextBoxColumn13.HeaderText = "Pos X";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 90;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewTextBoxColumn14.HeaderText = "Pos Y";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Width = 90;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Pos Z";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 90;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Angle";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 90;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "Speed";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "Shot";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 80;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "TYPE";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 90;
            // 
            // picVCMArc2
            // 
            this.picVCMArc2.Image = ((System.Drawing.Image)(resources.GetObject("picVCMArc2.Image")));
            this.picVCMArc2.Location = new System.Drawing.Point(918, 511);
            this.picVCMArc2.Name = "picVCMArc2";
            this.picVCMArc2.Size = new System.Drawing.Size(318, 318);
            this.picVCMArc2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVCMArc2.TabIndex = 1830;
            this.picVCMArc2.TabStop = false;
            // 
            // picVCMArc1
            // 
            this.picVCMArc1.Image = ((System.Drawing.Image)(resources.GetObject("picVCMArc1.Image")));
            this.picVCMArc1.Location = new System.Drawing.Point(217, 511);
            this.picVCMArc1.Name = "picVCMArc1";
            this.picVCMArc1.Size = new System.Drawing.Size(318, 318);
            this.picVCMArc1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVCMArc1.TabIndex = 1829;
            this.picVCMArc1.TabStop = false;
            // 
            // btnArcCurNum2
            // 
            this.btnArcCurNum2.BackColor = System.Drawing.Color.Silver;
            this.btnArcCurNum2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcCurNum2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcCurNum2.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcCurNum2.Location = new System.Drawing.Point(1240, 34);
            this.btnArcCurNum2.Name = "btnArcCurNum2";
            this.btnArcCurNum2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcCurNum2.ShineColor = System.Drawing.Color.Silver;
            this.btnArcCurNum2.Size = new System.Drawing.Size(70, 39);
            this.btnArcCurNum2.TabIndex = 1828;
            this.btnArcCurNum2.Text = "0";
            this.btnArcCurNum2.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // btnArcPre2
            // 
            this.btnArcPre2.BackColor = System.Drawing.Color.Silver;
            this.btnArcPre2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcPre2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcPre2.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcPre2.Location = new System.Drawing.Point(1166, 34);
            this.btnArcPre2.Name = "btnArcPre2";
            this.btnArcPre2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcPre2.ShineColor = System.Drawing.Color.Silver;
            this.btnArcPre2.Size = new System.Drawing.Size(70, 39);
            this.btnArcPre2.TabIndex = 1827;
            this.btnArcPre2.Text = "◀";
            this.btnArcPre2.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // btnArcCurNum1
            // 
            this.btnArcCurNum1.BackColor = System.Drawing.Color.Silver;
            this.btnArcCurNum1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcCurNum1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcCurNum1.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcCurNum1.Location = new System.Drawing.Point(523, 34);
            this.btnArcCurNum1.Name = "btnArcCurNum1";
            this.btnArcCurNum1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcCurNum1.ShineColor = System.Drawing.Color.Silver;
            this.btnArcCurNum1.Size = new System.Drawing.Size(70, 39);
            this.btnArcCurNum1.TabIndex = 1828;
            this.btnArcCurNum1.Text = "0";
            this.btnArcCurNum1.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(742, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(124, 40);
            this.label21.TabIndex = 1826;
            this.label21.Text = "Pattern Create";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnArcPre1
            // 
            this.btnArcPre1.BackColor = System.Drawing.Color.Silver;
            this.btnArcPre1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcPre1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcPre1.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcPre1.Location = new System.Drawing.Point(449, 34);
            this.btnArcPre1.Name = "btnArcPre1";
            this.btnArcPre1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcPre1.ShineColor = System.Drawing.Color.Silver;
            this.btnArcPre1.Size = new System.Drawing.Size(70, 39);
            this.btnArcPre1.TabIndex = 1827;
            this.btnArcPre1.Text = "◀";
            this.btnArcPre1.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // lblArcCreate2
            // 
            this.lblArcCreate2.BackColor = System.Drawing.Color.White;
            this.lblArcCreate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblArcCreate2.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblArcCreate2.ForeColor = System.Drawing.Color.Black;
            this.lblArcCreate2.Location = new System.Drawing.Point(868, 33);
            this.lblArcCreate2.Name = "lblArcCreate2";
            this.lblArcCreate2.Size = new System.Drawing.Size(84, 40);
            this.lblArcCreate2.TabIndex = 1826;
            this.lblArcCreate2.Text = "0";
            this.lblArcCreate2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblArcCreate2.Click += new System.EventHandler(this.lblPatCreate1_Click);
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(25, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(124, 40);
            this.label26.TabIndex = 1826;
            this.label26.Text = "Pattern Create";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnArcNext2
            // 
            this.btnArcNext2.BackColor = System.Drawing.Color.Silver;
            this.btnArcNext2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcNext2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcNext2.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcNext2.Location = new System.Drawing.Point(1314, 34);
            this.btnArcNext2.Name = "btnArcNext2";
            this.btnArcNext2.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcNext2.ShineColor = System.Drawing.Color.Silver;
            this.btnArcNext2.Size = new System.Drawing.Size(70, 39);
            this.btnArcNext2.TabIndex = 1825;
            this.btnArcNext2.Text = "▶";
            this.btnArcNext2.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // lblArcCreate1
            // 
            this.lblArcCreate1.BackColor = System.Drawing.Color.White;
            this.lblArcCreate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblArcCreate1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblArcCreate1.ForeColor = System.Drawing.Color.Black;
            this.lblArcCreate1.Location = new System.Drawing.Point(151, 33);
            this.lblArcCreate1.Name = "lblArcCreate1";
            this.lblArcCreate1.Size = new System.Drawing.Size(84, 40);
            this.lblArcCreate1.TabIndex = 1826;
            this.lblArcCreate1.Text = "0";
            this.lblArcCreate1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblArcCreate1.Click += new System.EventHandler(this.lblPatCreate1_Click);
            // 
            // btnArcNext1
            // 
            this.btnArcNext1.BackColor = System.Drawing.Color.Silver;
            this.btnArcNext1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArcNext1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnArcNext1.InnerBorderColor = System.Drawing.Color.White;
            this.btnArcNext1.Location = new System.Drawing.Point(597, 34);
            this.btnArcNext1.Name = "btnArcNext1";
            this.btnArcNext1.OuterBorderColor = System.Drawing.Color.Black;
            this.btnArcNext1.ShineColor = System.Drawing.Color.Silver;
            this.btnArcNext1.Size = new System.Drawing.Size(70, 39);
            this.btnArcNext1.TabIndex = 1825;
            this.btnArcNext1.Text = "▶";
            this.btnArcNext1.Click += new System.EventHandler(this.btnArc_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lblSelectRowIdx2PArc);
            this.groupBox10.Controls.Add(this.btnPArc2SelectItemDelete);
            this.groupBox10.Controls.Add(this.btnPArc2SelectItemAdd);
            this.groupBox10.Controls.Add(this.btnPArc2ItemDelete);
            this.groupBox10.Controls.Add(this.btnPArc2ItemAdd);
            this.groupBox10.Location = new System.Drawing.Point(717, 835);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(700, 93);
            this.groupBox10.TabIndex = 1802;
            this.groupBox10.TabStop = false;
            // 
            // lblSelectRowIdx2PArc
            // 
            this.lblSelectRowIdx2PArc.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx2PArc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx2PArc.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx2PArc.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx2PArc.Location = new System.Drawing.Point(333, 28);
            this.lblSelectRowIdx2PArc.Name = "lblSelectRowIdx2PArc";
            this.lblSelectRowIdx2PArc.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx2PArc.TabIndex = 1823;
            this.lblSelectRowIdx2PArc.Text = "0";
            this.lblSelectRowIdx2PArc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPArc2SelectItemDelete
            // 
            this.btnPArc2SelectItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPArc2SelectItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc2SelectItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc2SelectItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc2SelectItemDelete.Location = new System.Drawing.Point(559, 29);
            this.btnPArc2SelectItemDelete.Name = "btnPArc2SelectItemDelete";
            this.btnPArc2SelectItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc2SelectItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc2SelectItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPArc2SelectItemDelete.TabIndex = 1821;
            this.btnPArc2SelectItemDelete.Text = "SELECT\r\nITEM DELETE";
            this.btnPArc2SelectItemDelete.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc2SelectItemAdd
            // 
            this.btnPArc2SelectItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPArc2SelectItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc2SelectItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc2SelectItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc2SelectItemAdd.Location = new System.Drawing.Point(423, 29);
            this.btnPArc2SelectItemAdd.Name = "btnPArc2SelectItemAdd";
            this.btnPArc2SelectItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc2SelectItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc2SelectItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPArc2SelectItemAdd.TabIndex = 1820;
            this.btnPArc2SelectItemAdd.Text = "SELECT\r\nITEM ADD";
            this.btnPArc2SelectItemAdd.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc2ItemDelete
            // 
            this.btnPArc2ItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPArc2ItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc2ItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc2ItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc2ItemDelete.Location = new System.Drawing.Point(152, 29);
            this.btnPArc2ItemDelete.Name = "btnPArc2ItemDelete";
            this.btnPArc2ItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc2ItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc2ItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPArc2ItemDelete.TabIndex = 1821;
            this.btnPArc2ItemDelete.Text = "ITEM DELETE";
            this.btnPArc2ItemDelete.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc2ItemAdd
            // 
            this.btnPArc2ItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPArc2ItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc2ItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc2ItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc2ItemAdd.Location = new System.Drawing.Point(15, 29);
            this.btnPArc2ItemAdd.Name = "btnPArc2ItemAdd";
            this.btnPArc2ItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc2ItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc2ItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPArc2ItemAdd.TabIndex = 1820;
            this.btnPArc2ItemAdd.Text = "ITEM ADD";
            this.btnPArc2ItemAdd.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Silver;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(717, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(703, 25);
            this.label29.TabIndex = 1800;
            this.label29.Text = "BONDER 2 JETTING POSITION SETTING";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.lblSelectRowIdx1PArc);
            this.groupBox16.Controls.Add(this.btnPArc1SelectItemDelete);
            this.groupBox16.Controls.Add(this.btnPArc1SelectItemAdd);
            this.groupBox16.Controls.Add(this.btnPArc1ItemDelete);
            this.groupBox16.Controls.Add(this.btnPArc1ItemAdd);
            this.groupBox16.Location = new System.Drawing.Point(14, 835);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(689, 93);
            this.groupBox16.TabIndex = 1799;
            this.groupBox16.TabStop = false;
            // 
            // lblSelectRowIdx1PArc
            // 
            this.lblSelectRowIdx1PArc.BackColor = System.Drawing.Color.White;
            this.lblSelectRowIdx1PArc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectRowIdx1PArc.Font = new System.Drawing.Font("Tahoma", 12F);
            this.lblSelectRowIdx1PArc.ForeColor = System.Drawing.Color.Black;
            this.lblSelectRowIdx1PArc.Location = new System.Drawing.Point(316, 28);
            this.lblSelectRowIdx1PArc.Name = "lblSelectRowIdx1PArc";
            this.lblSelectRowIdx1PArc.Size = new System.Drawing.Size(84, 54);
            this.lblSelectRowIdx1PArc.TabIndex = 1823;
            this.lblSelectRowIdx1PArc.Text = "0";
            this.lblSelectRowIdx1PArc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPArc1SelectItemDelete
            // 
            this.btnPArc1SelectItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPArc1SelectItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc1SelectItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc1SelectItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc1SelectItemDelete.Location = new System.Drawing.Point(543, 29);
            this.btnPArc1SelectItemDelete.Name = "btnPArc1SelectItemDelete";
            this.btnPArc1SelectItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc1SelectItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc1SelectItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPArc1SelectItemDelete.TabIndex = 1821;
            this.btnPArc1SelectItemDelete.Text = "SELECT\r\nITEM DELETE";
            this.btnPArc1SelectItemDelete.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc1SelectItemAdd
            // 
            this.btnPArc1SelectItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPArc1SelectItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc1SelectItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc1SelectItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc1SelectItemAdd.Location = new System.Drawing.Point(406, 29);
            this.btnPArc1SelectItemAdd.Name = "btnPArc1SelectItemAdd";
            this.btnPArc1SelectItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc1SelectItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc1SelectItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPArc1SelectItemAdd.TabIndex = 1820;
            this.btnPArc1SelectItemAdd.Text = "SELECT\r\nITEM ADD";
            this.btnPArc1SelectItemAdd.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc1ItemDelete
            // 
            this.btnPArc1ItemDelete.BackColor = System.Drawing.Color.Silver;
            this.btnPArc1ItemDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc1ItemDelete.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc1ItemDelete.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc1ItemDelete.Location = new System.Drawing.Point(143, 29);
            this.btnPArc1ItemDelete.Name = "btnPArc1ItemDelete";
            this.btnPArc1ItemDelete.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc1ItemDelete.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc1ItemDelete.Size = new System.Drawing.Size(131, 53);
            this.btnPArc1ItemDelete.TabIndex = 1821;
            this.btnPArc1ItemDelete.Text = "ITEM DELETE";
            this.btnPArc1ItemDelete.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // btnPArc1ItemAdd
            // 
            this.btnPArc1ItemAdd.BackColor = System.Drawing.Color.Silver;
            this.btnPArc1ItemAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPArc1ItemAdd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnPArc1ItemAdd.InnerBorderColor = System.Drawing.Color.White;
            this.btnPArc1ItemAdd.Location = new System.Drawing.Point(6, 29);
            this.btnPArc1ItemAdd.Name = "btnPArc1ItemAdd";
            this.btnPArc1ItemAdd.OuterBorderColor = System.Drawing.Color.Black;
            this.btnPArc1ItemAdd.ShineColor = System.Drawing.Color.Silver;
            this.btnPArc1ItemAdd.Size = new System.Drawing.Size(131, 53);
            this.btnPArc1ItemAdd.TabIndex = 1820;
            this.btnPArc1ItemAdd.Text = "ITEM ADD";
            this.btnPArc1ItemAdd.Click += new System.EventHandler(this.btnPArcItemAdd_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Silver;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(3, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(700, 25);
            this.label31.TabIndex = 1797;
            this.label31.Text = "BONDER 1 JETTING POSITION SETTING";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmPageRecipeProject
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1790, 995);
            this.Controls.Add(this.a1Panel11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPageRecipeProject";
            this.Text = "FormPageRecipeProject";
            this.Load += new System.EventHandler(this.FormPageRecipeProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.a1Panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picVCM)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPageGeneral.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.gbLanguageOption.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.gbMachineOption.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.gbRunOption.ResumeLayout(false);
            this.gbSequenceOption.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDp2)).EndInit();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDp1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picVCM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCM1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPLineDp1)).EndInit();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridPLineDp2)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridPArcDp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPArcDp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCMArc2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVCMArc1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Glass.GlassButton btnSaveAs;
        private Glass.GlassButton btnOpen;
        internal System.Windows.Forms.DataGridView grid;
        private Glass.GlassButton btnDelete;
        private Owf.Controls.A1Panel a1Panel11;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.PictureBox picVCM;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageGeneral;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label lblUseActRetry;
        private Glass.GlassButton btnUseActRetry;
        private System.Windows.Forms.Label lblbtnUseActAndCure;
        private Glass.GlassButton btnUseActAndCure;
        private System.Windows.Forms.Label lbActuator_2_Mode;
        private System.Windows.Forms.Label lbActuator_1_Mode;
        private Glass.GlassButton btnActuator_2_Mode;
        private Glass.GlassButton btnActuator_1_Mode;
        private System.Windows.Forms.GroupBox groupBox2;
        private Glass.GlassButton btnUnloaderMagazine;
        private System.Windows.Forms.Label lbLoaderMagazine;
        private System.Windows.Forms.Label lbUnloaderMagazine;
        private Glass.GlassButton btnLoaderMagazine;
        private Glass.GlassButton btnLensMagazine;
        private System.Windows.Forms.Label lbLensMagazine;
        private System.Windows.Forms.GroupBox gbMachineOption;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbUseDummy2;
        private System.Windows.Forms.Label lbUseDummy1;
        private Glass.GlassButton btnUseDummy2;
        private Glass.GlassButton btnUseDummy1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDummyPeriodCount2;
        private System.Windows.Forms.Label lblDummyPeriodCount1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lbUsePlusenum_2;
        private System.Windows.Forms.Label label10;
        private Glass.GlassButton btnUsePlusenum_2;
        private System.Windows.Forms.Label lbUsePlusenum_1;
        private Glass.GlassButton btnUsePlusenum_1;
        private System.Windows.Forms.Label lblDummyTime2;
        private Glass.GlassButton btnJettingMode_2;
        private Glass.GlassButton btnJettingMode_1;
        private System.Windows.Forms.Label lblUseTipClean2;
        private System.Windows.Forms.Label lblDummyTime1;
        private System.Windows.Forms.Label lbUseIdle2;
        private System.Windows.Forms.Label lblUseTipClean1;
        private System.Windows.Forms.Label lbUseIdle1;
        private Glass.GlassButton btnUseTipClean2;
        private Glass.GlassButton btnUseIdle2;
        private Glass.GlassButton btnUseTipClean1;
        private Glass.GlassButton btnUseIdle1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Glass.GlassButton btnLensHeightReslut;
        private System.Windows.Forms.Label lbVisionResult;
        private System.Windows.Forms.Label lbLensHeightResult;
        private Glass.GlassButton btnVisionResult;
        private Glass.GlassButton btnJigPlateAngleResult;
        private Glass.GlassButton btnSideAngleResult;
        private System.Windows.Forms.Label lbSideAngleResult;
        private System.Windows.Forms.Label lbJigFlatnessResult;
        private System.Windows.Forms.GroupBox gbRunOption;
        private Glass.GlassButton btnVisionCheck;
        private System.Windows.Forms.Label lbVisionCheck;
        private Glass.GlassButton btnIndexCheck;
        private System.Windows.Forms.Label lbVacuumCheck;
        private System.Windows.Forms.Label lbIndexCheck;
        private Glass.GlassButton btnVacuumCheck;
        private Glass.GlassButton btnTrayCheck;
        private System.Windows.Forms.Label lbTrayCheck;
        private System.Windows.Forms.GroupBox gbSequenceOption;
        private Glass.GlassButton btnUseCureVisionFail;
        private System.Windows.Forms.Label lbUseCureVisionFail;
        private Glass.GlassButton btnUseBonder2;
        private Glass.GlassButton btnUseCuring2;
        private System.Windows.Forms.Label lbUseCuring2;
        private System.Windows.Forms.Label lbUseBonder2;
        private Glass.GlassButton btnUseBonder1;
        private Glass.GlassButton btnUseCuring1;
        private System.Windows.Forms.Label lbUseCuring1;
        private System.Windows.Forms.Label lbUseBonder1;
        private Glass.GlassButton btnUseVision;
        private System.Windows.Forms.Label lbUseVision;
        private Glass.GlassButton btnUsePlateAngle;
        private System.Windows.Forms.Label lbUseJigPlateAngle;
        private System.Windows.Forms.Label lbUsePlateAngle;
        private Glass.GlassButton btnUseJigPlateAngle;
        private Glass.GlassButton btnUseCleanJig;
        private Glass.GlassButton btnUseLensHeight;
        private System.Windows.Forms.Label lbUseLensHeight;
        private System.Windows.Forms.Label lbUseCleanJig;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label lblSelectRowIdx2;
        private Glass.GlassButton btnSelectItemDelete1;
        private Glass.GlassButton btnSelectItemAdd1;
        private Glass.GlassButton btnItemDelete1;
        private Glass.GlassButton btnItemAdd1;
        private System.Windows.Forms.DataGridView gridDp2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.Label lbJetPosGridTitle1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lblSelectRowIdx1;
        private Glass.GlassButton btnSelectItemDelete;
        private Glass.GlassButton btnSelectItemAdd;
        private Glass.GlassButton btnItemDelete;
        private Glass.GlassButton btnItemAdd;
        private System.Windows.Forms.DataGridView gridDp1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label lbJetPosGridTitle;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox picVCM2;
        private System.Windows.Forms.PictureBox picVCM1;
        private Glass.GlassButton btnPatCurNum2;
        private Glass.GlassButton btnPatPre2;
        private Glass.GlassButton btnPatCurNum1;
        private System.Windows.Forms.Label label11;
        private Glass.GlassButton btnPatPre1;
        private System.Windows.Forms.Label lblPatCreate2;
        private System.Windows.Forms.Label label8;
        private Glass.GlassButton btnPatNext2;
        private System.Windows.Forms.Label lblPatCreate1;
        private Glass.GlassButton btnPatNext1;
        private System.Windows.Forms.DataGridView gridPLineDp1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label lblSelectRowIdx2PLine;
        private Glass.GlassButton btnPLine2SelectItemDelete;
        private Glass.GlassButton btnPLine2SelectItemAdd;
        private Glass.GlassButton btnPLine2ItemDelete;
        private Glass.GlassButton btnPLine2ItemAdd;
        private System.Windows.Forms.DataGridView gridPLineDp2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label lblSelectRowIdx1PLine;
        private Glass.GlassButton btnPLine1SelectItemDelete;
        private Glass.GlassButton btnPLine1SelectItemAdd;
        private Glass.GlassButton btnPLine1ItemDelete;
        private Glass.GlassButton btnPLine1ItemAdd;
        private System.Windows.Forms.Label label6;
        private Glass.GlassButton btnRename;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox picVCMArc2;
        private System.Windows.Forms.PictureBox picVCMArc1;
        private Glass.GlassButton btnArcCurNum2;
        private Glass.GlassButton btnArcPre2;
        private Glass.GlassButton btnArcCurNum1;
        private System.Windows.Forms.Label label21;
        private Glass.GlassButton btnArcPre1;
        private System.Windows.Forms.Label lblArcCreate2;
        private System.Windows.Forms.Label label26;
        private Glass.GlassButton btnArcNext2;
        private System.Windows.Forms.Label lblArcCreate1;
        private Glass.GlassButton btnArcNext1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label lblSelectRowIdx2PArc;
        private Glass.GlassButton btnPArc2SelectItemDelete;
        private Glass.GlassButton btnPArc2SelectItemAdd;
        private Glass.GlassButton btnPArc2ItemDelete;
        private Glass.GlassButton btnPArc2ItemAdd;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label lblSelectRowIdx1PArc;
        private Glass.GlassButton btnPArc1SelectItemDelete;
        private Glass.GlassButton btnPArc1SelectItemAdd;
        private Glass.GlassButton btnPArc1ItemDelete;
        private Glass.GlassButton btnPArc1ItemAdd;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblUseActNotAction2;
        private Glass.GlassButton btnUseActNotAction2;
        private System.Windows.Forms.Label lblUseActNotAction1;
        private Glass.GlassButton btnUseActNotAction1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblVisionVer;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label lblUseMES;
        private Glass.GlassButton btnUseMES;
        private System.Windows.Forms.DataGridView gridPArcDp2;
        private System.Windows.Forms.DataGridView gridPArcDp1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.Label lbPreAct;
        private Glass.GlassButton btnPreAct;
        private System.Windows.Forms.Label lbActuator_3_Mode;
        private Glass.GlassButton btnActuator_3_Mode;
        private Glass.GlassButton btnUseAct3;
        private System.Windows.Forms.Label lbUseAct3;
        private Glass.GlassButton btnUseLensPicker;
        private System.Windows.Forms.Label lbUseLensPicker;
        private System.Windows.Forms.Label lbAlCooling2;
        private System.Windows.Forms.Label lbAlCooling1;
        private Glass.GlassButton btnUseCooling2;
        private Glass.GlassButton btnUseCooling1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox gbLanguageOption;
        private Glass.GlassButton btnLanguage;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbBonder2GapPosY;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbBonder2GapPosX;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbBonder1GapPosY;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbBonder1GapPosX;
        private System.Windows.Forms.Label lbUseGap;
        private Glass.GlassButton btnUseGap;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label lbVisionRetry;
        private System.Windows.Forms.Label lbVisionRetryCount;
        private System.Windows.Forms.Label lbBonder2Retry;
        private System.Windows.Forms.Label lbBonder2RetryCount;
        private System.Windows.Forms.Label lbBonder1Retry;
        private System.Windows.Forms.Label lbBonder1RetryCount;
        private System.Windows.Forms.Label lbLensBottomRetry;
        private System.Windows.Forms.Label lbLensBottomRetryCount;
        private System.Windows.Forms.Label lbLensUpperRetry;
        private System.Windows.Forms.Label lbLensUpperRetryCount;
        private System.Windows.Forms.Label lbVCMVisionRetry;
        private System.Windows.Forms.Label lbVCMVISIONRetryCount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lbSecondaryLimitValue;
        private System.Windows.Forms.Label lbUseSecondaryCorrection;
        private Glass.GlassButton btnSecondaryCorrection;
        private System.Windows.Forms.Label label19;
        private Glass.GlassButton btnAssembleMode;
        private System.Windows.Forms.Label lbLensThetaTorque;
        private Glass.GlassButton btnLensThetaTorque;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbTorqueTLimit;
        private System.Windows.Forms.Label lbLensPickUpTorque;
        private Glass.GlassButton btnLensPickUpTorque;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbTorqueLimitZ;
        private System.Windows.Forms.Label lbLensInsertTorque;
        private Glass.GlassButton btnLensInsertTorque;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label lbUseResultRowDataJudge;
        private Glass.GlassButton btnUseResultRowDataJudge;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbRnRShift;
        private System.Windows.Forms.Label lblResultDummyPass;
        private Glass.GlassButton BtnResultDummyPass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbRnRGain;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblLensAllowMin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblLensHeight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLensAllowMax;
        private System.Windows.Forms.Label lbLensHeightSoftWareJudge;
        private Glass.GlassButton btnLensHeightSoftWareJudge;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbResetTime1;
        private System.Windows.Forms.Label lbResetTime2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label lbUseMeasureContact;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lbPlateAngleGood;
        private Glass.GlassButton btnUseContact;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbPlateAngleRetry;
    }
}