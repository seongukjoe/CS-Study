﻿namespace XModule.Forms.FormConfig
{
    partial class FrmPageConfigAnalog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPageConfigAnalog));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.a1Panel1 = new Owf.Controls.A1Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gridStatus = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbDescriptionValue = new System.Windows.Forms.Label();
            this.lbIndexValue = new System.Windows.Forms.Label();
            this.lbStyleValue = new System.Windows.Forms.Label();
            this.lbNoValue = new System.Windows.Forms.Label();
            this.btnIndex = new Glass.GlassButton();
            this.btnNo = new Glass.GlassButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnDisable = new Glass.GlassButton();
            this.btnEnable = new Glass.GlassButton();
            this.a1Panel11 = new Owf.Controls.A1Panel();
            this.grid = new System.Windows.Forms.DataGridView();
            this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.a1Panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridStatus)).BeginInit();
            this.a1Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // a1Panel1
            // 
            this.a1Panel1.BackColor = System.Drawing.Color.DarkGray;
            this.a1Panel1.BorderColor = System.Drawing.Color.Black;
            this.a1Panel1.BorderWidth = 2;
            this.a1Panel1.Controls.Add(this.groupBox1);
            this.a1Panel1.Controls.Add(this.label20);
            this.a1Panel1.Controls.Add(this.label19);
            this.a1Panel1.Controls.Add(this.btnDisable);
            this.a1Panel1.Controls.Add(this.btnEnable);
            this.a1Panel1.GradientEndColor = System.Drawing.Color.White;
            this.a1Panel1.GradientStartColor = System.Drawing.Color.White;
            this.a1Panel1.Image = null;
            this.a1Panel1.ImageLocation = new System.Drawing.Point(4, 4);
            this.a1Panel1.Location = new System.Drawing.Point(0, 775);
            this.a1Panel1.Name = "a1Panel1";
            this.a1Panel1.RoundCornerRadius = 12;
            this.a1Panel1.ShadowOffSet = 1;
            this.a1Panel1.Size = new System.Drawing.Size(1788, 220);
            this.a1Panel1.TabIndex = 191;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.gridStatus);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lbDescriptionValue);
            this.groupBox1.Controls.Add(this.lbIndexValue);
            this.groupBox1.Controls.Add(this.lbStyleValue);
            this.groupBox1.Controls.Add(this.lbNoValue);
            this.groupBox1.Controls.Add(this.btnIndex);
            this.groupBox1.Controls.Add(this.btnNo);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.groupBox1.Location = new System.Drawing.Point(10, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1768, 212);
            this.groupBox1.TabIndex = 978;
            this.groupBox1.TabStop = false;
            // 
            // gridStatus
            // 
            this.gridStatus.AllowUserToAddRows = false;
            this.gridStatus.AllowUserToDeleteRows = false;
            this.gridStatus.AllowUserToResizeColumns = false;
            this.gridStatus.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("바탕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.gridStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gridStatus.BackgroundColor = System.Drawing.Color.White;
            this.gridStatus.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            this.gridStatus.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridStatus.ColumnHeadersHeight = 35;
            this.gridStatus.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.Column1,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.RoyalBlue;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridStatus.DefaultCellStyle = dataGridViewCellStyle4;
            this.gridStatus.GridColor = System.Drawing.Color.Silver;
            this.gridStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.gridStatus.Location = new System.Drawing.Point(4, 95);
            this.gridStatus.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.gridStatus.MultiSelect = false;
            this.gridStatus.Name = "gridStatus";
            this.gridStatus.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridStatus.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gridStatus.RowHeadersVisible = false;
            this.gridStatus.RowHeadersWidth = 30;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("바탕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            this.gridStatus.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.gridStatus.RowTemplate.Height = 30;
            this.gridStatus.ShowCellErrors = false;
            this.gridStatus.ShowEditingIcon = false;
            this.gridStatus.ShowRowErrors = false;
            this.gridStatus.Size = new System.Drawing.Size(1764, 110);
            this.gridStatus.StandardTab = true;
            this.gridStatus.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.DimGray;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(6, 55);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label14.Size = new System.Drawing.Size(157, 34);
            this.label14.TabIndex = 976;
            this.label14.Text = "DESCRIPTION";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.DimGray;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(6, 18);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label7.Size = new System.Drawing.Size(157, 34);
            this.label7.TabIndex = 975;
            this.label7.Text = "INDEX";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbDescriptionValue
            // 
            this.lbDescriptionValue.BackColor = System.Drawing.SystemColors.Window;
            this.lbDescriptionValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDescriptionValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lbDescriptionValue.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbDescriptionValue.Location = new System.Drawing.Point(169, 55);
            this.lbDescriptionValue.Name = "lbDescriptionValue";
            this.lbDescriptionValue.Padding = new System.Windows.Forms.Padding(5, 2, 0, 3);
            this.lbDescriptionValue.Size = new System.Drawing.Size(274, 34);
            this.lbDescriptionValue.TabIndex = 973;
            this.lbDescriptionValue.Text = "...";
            this.lbDescriptionValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIndexValue
            // 
            this.lbIndexValue.BackColor = System.Drawing.SystemColors.Window;
            this.lbIndexValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbIndexValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lbIndexValue.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbIndexValue.Location = new System.Drawing.Point(169, 17);
            this.lbIndexValue.Name = "lbIndexValue";
            this.lbIndexValue.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.lbIndexValue.Size = new System.Drawing.Size(220, 34);
            this.lbIndexValue.TabIndex = 972;
            this.lbIndexValue.Text = "...";
            this.lbIndexValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbStyleValue
            // 
            this.lbStyleValue.BackColor = System.Drawing.SystemColors.Window;
            this.lbStyleValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbStyleValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lbStyleValue.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbStyleValue.Location = new System.Drawing.Point(1537, 18);
            this.lbStyleValue.Name = "lbStyleValue";
            this.lbStyleValue.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.lbStyleValue.Size = new System.Drawing.Size(225, 34);
            this.lbStyleValue.TabIndex = 972;
            this.lbStyleValue.Text = "...";
            this.lbStyleValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbNoValue
            // 
            this.lbNoValue.BackColor = System.Drawing.SystemColors.Window;
            this.lbNoValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbNoValue.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lbNoValue.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lbNoValue.Location = new System.Drawing.Point(1537, 55);
            this.lbNoValue.Name = "lbNoValue";
            this.lbNoValue.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.lbNoValue.Size = new System.Drawing.Size(146, 34);
            this.lbNoValue.TabIndex = 972;
            this.lbNoValue.Text = "...";
            this.lbNoValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnIndex
            // 
            this.btnIndex.BackColor = System.Drawing.Color.DarkGray;
            this.btnIndex.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnIndex.ForeColor = System.Drawing.Color.Black;
            this.btnIndex.GlowColor = System.Drawing.Color.Transparent;
            this.btnIndex.Image = ((System.Drawing.Image)(resources.GetObject("btnIndex.Image")));
            this.btnIndex.InnerBorderColor = System.Drawing.Color.White;
            this.btnIndex.Location = new System.Drawing.Point(393, 17);
            this.btnIndex.Name = "btnIndex";
            this.btnIndex.OuterBorderColor = System.Drawing.Color.Black;
            this.btnIndex.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnIndex.Size = new System.Drawing.Size(49, 34);
            this.btnIndex.TabIndex = 963;
            this.btnIndex.TabStop = false;
            this.btnIndex.Tag = "0";
            this.btnIndex.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIndex.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.DarkGray;
            this.btnNo.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnNo.ForeColor = System.Drawing.Color.Black;
            this.btnNo.GlowColor = System.Drawing.Color.Transparent;
            this.btnNo.InnerBorderColor = System.Drawing.Color.White;
            this.btnNo.Location = new System.Drawing.Point(1689, 55);
            this.btnNo.Name = "btnNo";
            this.btnNo.OuterBorderColor = System.Drawing.Color.Black;
            this.btnNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnNo.Size = new System.Drawing.Size(73, 34);
            this.btnNo.TabIndex = 963;
            this.btnNo.TabStop = false;
            this.btnNo.Tag = "1";
            this.btnNo.Text = "Set";
            this.btnNo.Click += new System.EventHandler(this.ConfigurationClick);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.DimGray;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1368, 18);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label9.Size = new System.Drawing.Size(163, 34);
            this.label9.TabIndex = 7;
            this.label9.Text = "STYLE";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DimGray;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1368, 55);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(5, 2, 0, 0);
            this.label3.Size = new System.Drawing.Size(163, 34);
            this.label3.TabIndex = 7;
            this.label3.Text = "BOARD NO.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.LightGray;
            this.label20.Font = new System.Drawing.Font("Tahoma", 5F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Maroon;
            this.label20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label20.Location = new System.Drawing.Point(1651, 230);
            this.label20.Name = "label20";
            this.label20.Padding = new System.Windows.Forms.Padding(5, 2, 2, 3);
            this.label20.Size = new System.Drawing.Size(38, 12);
            this.label20.TabIndex = 977;
            this.label20.Text = "STATUS";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.LightGray;
            this.label19.Font = new System.Drawing.Font("Tahoma", 5F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.Maroon;
            this.label19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label19.Location = new System.Drawing.Point(1509, 230);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(5, 2, 2, 3);
            this.label19.Size = new System.Drawing.Size(38, 12);
            this.label19.TabIndex = 976;
            this.label19.Text = "STATUS";
            // 
            // btnDisable
            // 
            this.btnDisable.BackColor = System.Drawing.Color.DarkGray;
            this.btnDisable.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnDisable.ForeColor = System.Drawing.Color.Black;
            this.btnDisable.GlowColor = System.Drawing.Color.Transparent;
            this.btnDisable.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDisable.InnerBorderColor = System.Drawing.Color.White;
            this.btnDisable.Location = new System.Drawing.Point(1645, 227);
            this.btnDisable.Name = "btnDisable";
            this.btnDisable.OuterBorderColor = System.Drawing.Color.Black;
            this.btnDisable.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDisable.Size = new System.Drawing.Size(133, 49);
            this.btnDisable.TabIndex = 974;
            this.btnDisable.TabStop = false;
            this.btnDisable.Tag = "1";
            this.btnDisable.Text = "DISABLE";
            this.btnDisable.Click += new System.EventHandler(this.ActionClick);
            // 
            // btnEnable
            // 
            this.btnEnable.BackColor = System.Drawing.Color.DarkGray;
            this.btnEnable.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnEnable.ForeColor = System.Drawing.Color.Black;
            this.btnEnable.GlowColor = System.Drawing.Color.Transparent;
            this.btnEnable.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEnable.InnerBorderColor = System.Drawing.Color.White;
            this.btnEnable.Location = new System.Drawing.Point(1504, 227);
            this.btnEnable.Name = "btnEnable";
            this.btnEnable.OuterBorderColor = System.Drawing.Color.Black;
            this.btnEnable.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnEnable.Size = new System.Drawing.Size(133, 49);
            this.btnEnable.TabIndex = 975;
            this.btnEnable.TabStop = false;
            this.btnEnable.Tag = "0";
            this.btnEnable.Text = "ENABLE";
            this.btnEnable.Click += new System.EventHandler(this.ActionClick);
            // 
            // a1Panel11
            // 
            this.a1Panel11.BackColor = System.Drawing.Color.DarkGray;
            this.a1Panel11.BorderColor = System.Drawing.Color.Black;
            this.a1Panel11.BorderWidth = 2;
            this.a1Panel11.Controls.Add(this.grid);
            this.a1Panel11.GradientEndColor = System.Drawing.Color.White;
            this.a1Panel11.GradientStartColor = System.Drawing.Color.White;
            this.a1Panel11.Image = null;
            this.a1Panel11.ImageLocation = new System.Drawing.Point(4, 4);
            this.a1Panel11.Location = new System.Drawing.Point(0, 0);
            this.a1Panel11.Name = "a1Panel11";
            this.a1Panel11.RoundCornerRadius = 12;
            this.a1Panel11.ShadowOffSet = 1;
            this.a1Panel11.Size = new System.Drawing.Size(1788, 774);
            this.a1Panel11.TabIndex = 190;
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.AllowUserToResizeColumns = false;
            this.grid.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("바탕", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.grid.BackgroundColor = System.Drawing.Color.White;
            this.grid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.grid.ColumnHeadersHeight = 35;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewTextBoxColumn1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("바탕체", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid.DefaultCellStyle = dataGridViewCellStyle9;
            this.grid.GridColor = System.Drawing.Color.Silver;
            this.grid.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grid.Location = new System.Drawing.Point(10, 10);
            this.grid.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.grid.MultiSelect = false;
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.grid.RowHeadersVisible = false;
            this.grid.RowHeadersWidth = 30;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("바탕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            this.grid.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.grid.RowTemplate.Height = 23;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.ShowCellErrors = false;
            this.grid.ShowEditingIcon = false;
            this.grid.ShowRowErrors = false;
            this.grid.Size = new System.Drawing.Size(1768, 758);
            this.grid.StandardTab = true;
            this.grid.TabIndex = 6;
            this.grid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_CellClick);
            // 
            // DataGridViewTextBoxColumn1
            // 
            this.DataGridViewTextBoxColumn1.HeaderText = "INDEX";
            this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
            this.DataGridViewTextBoxColumn1.ReadOnly = true;
            this.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DataGridViewTextBoxColumn1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "STYLE";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "DISCRIPTION";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 1200;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "NO.";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 70;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "STATUS";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 195;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn2.HeaderText = "INDEX";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 160;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "0";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "1";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "2";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "3";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "4";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "5";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "6";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "7";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "8";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "9";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "10";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "11";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "12";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "13";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "14";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "15";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // FrmPageConfigAnalog
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1790, 995);
            this.ControlBox = false;
            this.Controls.Add(this.a1Panel1);
            this.Controls.Add(this.a1Panel11);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPageConfigAnalog";
            this.ShowIcon = false;
            this.Text = "FormPageConfigDigital";
            this.Load += new System.EventHandler(this.FrmPageConfigAnalog_Load);
            this.a1Panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridStatus)).EndInit();
            this.a1Panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Owf.Controls.A1Panel a1Panel1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private Glass.GlassButton btnDisable;
        private Glass.GlassButton btnEnable;
        private System.Windows.Forms.Label lbDescriptionValue;
        private System.Windows.Forms.Label lbIndexValue;
        private System.Windows.Forms.Label lbStyleValue;
        private System.Windows.Forms.Label lbNoValue;
        private Glass.GlassButton btnIndex;
        private Glass.GlassButton btnNo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private Owf.Controls.A1Panel a1Panel11;
        internal System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.DataGridView gridStatus;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
    }
}