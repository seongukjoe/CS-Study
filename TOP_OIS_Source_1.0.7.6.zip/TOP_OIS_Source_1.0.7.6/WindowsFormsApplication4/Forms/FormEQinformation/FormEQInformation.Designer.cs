﻿namespace XModule.Forms.FormOperation
{
    partial class FormInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInformation));
            this.b1 = new Glass.GlassButton();
            this.b2 = new Glass.GlassButton();
            this.b3 = new Glass.GlassButton();
            this.b4 = new Glass.GlassButton();
            this.b5 = new Glass.GlassButton();
            this.b6 = new Glass.GlassButton();
            this.b7 = new Glass.GlassButton();
            this.b8 = new Glass.GlassButton();
            this.b9 = new Glass.GlassButton();
            this.b10 = new Glass.GlassButton();
            this.b11 = new Glass.GlassButton();
            this.b12 = new Glass.GlassButton();
            this.b13 = new Glass.GlassButton();
            this.b14 = new Glass.GlassButton();
            this.b15 = new Glass.GlassButton();
            this.b16 = new Glass.GlassButton();
            this.b17 = new Glass.GlassButton();
            this.b18 = new Glass.GlassButton();
            this.b19 = new Glass.GlassButton();
            this.b20 = new Glass.GlassButton();
            this.b23 = new Glass.GlassButton();
            this.b22 = new Glass.GlassButton();
            this.b21 = new Glass.GlassButton();
            this.b24 = new Glass.GlassButton();
            this.b25 = new Glass.GlassButton();
            this.lbAddress = new System.Windows.Forms.Label();
            this.lbAddress_ = new System.Windows.Forms.Label();
            this.lbContact = new System.Windows.Forms.Label();
            this.lbTel = new System.Windows.Forms.Label();
            this.lbFax = new System.Windows.Forms.Label();
            this.lbEmail = new System.Windows.Forms.Label();
            this.b0 = new Glass.GlassButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.b26 = new Glass.GlassButton();
            this.b27 = new Glass.GlassButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Silver;
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b1.GlowColor = System.Drawing.Color.Transparent;
            this.b1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b1.InnerBorderColor = System.Drawing.Color.White;
            this.b1.Location = new System.Drawing.Point(312, 54);
            this.b1.Name = "b1";
            this.b1.OuterBorderColor = System.Drawing.Color.Black;
            this.b1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b1.ShineColor = System.Drawing.Color.Silver;
            this.b1.Size = new System.Drawing.Size(263, 36);
            this.b1.TabIndex = 1395;
            this.b1.TabStop = false;
            this.b1.Tag = "0";
            this.b1.Text = "Model No";
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Silver;
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b2.GlowColor = System.Drawing.Color.Transparent;
            this.b2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b2.InnerBorderColor = System.Drawing.Color.White;
            this.b2.Location = new System.Drawing.Point(312, 96);
            this.b2.Name = "b2";
            this.b2.OuterBorderColor = System.Drawing.Color.Black;
            this.b2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b2.ShineColor = System.Drawing.Color.Silver;
            this.b2.Size = new System.Drawing.Size(263, 36);
            this.b2.TabIndex = 1396;
            this.b2.TabStop = false;
            this.b2.Tag = "0";
            this.b2.Text = "S/N";
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Silver;
            this.b3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b3.GlowColor = System.Drawing.Color.Transparent;
            this.b3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b3.InnerBorderColor = System.Drawing.Color.White;
            this.b3.Location = new System.Drawing.Point(312, 138);
            this.b3.Name = "b3";
            this.b3.OuterBorderColor = System.Drawing.Color.Black;
            this.b3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b3.ShineColor = System.Drawing.Color.Silver;
            this.b3.Size = new System.Drawing.Size(263, 36);
            this.b3.TabIndex = 1397;
            this.b3.TabStop = false;
            this.b3.Tag = "0";
            this.b3.Text = "Size";
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Silver;
            this.b4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b4.GlowColor = System.Drawing.Color.Transparent;
            this.b4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b4.InnerBorderColor = System.Drawing.Color.White;
            this.b4.Location = new System.Drawing.Point(312, 180);
            this.b4.Name = "b4";
            this.b4.OuterBorderColor = System.Drawing.Color.Black;
            this.b4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b4.ShineColor = System.Drawing.Color.Silver;
            this.b4.Size = new System.Drawing.Size(263, 36);
            this.b4.TabIndex = 1400;
            this.b4.TabStop = false;
            this.b4.Tag = "0";
            this.b4.Text = "Weight";
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Silver;
            this.b5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b5.GlowColor = System.Drawing.Color.Transparent;
            this.b5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b5.InnerBorderColor = System.Drawing.Color.White;
            this.b5.Location = new System.Drawing.Point(312, 222);
            this.b5.Name = "b5";
            this.b5.OuterBorderColor = System.Drawing.Color.Black;
            this.b5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b5.ShineColor = System.Drawing.Color.Silver;
            this.b5.Size = new System.Drawing.Size(263, 36);
            this.b5.TabIndex = 1399;
            this.b5.TabStop = false;
            this.b5.Tag = "0";
            this.b5.Text = "Power1";
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Silver;
            this.b6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b6.GlowColor = System.Drawing.Color.Transparent;
            this.b6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b6.InnerBorderColor = System.Drawing.Color.White;
            this.b6.Location = new System.Drawing.Point(312, 264);
            this.b6.Name = "b6";
            this.b6.OuterBorderColor = System.Drawing.Color.Black;
            this.b6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b6.ShineColor = System.Drawing.Color.Silver;
            this.b6.Size = new System.Drawing.Size(263, 36);
            this.b6.TabIndex = 1398;
            this.b6.TabStop = false;
            this.b6.Tag = "0";
            this.b6.Text = "Power2";
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.Silver;
            this.b7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b7.GlowColor = System.Drawing.Color.Transparent;
            this.b7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b7.InnerBorderColor = System.Drawing.Color.White;
            this.b7.Location = new System.Drawing.Point(312, 306);
            this.b7.Name = "b7";
            this.b7.OuterBorderColor = System.Drawing.Color.Black;
            this.b7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b7.ShineColor = System.Drawing.Color.Silver;
            this.b7.Size = new System.Drawing.Size(263, 36);
            this.b7.TabIndex = 1401;
            this.b7.TabStop = false;
            this.b7.Tag = "0";
            this.b7.Text = "CDA1";
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.Silver;
            this.b8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b8.GlowColor = System.Drawing.Color.Transparent;
            this.b8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b8.InnerBorderColor = System.Drawing.Color.White;
            this.b8.Location = new System.Drawing.Point(312, 348);
            this.b8.Name = "b8";
            this.b8.OuterBorderColor = System.Drawing.Color.Black;
            this.b8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b8.ShineColor = System.Drawing.Color.Silver;
            this.b8.Size = new System.Drawing.Size(263, 36);
            this.b8.TabIndex = 1402;
            this.b8.TabStop = false;
            this.b8.Tag = "0";
            this.b8.Text = "VAC1";
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.Silver;
            this.b9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b9.GlowColor = System.Drawing.Color.Transparent;
            this.b9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b9.InnerBorderColor = System.Drawing.Color.White;
            this.b9.Location = new System.Drawing.Point(312, 390);
            this.b9.Name = "b9";
            this.b9.OuterBorderColor = System.Drawing.Color.Black;
            this.b9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b9.ShineColor = System.Drawing.Color.Silver;
            this.b9.Size = new System.Drawing.Size(263, 36);
            this.b9.TabIndex = 1403;
            this.b9.TabStop = false;
            this.b9.Tag = "0";
            this.b9.Text = "Manufacturing Data";
            // 
            // b10
            // 
            this.b10.BackColor = System.Drawing.Color.Silver;
            this.b10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b10.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b10.GlowColor = System.Drawing.Color.Transparent;
            this.b10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b10.InnerBorderColor = System.Drawing.Color.White;
            this.b10.Location = new System.Drawing.Point(312, 432);
            this.b10.Name = "b10";
            this.b10.OuterBorderColor = System.Drawing.Color.Black;
            this.b10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b10.ShineColor = System.Drawing.Color.Silver;
            this.b10.Size = new System.Drawing.Size(263, 36);
            this.b10.TabIndex = 1404;
            this.b10.TabStop = false;
            this.b10.Tag = "0";
            this.b10.Text = "Certifiction laboratory";
            // 
            // b11
            // 
            this.b11.BackColor = System.Drawing.Color.Silver;
            this.b11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b11.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b11.GlowColor = System.Drawing.Color.Transparent;
            this.b11.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b11.InnerBorderColor = System.Drawing.Color.White;
            this.b11.Location = new System.Drawing.Point(312, 474);
            this.b11.Name = "b11";
            this.b11.OuterBorderColor = System.Drawing.Color.Black;
            this.b11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b11.ShineColor = System.Drawing.Color.Silver;
            this.b11.Size = new System.Drawing.Size(263, 36);
            this.b11.TabIndex = 1405;
            this.b11.TabStop = false;
            this.b11.Tag = "0";
            this.b11.Text = "Certification Auditor";
            // 
            // b12
            // 
            this.b12.BackColor = System.Drawing.Color.Silver;
            this.b12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b12.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b12.GlowColor = System.Drawing.Color.Transparent;
            this.b12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b12.InnerBorderColor = System.Drawing.Color.White;
            this.b12.Location = new System.Drawing.Point(312, 516);
            this.b12.Name = "b12";
            this.b12.OuterBorderColor = System.Drawing.Color.Black;
            this.b12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b12.ShineColor = System.Drawing.Color.Silver;
            this.b12.Size = new System.Drawing.Size(263, 36);
            this.b12.TabIndex = 1406;
            this.b12.TabStop = false;
            this.b12.Tag = "0";
            this.b12.Text = "Process Testing Lab.";
            // 
            // b13
            // 
            this.b13.BackColor = System.Drawing.Color.Silver;
            this.b13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b13.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b13.GlowColor = System.Drawing.Color.Transparent;
            this.b13.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b13.InnerBorderColor = System.Drawing.Color.White;
            this.b13.Location = new System.Drawing.Point(312, 558);
            this.b13.Name = "b13";
            this.b13.OuterBorderColor = System.Drawing.Color.Black;
            this.b13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b13.ShineColor = System.Drawing.Color.Silver;
            this.b13.Size = new System.Drawing.Size(263, 36);
            this.b13.TabIndex = 1407;
            this.b13.TabStop = false;
            this.b13.Tag = "0";
            this.b13.Text = "Tester";
            // 
            // b14
            // 
            this.b14.BackColor = System.Drawing.Color.Silver;
            this.b14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b14.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b14.GlowColor = System.Drawing.Color.Transparent;
            this.b14.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b14.InnerBorderColor = System.Drawing.Color.White;
            this.b14.Location = new System.Drawing.Point(581, 13);
            this.b14.Name = "b14";
            this.b14.OuterBorderColor = System.Drawing.Color.Black;
            this.b14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b14.ShineColor = System.Drawing.Color.Silver;
            this.b14.Size = new System.Drawing.Size(263, 36);
            this.b14.TabIndex = 1420;
            this.b14.TabStop = false;
            this.b14.Tag = "0";
            this.b14.Text = "Name";
            // 
            // b15
            // 
            this.b15.BackColor = System.Drawing.Color.Silver;
            this.b15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b15.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b15.GlowColor = System.Drawing.Color.Transparent;
            this.b15.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b15.InnerBorderColor = System.Drawing.Color.White;
            this.b15.Location = new System.Drawing.Point(581, 55);
            this.b15.Name = "b15";
            this.b15.OuterBorderColor = System.Drawing.Color.Black;
            this.b15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b15.ShineColor = System.Drawing.Color.Silver;
            this.b15.Size = new System.Drawing.Size(263, 36);
            this.b15.TabIndex = 1419;
            this.b15.TabStop = false;
            this.b15.Tag = "0";
            this.b15.Text = "Name";
            // 
            // b16
            // 
            this.b16.BackColor = System.Drawing.Color.Silver;
            this.b16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b16.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b16.GlowColor = System.Drawing.Color.Transparent;
            this.b16.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b16.InnerBorderColor = System.Drawing.Color.White;
            this.b16.Location = new System.Drawing.Point(581, 97);
            this.b16.Name = "b16";
            this.b16.OuterBorderColor = System.Drawing.Color.Black;
            this.b16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b16.ShineColor = System.Drawing.Color.Silver;
            this.b16.Size = new System.Drawing.Size(263, 36);
            this.b16.TabIndex = 1418;
            this.b16.TabStop = false;
            this.b16.Tag = "0";
            this.b16.Text = "Name";
            // 
            // b17
            // 
            this.b17.BackColor = System.Drawing.Color.Silver;
            this.b17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b17.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b17.GlowColor = System.Drawing.Color.Transparent;
            this.b17.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b17.InnerBorderColor = System.Drawing.Color.White;
            this.b17.Location = new System.Drawing.Point(581, 139);
            this.b17.Name = "b17";
            this.b17.OuterBorderColor = System.Drawing.Color.Black;
            this.b17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b17.ShineColor = System.Drawing.Color.Silver;
            this.b17.Size = new System.Drawing.Size(263, 36);
            this.b17.TabIndex = 1417;
            this.b17.TabStop = false;
            this.b17.Tag = "0";
            this.b17.Text = "Name";
            // 
            // b18
            // 
            this.b18.BackColor = System.Drawing.Color.Silver;
            this.b18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b18.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b18.GlowColor = System.Drawing.Color.Transparent;
            this.b18.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b18.InnerBorderColor = System.Drawing.Color.White;
            this.b18.Location = new System.Drawing.Point(581, 181);
            this.b18.Name = "b18";
            this.b18.OuterBorderColor = System.Drawing.Color.Black;
            this.b18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b18.ShineColor = System.Drawing.Color.Silver;
            this.b18.Size = new System.Drawing.Size(263, 36);
            this.b18.TabIndex = 1416;
            this.b18.TabStop = false;
            this.b18.Tag = "0";
            this.b18.Text = "Name";
            // 
            // b19
            // 
            this.b19.BackColor = System.Drawing.Color.Silver;
            this.b19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b19.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b19.GlowColor = System.Drawing.Color.Transparent;
            this.b19.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b19.InnerBorderColor = System.Drawing.Color.White;
            this.b19.Location = new System.Drawing.Point(581, 223);
            this.b19.Name = "b19";
            this.b19.OuterBorderColor = System.Drawing.Color.Black;
            this.b19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b19.ShineColor = System.Drawing.Color.Silver;
            this.b19.Size = new System.Drawing.Size(263, 36);
            this.b19.TabIndex = 1415;
            this.b19.TabStop = false;
            this.b19.Tag = "0";
            this.b19.Text = "Name";
            // 
            // b20
            // 
            this.b20.BackColor = System.Drawing.Color.Silver;
            this.b20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b20.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b20.GlowColor = System.Drawing.Color.Transparent;
            this.b20.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b20.InnerBorderColor = System.Drawing.Color.White;
            this.b20.Location = new System.Drawing.Point(581, 265);
            this.b20.Name = "b20";
            this.b20.OuterBorderColor = System.Drawing.Color.Black;
            this.b20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b20.ShineColor = System.Drawing.Color.Silver;
            this.b20.Size = new System.Drawing.Size(263, 36);
            this.b20.TabIndex = 1414;
            this.b20.TabStop = false;
            this.b20.Tag = "0";
            this.b20.Text = "Name";
            // 
            // b23
            // 
            this.b23.BackColor = System.Drawing.Color.Silver;
            this.b23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b23.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b23.GlowColor = System.Drawing.Color.Transparent;
            this.b23.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b23.InnerBorderColor = System.Drawing.Color.White;
            this.b23.Location = new System.Drawing.Point(581, 391);
            this.b23.Name = "b23";
            this.b23.OuterBorderColor = System.Drawing.Color.Black;
            this.b23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b23.ShineColor = System.Drawing.Color.Silver;
            this.b23.Size = new System.Drawing.Size(263, 36);
            this.b23.TabIndex = 1413;
            this.b23.TabStop = false;
            this.b23.Tag = "0";
            this.b23.Text = "Name";
            // 
            // b22
            // 
            this.b22.BackColor = System.Drawing.Color.Silver;
            this.b22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b22.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b22.GlowColor = System.Drawing.Color.Transparent;
            this.b22.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b22.InnerBorderColor = System.Drawing.Color.White;
            this.b22.Location = new System.Drawing.Point(581, 349);
            this.b22.Name = "b22";
            this.b22.OuterBorderColor = System.Drawing.Color.Black;
            this.b22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b22.ShineColor = System.Drawing.Color.Silver;
            this.b22.Size = new System.Drawing.Size(263, 36);
            this.b22.TabIndex = 1412;
            this.b22.TabStop = false;
            this.b22.Tag = "0";
            this.b22.Text = "Name";
            // 
            // b21
            // 
            this.b21.BackColor = System.Drawing.Color.Silver;
            this.b21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b21.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b21.GlowColor = System.Drawing.Color.Transparent;
            this.b21.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b21.InnerBorderColor = System.Drawing.Color.White;
            this.b21.Location = new System.Drawing.Point(581, 307);
            this.b21.Name = "b21";
            this.b21.OuterBorderColor = System.Drawing.Color.Black;
            this.b21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b21.ShineColor = System.Drawing.Color.Silver;
            this.b21.Size = new System.Drawing.Size(263, 36);
            this.b21.TabIndex = 1411;
            this.b21.TabStop = false;
            this.b21.Tag = "0";
            this.b21.Text = "Name";
            // 
            // b24
            // 
            this.b24.BackColor = System.Drawing.Color.Silver;
            this.b24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b24.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b24.GlowColor = System.Drawing.Color.Transparent;
            this.b24.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b24.InnerBorderColor = System.Drawing.Color.White;
            this.b24.Location = new System.Drawing.Point(581, 433);
            this.b24.Name = "b24";
            this.b24.OuterBorderColor = System.Drawing.Color.Black;
            this.b24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b24.ShineColor = System.Drawing.Color.Silver;
            this.b24.Size = new System.Drawing.Size(263, 36);
            this.b24.TabIndex = 1410;
            this.b24.TabStop = false;
            this.b24.Tag = "0";
            this.b24.Text = "Name";
            // 
            // b25
            // 
            this.b25.BackColor = System.Drawing.Color.Silver;
            this.b25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b25.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b25.GlowColor = System.Drawing.Color.Transparent;
            this.b25.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b25.InnerBorderColor = System.Drawing.Color.White;
            this.b25.Location = new System.Drawing.Point(581, 475);
            this.b25.Name = "b25";
            this.b25.OuterBorderColor = System.Drawing.Color.Black;
            this.b25.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b25.ShineColor = System.Drawing.Color.Silver;
            this.b25.Size = new System.Drawing.Size(263, 36);
            this.b25.TabIndex = 1409;
            this.b25.TabStop = false;
            this.b25.Tag = "0";
            this.b25.Text = "Name";
            // 
            // lbAddress
            // 
            this.lbAddress.BackColor = System.Drawing.Color.White;
            this.lbAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAddress.Location = new System.Drawing.Point(51, 12);
            this.lbAddress.Name = "lbAddress";
            this.lbAddress.Size = new System.Drawing.Size(231, 27);
            this.lbAddress.TabIndex = 1488;
            this.lbAddress.Text = "Address";
            this.lbAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAddress_
            // 
            this.lbAddress_.BackColor = System.Drawing.Color.White;
            this.lbAddress_.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAddress_.Location = new System.Drawing.Point(51, 43);
            this.lbAddress_.Name = "lbAddress_";
            this.lbAddress_.Size = new System.Drawing.Size(231, 106);
            this.lbAddress_.TabIndex = 1489;
            this.lbAddress_.Text = "25-32, LS-ro 116beon-gil, Dongan-gu, Anyang-si, Gyeonggi-do, Republic of Korea";
            this.lbAddress_.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbContact
            // 
            this.lbContact.BackColor = System.Drawing.Color.White;
            this.lbContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbContact.Location = new System.Drawing.Point(51, 158);
            this.lbContact.Name = "lbContact";
            this.lbContact.Size = new System.Drawing.Size(231, 27);
            this.lbContact.TabIndex = 1490;
            this.lbContact.Text = "Contact Us";
            this.lbContact.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTel
            // 
            this.lbTel.BackColor = System.Drawing.Color.White;
            this.lbTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTel.Location = new System.Drawing.Point(51, 189);
            this.lbTel.Name = "lbTel";
            this.lbTel.Size = new System.Drawing.Size(231, 27);
            this.lbTel.TabIndex = 1491;
            this.lbTel.Text = "TEL : +82 031-763-5067";
            this.lbTel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbFax
            // 
            this.lbFax.BackColor = System.Drawing.Color.White;
            this.lbFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbFax.Location = new System.Drawing.Point(51, 220);
            this.lbFax.Name = "lbFax";
            this.lbFax.Size = new System.Drawing.Size(231, 27);
            this.lbFax.TabIndex = 1492;
            this.lbFax.Text = "FAX : +82 050-4446-5068";
            this.lbFax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEmail
            // 
            this.lbEmail.BackColor = System.Drawing.Color.White;
            this.lbEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbEmail.Location = new System.Drawing.Point(51, 251);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(231, 27);
            this.lbEmail.TabIndex = 1493;
            this.lbEmail.Text = "E-Mail : sic_work@naver.com";
            this.lbEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // b0
            // 
            this.b0.BackColor = System.Drawing.Color.Silver;
            this.b0.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b0.GlowColor = System.Drawing.Color.Transparent;
            this.b0.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b0.InnerBorderColor = System.Drawing.Color.White;
            this.b0.Location = new System.Drawing.Point(312, 12);
            this.b0.Name = "b0";
            this.b0.OuterBorderColor = System.Drawing.Color.Black;
            this.b0.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b0.ShineColor = System.Drawing.Color.Silver;
            this.b0.Size = new System.Drawing.Size(263, 36);
            this.b0.TabIndex = 1495;
            this.b0.TabStop = false;
            this.b0.Tag = "0";
            this.b0.Text = "Name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(51, 297);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 213);
            this.pictureBox1.TabIndex = 1494;
            this.pictureBox1.TabStop = false;
            // 
            // b26
            // 
            this.b26.BackColor = System.Drawing.Color.Silver;
            this.b26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b26.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b26.GlowColor = System.Drawing.Color.Transparent;
            this.b26.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b26.InnerBorderColor = System.Drawing.Color.White;
            this.b26.Location = new System.Drawing.Point(581, 517);
            this.b26.Name = "b26";
            this.b26.OuterBorderColor = System.Drawing.Color.Black;
            this.b26.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b26.ShineColor = System.Drawing.Color.Silver;
            this.b26.Size = new System.Drawing.Size(263, 36);
            this.b26.TabIndex = 1497;
            this.b26.TabStop = false;
            this.b26.Tag = "0";
            this.b26.Text = "Name";
            // 
            // b27
            // 
            this.b27.BackColor = System.Drawing.Color.Silver;
            this.b27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b27.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.b27.GlowColor = System.Drawing.Color.Transparent;
            this.b27.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b27.InnerBorderColor = System.Drawing.Color.White;
            this.b27.Location = new System.Drawing.Point(582, 559);
            this.b27.Name = "b27";
            this.b27.OuterBorderColor = System.Drawing.Color.Black;
            this.b27.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.b27.ShineColor = System.Drawing.Color.Silver;
            this.b27.Size = new System.Drawing.Size(263, 36);
            this.b27.TabIndex = 1496;
            this.b27.TabStop = false;
            this.b27.Tag = "0";
            this.b27.Text = "Name";
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FormInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 675);
            this.Controls.Add(this.b26);
            this.Controls.Add(this.b27);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.lbFax);
            this.Controls.Add(this.lbTel);
            this.Controls.Add(this.lbContact);
            this.Controls.Add(this.lbAddress_);
            this.Controls.Add(this.lbAddress);
            this.Controls.Add(this.b14);
            this.Controls.Add(this.b15);
            this.Controls.Add(this.b16);
            this.Controls.Add(this.b17);
            this.Controls.Add(this.b18);
            this.Controls.Add(this.b19);
            this.Controls.Add(this.b20);
            this.Controls.Add(this.b23);
            this.Controls.Add(this.b22);
            this.Controls.Add(this.b21);
            this.Controls.Add(this.b24);
            this.Controls.Add(this.b25);
            this.Controls.Add(this.b13);
            this.Controls.Add(this.b12);
            this.Controls.Add(this.b11);
            this.Controls.Add(this.b10);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Name = "FormInformation";
            this.Text = "FormEQInformation";
            this.Load += new System.EventHandler(this.FormInforation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Glass.GlassButton b1;
        private Glass.GlassButton b2;
        private Glass.GlassButton b3;
        private Glass.GlassButton b4;
        private Glass.GlassButton b5;
        private Glass.GlassButton b6;
        private Glass.GlassButton b7;
        private Glass.GlassButton b8;
        private Glass.GlassButton b9;
        private Glass.GlassButton b10;
        private Glass.GlassButton b11;
        private Glass.GlassButton b12;
        private Glass.GlassButton b13;
        private Glass.GlassButton b14;
        private Glass.GlassButton b15;
        private Glass.GlassButton b16;
        private Glass.GlassButton b17;
        private Glass.GlassButton b18;
        private Glass.GlassButton b19;
        private Glass.GlassButton b20;
        private Glass.GlassButton b23;
        private Glass.GlassButton b22;
        private Glass.GlassButton b21;
        private Glass.GlassButton b24;
        private Glass.GlassButton b25;
        private System.Windows.Forms.Label lbAddress;
        private System.Windows.Forms.Label lbAddress_;
        private System.Windows.Forms.Label lbContact;
        private System.Windows.Forms.Label lbTel;
        private System.Windows.Forms.Label lbFax;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Glass.GlassButton b0;
        private Glass.GlassButton b26;
        private Glass.GlassButton b27;
        private System.Windows.Forms.Timer timer1;
    }
}